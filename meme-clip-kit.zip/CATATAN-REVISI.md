# CATATAN REVISI — meme-clip-kit

## v1.0.0 (sesi-33) — rilis perdana

Konteks lahir: user minta sesi klip Windah Basudara "kali ini jatuhnya meme
sih, editingnya harus beda total, buat klip kit lain juga khusus meme atau
konten hiburan". Dibuat sebagai kit TERPISAH (zip sendiri di repo:
`meme-clip-kit.zip`) — ofc-clip-kit tidak disentuh.

### Keputusan desain

1. **Dark neon streamer aesthetic** — kebalikan total paper/kertas ofc:
   hitam pekat, aksen lime `#A6FF2F` + purple `#8B5CF6` + cyan `#22D3EE`.
2. **Video TANPA crop samping** (keputusan dari analisis VLM frame stream):
   facecam Windah di kiri-bawah (15-20% lebar layar), pindah kanan di
   beberapa scene cutscene — crop apapun berisiko memotong wajah. Video
   16:9 full-width 1080x608 di zona atas. Meme energy datang dari elemen
   sekitar (banner, chat bubble, caption), bukan dari memperbesar video.
3. **Luckiest Guy** (Google Fonts, OFL) — font komik display untuk subtitle
   KAPITAL + hook banner. Di-bundle di public/fonts (render offline aman).
   Poppins tetap untuk chip UI kecil.
4. **Chat bubble = dekorasi, bukan kutipan** — pool pesan generik
   ("WKWKWKWK", "GILA SIH", dst) dengan username jelas fiktif. Overlay
   gaya Twitch adalah konvensi edit meme/hiburan.
5. **Emoji DILARANG** — runner GA tidak punya font emoji warna (tofu di
   headless Chrome). Semua elemen teks murni; ikon play = CSS murni.
6. **Hook banner** — field opsional `hook` per klip (schema sheet + types
   + build-clips diperluas, backward-compatible). Fallback: id → kapital.
7. **Determinisme render ulang**: chat bubble & jitter rotasi subtitle
   pakai `random(seed-string)` Remotion (fungsi hash deterministik) —
   render ulang klip = pixel identik, aman utk retry idempoten.

### Perubahan teknis vs ofc-clip-kit v1.2.4

- `src/config.ts` — ditulis ulang penuh (tema MEME).
- `src/components/` baru: MemeBackground, HookBanner, ChatBubbles.
  Dihapus: PaperBackground, TapeCorners. Subtitles/Watermark/ProgressBar
  ditulis ulang; SourceBadge disalin (restyle via config).
- `src/Root.tsx` — loadFont Luckiest Guy + demo hook.
- `src/types.ts` / `src/schemas.ts` — field `hook?` opsional.
- `scripts/build-clips.mjs` — teruskan `hook`; warning durasi < 40s
  dilonggarkan jadi < 12s (meme klip pendek).
- `scripts/` lain, `remotion.config.ts`, `tsconfig.json`, pipeline data,
  format out/data, format sheet — IDENTIK ofc (workflow GA tidak perlu
  perubahan apa pun selain URL kit + warna QA).
- Workflow `ga-render.yml` (repo) dapat input baru `kit_url` + `qa_color`
  supaya bisa render pakai kit mana pun — default tetap ofc.

### QA piksel

Kata aktif lime rgb(166,255,47) → threshold `r>120, g>210, b<110`
(ofc kuning: r>200, g>160, b<120). Diteruskan via input `qa_color`
format `"120,210,110"`.
