import React, {useMemo} from 'react';
import {
  AbsoluteFill,
  random,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {CANVAS, SUBTITLE} from '../config';
import type {Chunk, Word} from '../types';

const clamp = (v: number, min: number, max: number) =>
  Math.min(max, Math.max(min, v));

/** parse #RRGGBB -> [r,g,b] */
const hex2rgb = (h: string): [number, number, number] => {
  const n = parseInt(h.replace('#', ''), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};

/** campur dua warna hex, p = 0..1 (a -> b) */
const mixColor = (a: string, b: string, p: number) => {
  const A = hex2rgb(a);
  const B = hex2rgb(b);
  const k = clamp(p, 0, 1);
  const c = A.map((av, i) => Math.round(av + (B[i] - av) * k));
  return `rgb(${c[0]}, ${c[1]}, ${c[2]})`;
};

/**
 * SUBTITLE MEME — kapital semua, font komik Luckiest Guy, stroke pekat:
 *  - chunk 2-4 kata masuk BOUNCE per kata (overshoot + jitter rotasi
 *    kecil deterministik — tiap kata mendarat dengan sudut beda)
 *  - kata yang sedang diucap berubah LIME neon + glow, mengikuti
 *    timestamp word-level whisper (karaoke) — identitas meme kit
 *  - keluar cepat sebelum chunk berikutnya; jeda napas tetap di-hold
 */
export const Subtitles: React.FC<{chunks: Chunk[]}> = ({chunks}) => {
  const frame = useCurrentFrame();
  const {fps, height} = useVideoConfig();
  const t = frame / fps;

  // chunk aktif = chunk terakhir yang waktunya sudah mulai
  const activeIdx = useMemo(() => {
    let idx = -1;
    for (let i = 0; i < chunks.length; i++) {
      if (chunks[i].start <= t) {
        idx = i;
      } else {
        break;
      }
    }
    return idx;
  }, [chunks, t]);

  if (activeIdx === -1) {
    return null;
  }

  const chunk = chunks[activeIdx];
  const next = chunks[activeIdx + 1];
  const visibleUntil = next
    ? Math.min(next.start, chunk.end + SUBTITLE.holdAfterEnd)
    : chunk.end + SUBTITLE.holdAfterEnd;
  if (t >= visibleUntil) {
    return null;
  }

  const chunkStartFrame = Math.round(chunk.start * fps);
  const exitStartFrame = Math.round(visibleUntil * fps) - SUBTITLE.exitFrames;
  const exitP = clamp((frame - exitStartFrame) / SUBTITLE.exitFrames, 0, 1);

  /**
   * Progress highlight kata (0..1):
   *  - naik cepat saat kata mulai diucap (onFrames) -> lime penuh
   *  - tahan selama kata diucap + holdBuffer
   *  - fade balik ke putih (fadeFrames)
   */
  const wordActiveP = (w: Word): number => {
    if (!SUBTITLE.activeWord.enabled) return 0;
    const onDur = Math.max(SUBTITLE.activeWord.onFrames, 1) / fps;
    const offDur = Math.max(SUBTITLE.activeWord.fadeFrames, 1) / fps;
    const on = w.start;
    const off = Math.max(w.end, w.start + 0.15) + SUBTITLE.activeWord.holdBuffer;
    if (t >= off + offDur) return 0;
    if (t >= off) return 1 - (t - off) / offDur;
    if (t >= on + onDur) return 1;
    if (t >= on) return (t - on) / onDur;
    return 0;
  };

  const raw = chunk.words.map((w) => w.text).join(' ');
  const text = SUBTITLE.uppercase ? raw.toUpperCase() : raw;

  // heuristic lebar: Luckiest Guy KAPITAL jauh lebih lebar dari Poppins (~0.72 —
  // termasuk kontribusi margin antar kata yang ikut melebarkan baris)
  const estWidth = text.length * SUBTITLE.fontSize * 0.72;
  const maxW = CANVAS.width * SUBTITLE.maxWidthRatio;
  const fontSize = Math.max(
    SUBTITLE.minFontSize,
    Math.min(
      SUBTITLE.fontSize,
      (SUBTITLE.fontSize * maxW) / Math.max(estWidth, 1)
    )
  );

  const wordStyle = (w: Word, i: number): React.CSSProperties => {
    const delay = i * SUBTITLE.staggerFrames;
    const s = spring({
      fps,
      frame: Math.max(0, frame - chunkStartFrame - delay),
      config: SUBTITLE.spring,
      durationInFrames: SUBTITLE.entryFrames,
    });
    // highlight lime mengikuti irama bicara per kata
    const p = wordActiveP(w);
    const active = SUBTITLE.activeWord.enabled && p > 0;
    const color = active
      ? mixColor(SUBTITLE.color, SUBTITLE.activeWord.color, p)
      : SUBTITLE.color;
    const pop = 1 + (SUBTITLE.activeWord.scale - 1) * p;
    const op = active
      ? SUBTITLE.activeWord.dimOpacity +
        (1 - SUBTITLE.activeWord.dimOpacity) * p
      : SUBTITLE.activeWord.dimOpacity;
    // jitter rotasi deterministik per kata (chunk beda -> sudut beda)
    const rot =
      (random(`sub-${activeIdx}-${i}`) - 0.5) * 2 * SUBTITLE.rotJitterDeg;
    return {
      display: 'inline-block',
      fontFamily: SUBTITLE.fontFamily,
      fontWeight: SUBTITLE.fontWeight,
      fontSize,
      lineHeight: SUBTITLE.lineHeight,
      letterSpacing: SUBTITLE.letterSpacing,
      color,
      WebkitTextStroke: `${SUBTITLE.strokeWidth}px ${SUBTITLE.strokeColor}`,
      paintOrder: 'stroke',
      whiteSpace: 'pre',
      // Luckiest Guy punya letter-spacing internal LEBAR (antar huruf dalam
      // satu kata ±6-9px di font 64px) — supaya kata terbaca sebagai kata
      // terpisah, margin antar kata harus jauh di atasnya (gap efektif
      // ±0.5 x fontSize). Stroke juga melukis ke luar glyph strokeWidth/2.
      margin: `0 ${Math.round(fontSize * 0.32)}px`,
      transform: `translateY(${(1 - s) * 34}px) rotate(${rot * s}deg) scale(${s * pop})`,
      opacity: s * op,
      filter: active
        ? `${SUBTITLE.shadow}, drop-shadow(${SUBTITLE.activeWord.glow})`
        : SUBTITLE.shadow,
    };
  };

  return (
    <AbsoluteFill>
      <div
        style={{
          position: 'absolute',
          left: (CANVAS.width * (1 - SUBTITLE.maxWidthRatio)) / 2,
          width: CANVAS.width * SUBTITLE.maxWidthRatio,
          top: SUBTITLE.centerY * height,
          transform: `translateY(-50%) scale(${1 - exitP * 0.04}) rotate(${(1 - exitP) * -0.4}deg)`,
          opacity: 1 - exitP,
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          alignContent: 'center',
        }}
      >
        {chunk.words.map((w, i) => (
          <span key={`${activeIdx}-${i}`} style={wordStyle(w, i)}>
            {SUBTITLE.uppercase ? w.text.toUpperCase() : w.text}
          </span>
        ))}
      </div>
    </AbsoluteFill>
  );
};
