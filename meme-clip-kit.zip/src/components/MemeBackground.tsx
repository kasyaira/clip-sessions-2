import React from 'react';
import {random, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {BG, CANVAS, GRAIN} from '../config';

/**
 * BACKGROUND MEME — dark neon "streamer gamer":
 *   hitam pekat -> garis diagonal miring bergerak lambat ->
 *   glow purple di belakang video -> glow cyan di zona caption ->
 *   vignette -> grain halus (menyatukan semua lapisan).
 * Kebalikan total dari paper-beige ofc-clip-kit.
 */
export const MemeBackground: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const stripes: React.CSSProperties = BG.stripes.enabled
    ? {
        position: 'absolute',
        inset: '-30%',
        backgroundImage: `repeating-linear-gradient(${BG.stripes.angle}deg, ${BG.stripes.color} 0 ${BG.stripes.size / 2}px, transparent ${BG.stripes.size / 2}px ${BG.stripes.size}px)`,
        // geser diagonal pelan — latar "hidup" tanpa mengganggu
        backgroundPosition: `${-Math.round((frame / fps) * BG.stripes.drift)}px 0`,
      }
    : {};

  return (
    <Absolute bg={BG.color}>
      {BG.stripes.enabled ? <div style={stripes} /> : null}
      <div style={{position: 'absolute', inset: 0, background: BG.glowTop}} />
      <div style={{position: 'absolute', inset: 0, background: BG.glowBottom}} />
      <Vignette />
    </Absolute>
  );
};

const Absolute: React.FC<{bg: string; children: React.ReactNode}> = ({
  bg,
  children,
}) => (
  <div
    style={{
      position: 'absolute',
      top: 0,
      left: 0,
      width: CANVAS.width,
      height: CANVAS.height,
      backgroundColor: bg,
      overflow: 'hidden',
    }}
  >
    {children}
  </div>
);

const Vignette: React.FC = () => (
  <div
    style={{
      position: 'absolute',
      inset: 0,
      background: `radial-gradient(ellipse 90% 74% at 50% 46%, rgba(0,0,0,0) 58%, rgba(0,0,0,${BG.vignette}) 100%)`,
    }}
  />
);

/** Grain halus di atas seluruh frame — video & background menyatu */
export const GrainOverlay: React.FC = () => {
  const frame = useCurrentFrame();

  if (!GRAIN.enabled) {
    return null;
  }

  const style: React.CSSProperties = {
    position: 'absolute',
    inset: 0,
    backgroundImage: `url(${staticFile(GRAIN.texture)})`,
    backgroundRepeat: 'repeat',
    opacity: GRAIN.opacity,
    mixBlendMode: GRAIN.blend,
    pointerEvents: 'none',
  };

  if (GRAIN.animated) {
    const x = Math.floor(random(`grain-x-${frame}`) * 512);
    const y = Math.floor(random(`grain-y-${frame}`) * 512);
    style.backgroundPosition = `${x}px ${y}px`;
  }

  return <div style={style} />;
};
