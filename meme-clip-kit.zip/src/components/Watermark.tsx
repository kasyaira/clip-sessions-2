import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';
import {WATERMARK} from '../config';

/**
 * Watermark @ofkiehme — chip gelap pojok KIRI-bawah dengan titik lime.
 * (ofc: chip frosted-paper di atas-tengah — meme kit: bawah-kiri,
 * gelap + neon, seirama badge source.)
 */
export const Watermark: React.FC = () => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [0, 14], [0, 1], {
    easing: Easing.out(Easing.cubic),
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <div
      style={{
        position: 'absolute',
        left: WATERMARK.left,
        bottom: WATERMARK.bottom,
        opacity: p,
        transform: `translateY(${(1 - p) * 14}px)`,
        userSelect: 'none',
        zIndex: 30,
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          padding: `${WATERMARK.chipPaddingV}px ${WATERMARK.chipPaddingH}px`,
          borderRadius: 999,
          background: WATERMARK.chipBg,
          border: WATERMARK.chipBorder,
          boxShadow: WATERMARK.chipShadow,
          backdropFilter: 'blur(2px)',
        }}
      >
        <div
          style={{
            width: WATERMARK.dotSize,
            height: WATERMARK.dotSize,
            borderRadius: 999,
            background: WATERMARK.dotColor,
            boxShadow: WATERMARK.dotGlow,
          }}
        />
        <span
          style={{
            fontFamily: WATERMARK.fontFamily,
            fontWeight: WATERMARK.fontWeight,
            fontSize: WATERMARK.fontSize,
            letterSpacing: WATERMARK.letterSpacing,
            color: WATERMARK.color,
          }}
        >
          {WATERMARK.text}
        </span>
      </div>
    </div>
  );
};
