import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {BANNER, CANVAS} from '../config';

/**
 * HOOK BANNER — strip lime miring ala sticker ditempel menimpa jahitan
 * bawah video. Teks = "hook" klip (judul singkat penuh energi) atau
 * fallback dari id. Masuk dengan overshoot dari kiri, tahan beberapa
 * detik, lalu melesat keluar ke kanan.
 */

/** id klip -> teks hook fallback: "i-can-fix-her" -> "I CAN FIX HER" */
export const hookFromId = (id: string): string =>
  id.replace(/\.json$/, '').replace(/[-_]+/g, ' ').toUpperCase().trim();

export const HookBanner: React.FC<{hook: string}> = ({hook}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const text = hook.length > 0 ? hook.toUpperCase() : 'MEME';

  // ukuran font adaptif supaya teks panjang tetap muat di strip
  const maxW = CANVAS.width * BANNER.maxWidthRatio;
  const estWidth = text.length * BANNER.fontSize * 0.62;
  const fontSize = Math.max(
    BANNER.minFontSize,
    Math.min(BANNER.fontSize, (BANNER.fontSize * maxW) / Math.max(estWidth, 1))
  );

  // masuk: spring overshoot dari kiri (translateX -110% -> 0)
  const inFrame = Math.round(BANNER.inAt * fps);
  const s = spring({
    fps,
    frame: frame - inFrame,
    config: BANNER.inSpring,
    durationInFrames: 14,
  });

  // keluar: melesat ke kanan setelah hold
  const outStart = inFrame + Math.round(BANNER.hold * fps);
  const outP = Math.min(
    1,
    Math.max(0, (frame - outStart) / Math.max(BANNER.outFrames, 1))
  );
  const outX = outP * outP * CANVAS.width * 1.25; // easing kuadrat = lepasan cepat

  const x = -(1 - s) * CANVAS.width * 1.15 + outX;
  const scale = 0.92 + 0.08 * s;

  return (
    <div
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: CANVAS.width,
        height: CANVAS.height,
        pointerEvents: 'none',
        zIndex: 24,
      }}
    >
      <div
        style={{
          position: 'absolute',
          top: BANNER.centerY,
          left: '50%',
          transform: `translate(-50%, -50%) translateX(${x}px) rotate(${BANNER.rotate}deg) scale(${scale})`,
        }}
      >
        {/* strip bayangan — kesan sticker terangkat dari permukaan */}
        <div
          style={{
            position: 'absolute',
            left: 4,
            top: 6,
            right: -6,
            bottom: -4,
            background: BANNER.underlay,
            borderRadius: 10,
          }}
        />
        <div
          style={{
            position: 'relative',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 14,
            padding: `${BANNER.padV}px ${BANNER.padH}px`,
            background: BANNER.bg,
            borderRadius: 10,
            boxShadow: BANNER.shadow,
            maxWidth: CANVAS.width * BANNER.maxWidthRatio + BANNER.padH * 2,
          }}
        >
          <span
            style={{
              fontFamily: BANNER.fontFamily,
              fontSize,
              color: BANNER.color,
              letterSpacing: '0.02em',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              maxWidth: CANVAS.width * BANNER.maxWidthRatio,
            }}
          >
            {text}
          </span>
        </div>
      </div>
    </div>
  );
};
