#!/usr/bin/env node
/**
 * part-split.mjs — solusi bagian yang kebablas limit 10 menit (CARA-KERJA §36.3)
 * Potong wav bagian jadi 2 paruh (overlap 2s), whisper masing-masing paruh,
 * gabung dengan aturan titik-tengah overlap:
 *   A: start < mid      (dipertahankan dari paruh A)
 *   B: start >= mid     (waktu B digeser +mid-1)
 * Hasil join ditulis ke part-NN.words.json -> kompatibel merge transcribe-parts.
 *
 * Pemakaian:
 *   node scripts/part-split.mjs init 3      # potong bagian 3 jadi 2 paruh wav
 *   node scripts/part-split.mjs half 3 0    # transkrip paruh A (idempoten)
 *   node scripts/part-split.mjs half 3 1    # transkrip paruh B
 *   node scripts/part-split.mjs join 3      # gabung -> part-03.words.json
 */
import fs from 'node:fs';
import path from 'node:path';
import {execSync} from 'node:child_process';
import whisperSdk from '@remotion/install-whisper-cpp';

const WHISPER_CPP_VERSION = '1.7.3';
const WHISPER_DIR = 'whisper.cpp';
const TMP = 'out/tmp/parts';
const MODEL = process.env.WHISPER_MODEL || 'small';
const LANG = 'id';

const args = process.argv.slice(2);
const cmd = args[0] ?? 'help';
const N = Number(args[1]);

const p2 = (n) => String(n).padStart(2, '0');
const partWav = path.join(TMP, `part-${p2(N)}.wav`);
const halfWav = (h) => path.join(TMP, `part-${p2(N)}.half${h}.wav`);
const halfJson = (h) => path.join(TMP, `part-${p2(N)}.half${h}.words.json`);

const wavDur = (f) =>
  Number(execSync(`ffprobe -v error -show_entries format=duration -of csv=p=0 "${f}"`).toString().trim());

const meta0 = () => {
  const meta = JSON.parse(fs.readFileSync(path.join(TMP, 'parts-meta.json'), 'utf8'));
  if (!meta.parts[N]) throw new Error(`bagian ${N} tidak ada di parts-meta`);
  return meta;
};

const readMid = () => {
  const mid = JSON.parse(fs.readFileSync(path.join(TMP, `part-${p2(N)}.splitmeta.json`), 'utf8')).mid;
  if (!mid) throw new Error('jalankan "init" dulu');
  return mid;
};

async function ensureWhisper() {
  const {installWhisperCpp, downloadWhisperModel} = whisperSdk;
  await installWhisperCpp({version: WHISPER_CPP_VERSION, to: WHISPER_DIR, printOutput: true});
  await downloadWhisperModel({model: MODEL, folder: WHISPER_DIR, printOutput: true});
}

// gabung token -> kata (logika sama transcribe-parts.mjs)
const tokensToWords = (transcription) => {
  const words = [];
  const pushWord = (w) => {
    if (w && w.text.trim()) {
      words.push({
        text: w.text,
        start: Math.round(w.start * 1000) / 1000,
        end: Math.round(w.end * 1000) / 1000,
      });
    }
  };
  let cur = null;
  for (const segment of transcription) {
    for (const tok of segment.tokens ?? []) {
      const raw = tok.text ?? '';
      if (!raw.trim()) continue;
      if (/^<\|.*\|>$/.test(raw.trim())) continue;
      if (/^\[_\w+\]$/.test(raw.trim())) continue;
      if (/\[_TT_\d+\]/.test(raw.trim())) continue;
      const tokStart = tok.offsets ? tok.offsets.from / 1000 : tok.start;
      const tokEnd = tok.offsets ? tok.offsets.to / 1000 : tok.end;
      if (tokStart == null || tokEnd == null) continue;
      const startsNew = /^[\s▁]/.test(raw);
      const trimmed = raw.replace(/^▁/, '').trim();
      if (!trimmed) continue;
      const isPunct = /^[.,!?;:…%)\]]/.test(trimmed);
      if (startsNew && !isPunct) {
        pushWord(cur);
        cur = {text: trimmed, start: tokStart, end: tokEnd};
      } else if (cur) {
        cur.text += trimmed;
        cur.end = tokEnd;
      } else {
        cur = {text: trimmed, start: tokStart, end: tokEnd};
      }
    }
  }
  pushWord(cur);
  return words;
};

async function runWhisper(wavPath) {
  const {transcribe} = whisperSdk;
  const raw = await transcribe({
    inputPath: path.resolve(wavPath),
    whisperPath: WHISPER_DIR,
    whisperCppVersion: WHISPER_CPP_VERSION,
    model: MODEL,
    language: LANG,
    printOutput: false,
    tokenLevelTimestamps: true,
  });
  return tokensToWords(raw.transcription);
}

if (cmd === 'init') {
  const meta = meta0();
  const L = wavDur(partWav);
  const mid = Math.round(L / 2);
  if (!fs.existsSync(halfWav(0))) {
    execSync(`ffmpeg -y -t ${mid + 1} -i "${partWav}" -acodec copy "${halfWav(0)}"`, {stdio: 'ignore'});
  }
  if (!fs.existsSync(halfWav(1))) {
    execSync(`ffmpeg -y -ss ${mid - 1} -i "${partWav}" -acodec copy "${halfWav(1)}"`, {stdio: 'ignore'});
  }
  fs.writeFileSync(path.join(TMP, `part-${p2(N)}.splitmeta.json`), JSON.stringify({mid, L}));
  console.log(`[split-init] bagian ${N}: durasi ${L.toFixed(1)}s -> paruh A [0,${mid + 1}) + paruh B [${mid - 1},${L.toFixed(1)})`);
  process.exit(0);
}

if (cmd === 'half') {
  const H = Number(args[2]);
  if (![0, 1].includes(H)) { console.error('H harus 0 atau 1'); process.exit(1); }
  if (fs.existsSync(halfJson(H))) {
    const w = JSON.parse(fs.readFileSync(halfJson(H), 'utf8'));
    console.log(`[half ${N}.${H}] sudah ada (${w.length} kata) — skip`);
    process.exit(0);
  }
  await ensureWhisper();
  const t0 = Date.now();
  const words = await runWhisper(halfWav(H));
  fs.writeFileSync(halfJson(H), JSON.stringify(words));
  console.log(`[half ${N}.${H}] OK: ${words.length} kata dalam ${((Date.now() - t0) / 1000).toFixed(0)}s`);
  process.exit(0);
}

if (cmd === 'join') {
  const mid = readMid();
  if (!fs.existsSync(halfJson(0)) || !fs.existsSync(halfJson(1))) {
    console.error('[join] kedua paruh harus selesai dulu'); process.exit(1);
  }
  const A = JSON.parse(fs.readFileSync(halfJson(0), 'utf8'));
  const B = JSON.parse(fs.readFileSync(halfJson(1), 'utf8'));
  const shift = mid - 1; // paruh B mulai di waktu global (mid-1) bagian
  const out = [];
  for (const w of A) {
    if (w.start < mid) out.push({...w}); // A menyimpan kata start < mid
  }
  for (const w of B) {
    if (w.start >= 1) { // lokal >= 1s == global >= mid (hindari kata terpotong tepat di tepi)
      out.push({
        text: w.text,
        start: Math.round((w.start + shift) * 1000) / 1000,
        end: Math.round((w.end + shift) * 1000) / 1000,
      });
    }
  }
  out.sort((a, b) => a.start - b.start);
  const outPath = path.join(TMP, `part-${p2(N)}.words.json`);
  fs.writeFileSync(outPath, JSON.stringify(out));
  let mono = true;
  for (let i = 1; i < out.length; i++) if (out[i].start < out[i - 1].start - 0.01) mono = false;
  console.log(`[join ${N}] A:${A.length} B:${B.length} -> ${out.length} kata (mono=${mono}) -> ${path.basename(outPath)}`);
  if (!mono) { console.error('[join] !! tidak monotonik — cek paruh'); process.exit(1); }
  process.exit(0);
}

console.log('Pemakaian: init N | half N 0|1 | join N');
