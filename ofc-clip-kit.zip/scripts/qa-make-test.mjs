#!/usr/bin/env node
/**
 * QA visual v1.2: buat data klip UJI dari potongan awal video asli.
 * - extract audio 45s pertama (ffmpeg) -> whisper small -> words
 * - tulis out/data/qa-style-test.json (video: input/raw.mp4, clipStart 2s)
 * Dipakai oleh scripts/qa-frames.mjs untuk render still.
 * Parsing token = logika persis scripts/transcribe.mjs (terbukti).
 */
import fs from 'node:fs';
import path from 'node:path';
import {execSync} from 'node:child_process';
import whisperSdk from '@remotion/install-whisper-cpp';

const WHISPER_DIR = 'whisper.cpp';
const {transcribe} = whisperSdk;
const SLICE = 'out/tmp/qa-slice.wav';
const OUT = 'out/data/qa-style-test.json';
const FROM = 2; // mulai dari detik 2 (lewati intro jingle bila ada)

fs.mkdirSync('out/tmp', {recursive: true});
console.log('[qa-data] extract audio 45s @', FROM, 's ...');
execSync(
  `ffmpeg -y -v error -ss ${FROM} -t 45 -i public/input/raw.mp4 -ac 1 -ar 16000 ${SLICE}`
);

console.log('[qa-data] whisper ...');
const rawJson = await transcribe({
  inputPath: path.resolve(SLICE),
  whisperPath: WHISPER_DIR,
  whisperCppVersion: '1.7.3',
  model: 'small',
  language: 'id',
  printOutput: false,
  tokenLevelTimestamps: true,
});
const {transcription} = rawJson;

// gabung token -> kata (logika persis transcribe.mjs)
const words = [];
const pushWord = (w) => {
  if (w && w.text.trim()) {
    words.push({
      text: w.text,
      start: Math.round(w.start * 1000) / 1000,
      end: Math.round(w.end * 1000) / 1000,
    });
  }
};
let cur = null;
for (const segment of transcription) {
  for (const tok of segment.tokens ?? []) {
    const raw = tok.text ?? '';
    if (!raw.trim()) continue;
    if (/^<\|.*\|>$/.test(raw.trim())) continue;
    if (/^\[_\w+\]$/.test(raw.trim())) continue;
    if (/\[_TT_\d+\]/.test(raw.trim())) continue;
    const tokStart = tok.offsets ? tok.offsets.from / 1000 : tok.start;
    const tokEnd = tok.offsets ? tok.offsets.to / 1000 : tok.end;
    if (tokStart == null || tokEnd == null) continue;
    const startsNew = /^[\s▁]/.test(raw);
    const trimmed = raw.replace(/^▁/, '').trim();
    if (!trimmed) continue;
    const isPunct = /^[.,!?;:…%)\]]/.test(trimmed);
    if (startsNew && !isPunct) {
      pushWord(cur);
      cur = {text: trimmed, start: tokStart, end: tokEnd};
    } else if (cur) {
      cur.text += trimmed;
      cur.end = tokEnd;
    } else {
      cur = {text: trimmed, start: tokStart, end: tokEnd};
    }
  }
}
pushWord(cur);
console.log('[qa-data] words:', words.length);

// offset: whisper slice mulai 0, klip uji dimulai di FROM
const shifted = words.map((w) => ({
  text: w.text,
  start: Number((w.start + FROM).toFixed(3)),
  end: Number((w.end + FROM).toFixed(3)),
}));

fs.mkdirSync('out/data', {recursive: true});
fs.writeFileSync(
  OUT,
  JSON.stringify(
    {
      id: 'qa-style-test',
      video: 'input/raw.mp4',
      clipStart: FROM,
      clipEnd: FROM + 42,
      words: shifted,
      sourceChannel: 'Tirta PengPengPeng',
    },
    null,
    2
  )
);
console.log('[qa-data] saved:', OUT, '| words:', shifted.length);
