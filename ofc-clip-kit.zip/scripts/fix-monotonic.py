#!/usr/bin/env python3
"""
fix-monotonic.py — perbaiki timestamp kata yang MUNDUR (back-jump).

Whisper 'small' kadang halusinasi token-timestamp di tengah bagian: satu run
kata tiba-tiba ber-timestamp mundur berurutan (contoh CARA-KERJA 52: 'Tapi'
75.96-73.73 -> 'percaya' 73.73-69.82 -> dst). Ini BUKAN bug merge dan BUKAN
salah sambungan bagian — jangan geser split-point, cukup perbaiki di sini.

Metode (52): deteksi run non-monotonik, INTERPOLASI linear antara kata baik
terakhir SEBELUM run dan kata baik pertama SESUDAH run (slot = rentang/n-kata,
durasi minimum 0.05s). Idempoten: kalau sudah mono 100%, tidak ada yang diubah.

Pemakaian:
  python3 scripts/fix-monotonic.py out/transcripts/raw.json           # fix in-place
  python3 scripts/fix-monotonic.py file.json --check-only             # hanya diagnostik

Input: JSON list [{text,start,end}] ATAU {video,model,words:[...]}.
Exit code: 0 = mono (atau berhasil diperbaiki); 1 = masih ada back-jump
(atau file tidak bisa diparse).
"""
import json
import sys

MIN_DUR = 0.05


def load_words(path):
    data = json.load(open(path, encoding='utf-8'))
    if isinstance(data, dict) and 'words' in data:
        return data, data['words']
    if isinstance(data, list):
        return None, data
    raise ValueError('format tidak dikenali (harus list kata atau {"words": [...]})')


def is_bad(prev, w):
    """Kata dianggap menyebabkan back-jump kalau start mundur sebelum akhir
    kata sebelumnya, atau rentangnya terbalik (end < start)."""
    return w['start'] < prev['end'] - 0.01 or w['end'] < w['start']


def find_runs(words):
    """Kembalikan daftar run bad: (start_idx, end_idx) inklusif.
    Run = kata i..j di mana tiap kata bad relatif terhadap kata sebelumnya
    yang masih dipakai sebagai anchor (kata baik terakhir)."""
    runs = []
    n = len(words)
    i = 1
    anchor = 0
    while i < n:
        if is_bad(words[anchor], words[i]):
            j = i
            while j + 1 < n and is_bad(words[j], words[j + 1]):
                j += 1
            # run berakhir kalau kata j+1 sudah "baik" relatif j.
            # tapi bisa terlanjur melompat — cek juga relatif anchor
            runs.append((i, j))
            anchor = j
            i = j + 1
        else:
            anchor = i
            i += 1
    return runs


def interp(words, lo, hi):
    """Perbaiki run words[lo..hi] dengan interpolasi antara kata baik
    sebelumnya (words[lo-1]) dan sesudahnya (words[hi+1] bila ada)."""
    n_run = hi - lo + 1
    prev_end = words[lo - 1]['end'] if lo > 0 else 0.0
    nxt = words[hi + 1] if hi + 1 < len(words) else None
    span = (nxt['start'] - prev_end) if nxt else n_run * MIN_DUR
    slot = max(span / n_run, MIN_DUR) if span > 0 else MIN_DUR
    changed = []
    for k, w in enumerate(words[lo:hi + 1]):
        old = (w['start'], w['end'])
        s = prev_end + k * slot
        e = prev_end + (k + 1) * slot - min(0.01, slot * 0.2)
        if e - s < MIN_DUR:
            e = s + MIN_DUR
        w['start'] = round(s, 3)
        w['end'] = round(e, 3)
        changed.append((w['text'], old, (w['start'], w['end'])))
    return changed


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    path = sys.argv[1]
    check_only = '--check-only' in sys.argv
    wrapper, words = load_words(path)
    runs = find_runs(words)
    if not runs:
        print(f'[fix-mono] {path}: sudah mono 100% ({len(words)} kata) — tidak ada perubahan')
        sys.exit(0)
    total_bad = sum(h - l + 1 for l, h in runs)
    print(f'[fix-mono] {len(runs)} run non-monotonik, total {total_bad} kata:')
    if check_only:
        for lo, hi in runs:
            print(f'  run {lo}-{hi}: {words[lo]["text"]!r} @{words[lo]["start"]} ... {words[hi]["text"]!r} @{words[hi]["start"]}')
        sys.exit(1)
    for lo, hi in runs:
        changed = interp(words, lo, hi)
        for text, old, new in changed:
            print(f'  [{lo}] {text!r}: {old[0]}-{old[1]} -> {new[0]}-{new[1]}')
    # verifikasi ulang
    remaining = find_runs(words)
    out = wrapper if wrapper is not None else words
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    if remaining:
        print(f'[fix-mono] !! masih ada {len(remaining)} run — periksa manual')
        sys.exit(1)
    print(f'[fix-mono] OK: {total_bad} kata diinterpolasi, sekarang mono 100% ({len(words)} kata)')
    sys.exit(0)


if __name__ == '__main__':
    main()
