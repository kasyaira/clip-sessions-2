#!/bin/bash
# finish-one.sh <clip-id> <sesi-dir> — finalize idempoten → QA piksel 3 titik
# (proporsional durasi) + auto cek tetangga LOW (§20.6) → UPLOAD → bersih +
# HAPUS klip lokal setelah upload OK (§34.4). Log ke FILE dulu baru tail (§46).
# v3 SESI-22 — ATURAN NAMA FILE BARU (§55 CARA-KERJA):
#   NAMA REMOTE = slug topik DENGAN SPASI, TANPA nomor urut:
#     id "rocky-gerung-kritikus"  ->  "rocky gerung kritikus.mp4"
#   Urutan klip TIDAK ada di nama file — hanya di metadata.json (array order).
set -uo pipefail
ID="${1:?Pemakaian: bash finish-one.sh <clip-id> <sesi-dir>}"
SESI_DIR="${2:?Pemakaian: bash finish-one.sh <clip-id> <sesi-dir>}"
KIT=/home/z/my-project/ofc-clip-kit
cd "$KIT"
LOG="out/finish-$ID.log"
echo "=== finish-one $ID -> $SESI_DIR  $(date +%H:%M:%S) ===" > "$LOG"   # header (§53.9: baris berikut >>)

# 1. FINALIZE (idempoten §46: final sudah ada = skip; belum ada = cek segmen)
if [ ! -f "out/clips/$ID.mp4" ]; then
  if ! ls out/segments/seg-*.mp4 >/dev/null 2>&1; then
    echo "✗ tidak ada segmen utk '$ID' — render dulu (render-one.sh)" | tee -a "$LOG"; exit 2
  fi
  node scripts/finalize-clip.mjs "$ID" >> "$LOG" 2>&1
  if [ ! -f "out/clips/$ID.mp4" ]; then
    echo "✗ finalize gagal:" | tee -a "$LOG"; tail -6 "$LOG"; exit 3
  fi
fi
echo "[finish] final OK: out/clips/$ID.mp4" >> "$LOG"

# 2. QA PIKSEL — 3 titik proporsional durasi (25/55/85%)
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "out/clips/$ID.mp4" 2>/dev/null | grep -oE '[0-9.]+' | head -1)
[ -z "$DUR" ] && { echo "✗ ffprobe gagal baca durasi" | tee -a "$LOG"; exit 3; }
P1=$(python3 -c "print(round($DUR*0.25+0.5,1))")
P2=$(python3 -c "print(round($DUR*0.55+0.5,1))")
P3=$(python3 -c "print(round($DUR*0.85+0.5,1))")
QA_OUT=$(python3 scripts/qa_clip.py "out/clips/$ID.mp4" "$P1" "$P2" "$P3" 2>/dev/null)
echo "$QA_OUT" >> "$LOG"

# auto cek tetangga utk titik LOW (§20.6: micro-pause = normal)
LOW_TS=$(echo "$QA_OUT" | awk '/LOW/{gsub(/s$/,"",$1); print $1}')
if [ -n "$LOW_TS" ]; then
  echo "[QA] titik LOW di: $LOW_TS — cek tetangga ±1.5s (§20.6)" >> "$LOG"
  NEIGH_OK=0
  for T in $LOW_TS; do
    for OFF in -1.5 -0.7 0.7 1.5; do
      NT=$(python3 -c "print(max(0.3, round($T+$OFF,1)))")
      R=$(python3 scripts/qa_clip.py "out/clips/$ID.mp4" "$NT" 2>/dev/null | awk '/kuning/{print $1, $2, $NF}')
      echo "  tetangga ${NT}s: $R" >> "$LOG"
      echo "$R" | grep -q " OK " && NEIGH_OK=$((NEIGH_OK+1))
    done
  done
  echo "[QA] tetangga OK: $NEIGH_OK (>=2 = micro-pause, lanjut)" >> "$LOG"
fi

# 3. UPLOAD — ATURAN NAMA BARU §55: spasi, TANPA nomor urut
REMOTE_NAME="${ID//-/ }"
echo "[upload] $ID -> $SESI_DIR/$REMOTE_NAME.mp4" >> "$LOG"
node scripts/gh-upload.mjs "out/clips/$ID.mp4" "$SESI_DIR/$REMOTE_NAME.mp4" "klip: $REMOTE_NAME" >> "$LOG" 2>&1
if [ $? -ne 0 ]; then
  echo "✗ UPLOAD GAGAL (klip lokal DIPERTAHANKAN utk retry)" | tee -a "$LOG"; tail -6 "$LOG"; exit 4
fi

# 4. BERSIH — klip lokal dihapus setelah upload OK (§34.4) + intermediat
rm -f "out/clips/$ID.mp4"
rm -rf out/tmp/finalize/* 2>/dev/null
echo "[finish] SELESAI OK — '$REMOTE_NAME.mp4' ter-upload, lokal dibersihkan" | tee -a "$LOG"
tail -n 14 "$LOG"
exit 0
