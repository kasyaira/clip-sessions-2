#!/bin/bash
# render-one.sh <clip-id> — render satu klip dengan marker resume (§40/§53.5).
# Marker out/segments/.current-clip mencegah reset segmen saat panggilan ulang
# tool call (segmen pending dilanjutkan, bukan diulang dari nol).
# ATURAN NAMA SESI-22 (§55 CARA-KERJA): ID klip = slug topik TANPA nomor urut.
set -uo pipefail
ID="${1:?Pemakaian: bash render-one.sh <clip-id>}"
KIT=/home/z/my-project/ofc-clip-kit
cd "$KIT"

# anti-typo §53.5: id HARUS ada di out/data (copy-paste dari ls out/data/)
if [ ! -f "out/data/$ID.json" ]; then
  echo "✗ out/data/$ID.json TIDAK ADA — copy-paste id dari: ls out/data/"
  exit 1
fi

MARKER="out/segments/.current-clip"
CUR=""
[ -f "$MARKER" ] && CUR=$(cat "$MARKER")
if [ "$CUR" != "$ID" ]; then
  echo "[render-one] ganti klip ('$CUR' -> '$ID'): reset segments + marker"
  rm -rf out/segments
  mkdir -p out/segments
fi
echo "$ID" > "$MARKER"

LOG="out/render-$ID.log"
echo "=== render-one $ID $(date +%H:%M:%S) ===" >> "$LOG"
bash scripts/render-retry.sh "$ID" 3 >> "$LOG" 2>&1
EC=$?

# tail ringkas ke stdout (log penuh di file)
tail -n 18 "$LOG"
echo "--- disk: $(df -h / | awk 'NR==2{print $4" bebas"}')"
exit $EC
