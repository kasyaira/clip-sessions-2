# Catatan Sesi — Download YouTube & Transkrip Video Panjang

> Ditulis dari log agent yang sudah berhasil **end-to-end**: download video
> YouTube 56 menit → transkrip → 7 klip panjang ter-render & lolos QA.
> Tujuan file ini: agent sesi berikutnya **langsung pakai cara yang terbukti
> jalan**, tanpa mengulang jalan buntu yang sudah terbukti gagal di sandbox
> ini. Taruh file ini di root project (atau sekadar lampirkan ke chat) dan
> minta agent baca ini **sebelum** mulai research cara download video.
>
> Ikuti bersama `SKILL.md` → `AGENTS.md` → `CATATAN-TEKNIS.md`. File ini
> melengkapi ketiganya, khusus untuk bagian yang belum tertulis di sana:
> download video sumber + transkrip video panjang.

---

## 1. Download video YouTube — ini yang SUDAH TERBUKTI GAGAL, jangan diulang

Sandbox ini kemungkinan besar jalan dari IP datacenter, yang sudah ditandai
YouTube. Semua jalur "biasa" gagal, secara berurutan:

| Cara | Hasil di sesi ini | Kenapa jangan diulang duluan |
|---|---|---|
| `yt-dlp` langsung (semua player client dicoba: web, android, ios, tv_embedded, dst) | diblokir bot-check | konsisten diblokir di semua client, bukan soal client mana yang dipakai |
| Piped (proxy publik) | diblokir juga | instance publik kena block/rate-limit yang sama |
| Invidious (instance publik) | mayoritas mati / tidak balas JSON valid | daftar instance publik cepat basi, jangan habiskan waktu coba satu-satu |
| cobalt (API publik) | sekarang wajib JWT auth | kebijakan mereka berubah, sandbox tidak punya token |

**Jangan mulai dari salah satu di atas.** Kalau mau coba variasi lagi
(client baru / instance baru), itu tetap masuk kategori "sudah terbukti buntu"
sampai ada bukti sebaliknya — jangan buang >5 menit di sini.

## 2. Yang TERBUKTI JALAN: `loader.to`

Alur yang berhasil di sesi ini:

1. Kirim request ke API **loader.to** (layanan yang dipakai banyak
   "youtube downloader" pihak ketiga) dengan URL video.
2. Poll endpoint progress-nya sampai statusnya selesai / dapat link download.
3. Download file dari link yang dikembalikan (`curl`/`wget` biasa).

Hasil di sesi ini: dapat judul video + file 422MB terdownload utuh.

> Endpoint/parameter API pihak ketiga seperti ini bisa berubah sewaktu-waktu.
> Kalau bentuk request yang dipakai sesi lalu sudah tidak jalan, cari dulu
> dokumentasi/endpoint terbaru loader.to (web search) — **tapi tetap mulai
> dari loader.to / layanan sejenis dulu**, jangan balik lagi ke
> yt-dlp/Piped/Invidious/cobalt di atas kecuali loader.to juga sudah benar-benar
> mati saat itu.

Kalau loader.to juga buntu: opsi terakhir adalah minta user upload video
mentah secara manual — jangan habiskan lebih dari ~15-20 menit total mencoba
jalur otomatis sebelum menyerah ke opsi ini.

## 3. Video sumber: cek CFR dulu, jangan asal re-encode ke 30fps

`public/input/README.txt` bilang re-encode ke CFR 30fps kalau videonya VFR.
Untuk video panjang, re-encode itu bisa makan puluhan menit — jadi **cek
dulu**, jangan asumsi:

```bash
# 1) cek cepat
ffprobe -select_streams v -show_entries stream=r_frame_rate,avg_frame_rate,nb_frames video.mp4

# 2) kalau r_frame_rate == avg_frame_rate, VERIFIKASI lebih jauh dengan
#    packet timestamps — CFR asli harus di grid rapi (mis. kelipatan 1/25s),
#    tanpa drift:
ffprobe -select_streams v -show_entries packet=pts_time -of csv video.mp4 | head -50
```

Kalau videonya sudah CFR asli (walau fps-nya bukan 30, mis. 25fps) dan grid-nya
rapi tanpa drift → **langsung pakai sebagai `raw.mp4` tanpa re-encode**. Di
sesi ini video 25fps CFR dipakai langsung, hemat waktu render yang seharusnya
kepakai buat re-encode 56 menit video.

Re-encode ke CFR 30fps **hanya** kalau video terbukti VFR (drift antar frame).

## 4. Transkrip video panjang (>10 menit) — WAJIB dipecah per-bagian

Whisper model `small` di sandbox ini (2 core) jalan **~0.91× realtime**
(kalibrasi dari sesi ini: audio 120s → whisper 110s). Satu tool call sandbox
biasanya dibatasi ±10 menit, jadi video panjang **tidak akan muat** ditranskrip
dalam satu panggilan.

Strategi yang terbukti jalan:

1. **Kalibrasi dulu**, jangan asumsi angka di atas — potong 2 menit audio,
   transkrip, ukur waktunya. Kecepatan bisa beda tergantung load sandbox
   saat itu.
2. Dari situ hitung durasi per-bagian yang aman (target proses <8 menit per
   panggilan, sisakan buffer dari limit 10 menit). Di sesi ini: bagian
   **420 detik (7 menit)** dengan **overlap 6 detik** antar-bagian.
3. Transkrip tiap bagian di panggilan tool terpisah (pola sama dengan
   `render-segments.mjs` — alasan yang sama: kerja panjang dipecah per sesi
   tool-call).
4. **Merge**: titik potong antar-bagian diambil beberapa detik **masuk ke
   dalam area overlap** (bukan pas di batas mentah) — supaya kata yang
   terpotong tepat di ujung bagian tidak hilang atau dobel. Sesi ini: overlap
   6s, split-point +3s ke dalam overlap.
5. **Validasi merge**: cek jumlah gap/kata hilang di titik sambung = 0.
   Kalau ada gap, geser split-point sedikit dan cek ulang.

Hasil sesi ini: 8 bagian × video 56 menit → merge bersih, 0 gap, 7887 kata.

## 5. Render panjang: Chrome crash di tengah segmen itu NORMAL, bukan bug

Ini sudah diantisipasi arsitektur `render-segments.mjs` (idempoten per
segmen) — kalau render mati di tengah (Chrome crash / proses kebunuh sandbox),
**jangan didiagnosis lama-lama**. Segmen yang sudah selesai tetap aman, cukup
panggil lagi:

```bash
bash scripts/render-retry.sh <nama-data>
```

sampai semua segmen kelar. Ini bukan lagi masalah yang perlu "dipecahkan
ulang" tiap sesi — cukup percaya ke wrapper retry.

## 6. Dua bug yang ditemukan sesi ini SUDAH diperbaiki di kode kit

Tidak perlu ditemukan/diperbaiki manual lagi mulai sekarang (lihat
`CATATAN-TEKNIS.md` §13 di zip terbaru):

- **`/tmp` penuh (ENOSPC)** setelah beberapa kali render — penyebabnya
  `bundle()` Remotion menumpuk file baru ~800MB+ di `/tmp` tiap dipanggil
  (termasuk copy penuh `public/`, video mentah ikut ter-duplikasi tiap kali).
  → sudah di-fix: bundle sekarang pakai folder tetap (`.remotion-bundle/` di
  root project, di-overwrite tiap panggilan, tidak menumpuk).
- **Symlink `whisper.cpp/main` hilang** tiap build whisper.cpp fresh (SDK
  butuh nama itu, hasil `make` menaruhnya di `build/bin/main`) → sudah
  di-fix: `bootstrap.sh` sekarang otomatis membuat symlink ini tiap selesai
  build ATAU restore dari cache-pack.
- Kalau kamu masih pakai `clip-kit-cache.tar.gz` versi lama (dari sebelum fix
  ini): **tetap aman dipakai**, tidak perlu dibuat ulang — fix symlink jalan
  otomatis setelah extract, terlepas dari isi cache-pack-nya.

## 7. Ringkasan alur "langsung tembak" untuk sesi berikutnya

```
1. Download video via loader.to (skip yt-dlp/Piped/Invidious/cobalt)
2. ffprobe cek CFR — re-encode HANYA kalau VFR
3. cp video -> public/input/raw.mp4
4. bash scripts/bootstrap.sh   (extract cache-pack kalau ada)
5. Kalibrasi kecepatan whisper (potongan 2 menit) -> tentukan ukuran bagian
6. Transkrip per-bagian dengan overlap, merge, validasi 0 gap
7. Tentukan batas klip dari transkrip (cek kata di sekitar tiap batas)
8. npm run build-data
9. bash scripts/render-retry.sh <nama-data>   (ulang sampai semua segmen selesai)
10. Finalisasi (concat + mux audio) + QA visual (ekstrak 2-3 frame per klip)
```

---

# ADDENDUM SESI-09 (video 51.5 menit "Bobon Mau Bantu Lebih Banyak Orang Lewat Politik")

> Sesi ini menjalankan LAGI alur §7 end-to-end dan menemukan beberapa jalan
> buntu baru + fix-nya. Semua di bawah SUDAH DIVERIFIKASI JALAN di sesi ini.
> Script baru semuanya sudah masuk zip kit terbaru (lihat daftar §9).

## 8. Metode download yang BERHASIL (konfirmasi ulang §2): loader.to

Skrip siap pakai sekarang ada di kit: `scripts/loader-download.mjs`

```
node scripts/loader-download.mjs "https://youtu.be/<id>" /path/out.mp4 720
```

- Alur: POST `loader.to/ajax/download.php?format=720&url=...` → dapat `id` →
  poll `loader.to/ajax/progress.php?id=<id>` tiap 3s sampai ada `download_url`
  → fetch file-nya (stream ke `.part`, rename setelah utuh).
- Hasil sesi ini: video 51:29 (3089s), 1280x720 **CFR 30fps asli** (r_frame_rate
  == avg_frame_rate == 30/1, semua pts di grid 1/30) → dipakai langsung
  sebagai `raw.mp4` TANPA re-encode (§3).
- Catatan: tool call bisa ke-timeout sebelum skrip selesai — file `.part`
  yang belum direname berarti belum utuh; file yang SUDAH direname tapi proses
  terbunuh TETAP VALID (cukup `ffprobe` untuk verifikasi). Kalau belum selesai,
  jalankan lagi skrip yang sama (tidak otomatis resume — mulai dari progress
  terakhir server biasanya cepat, atau ulang total).
- oEmbed (`https://www.youtube.com/oembed?url=...&format=json`) selalu jalan
  untuk konfirmasi judul/channel DULU sebelum download.

## 9. Script baru di kit (semua terverifikasi sesi ini)

| Script | Fungsi |
|---|---|
| `scripts/transcribe-parts.mjs` | transkrip per-bagian (§4) jadi 4 subcommand: `calibrate` (ukur kecepatan whisper pakai potongan 120s), `init --part-len 420 --overlap 6` (potong wav per bagian), `part N` (transkrip bagian N, idempoten, cache per bagian), `merge` (gabung + validasi monotonic). Merge rule: bagian menyimpan kata lokal di `[overlap/2, partLen-overlap/2)` — TERBUKTI 0 gap, 0 back-jump. |
| `scripts/finalize-clip.mjs` | concat segmen muted + mux audio asli dari video sumber (rentang clipStart-lead sampai +tail) → `out/clips/<id>.mp4` +faststart. Sekaligus validasi jumlah frame vs target. |
| `scripts/gh-upload.mjs` | upload 1 file ke repo GitHub `clip-sessions` via Contents API; kalau 422/502 otomatis fallback ke Git Blobs/Tree/Commit API. |
| `scripts/gh-push-big.sh` | file BESAR (>±45MB) yang ditolak API: git plumbing (fetch blob-less → hash-object → read-tree → update-index → commit-tree → push). |
| `scripts/qa-frames.mjs` | render frame PNG tertentu dari data klip untuk QA visual cepat. |
| `scripts/words-around.mjs` | lihat kata + timestamp di sekitar detik tertentu — untuk pilih batas klip presisi di batas kalimat. |
| `scripts/dump-transcript.mjs` | dump transkrip per jendela 20s untuk baca struktur topik. |
| `scripts/loader-download.mjs` | download via loader.to (§8). |

## 10. Bug & jalan buntu BARU yang ditemukan sesi ini (beserta fix)

1. **`tsconfig.json` tidak ada di zip kit** → `npx remotion browser ensure`
   GAGAL dengan pesan "Could not find a tsconfig.json". Fix: buat tsconfig
   standar Remotion (sudah ikut zip terbaru).
2. **pip PEP 668** (`externally-managed-environment`) → `pip install cmake`
   ditolak. Fix yang berhasil: `python3 -m venv ~/.venv` lalu
   `~/.venv/bin/python -m pip install cmake` (CATATAN: binary `pip` tidak ada
   di venv ini — WAJIB pakai `python -m pip`). Bootstrap lalu otomatis nemu
   cmake di `~/.venv/bin`.
3. **`@remotion/studio` hilang dari node_modules** padahal dibutuhkan
   `@remotion/bundler` (error `renderEntry.js` MODULE_NOT_FOUND) — paket ini
   TIDAK ada di package.json kit. Fix: `npm install @remotion/studio@4.0.526`
   (WAJIB pin versi sama persis dengan remotion lain). Kalau npm bilang
   "up to date" tapi filenya rusak (sisa install yang terbunuh), hapus folder
   `node_modules/@remotion/studio` dulu baru install ulang.
4. **Kebocoran /tmp LEBIH PARAH dari §6**: bukan cuma `bundle()` yang numpuk
   (`/tmp/remotion-webpack-bundle-*` ±420MB/panggilan), `renderMedia` juga
   meninggalkan `/tmp/remotion-v*-assets*` (±400MB/proses, isinya copy
   `public/` = video mentah). Render beberapa segmen bisa habiskan disk 10GB
   dalam <30 menit → node mati diam-diam (log KOSONG, exit instan = cek
   `df -h` dulu!). Fix: `render-retry.sh` sekarang membersihkan kedua pola
   itu sebelum & sesudah tiap percobaan.
5. **Symlink whisper.cpp/main** (§6) memang belum ada di zip lama — sudah
   ditambahkan ke `bootstrap.sh` (auto `ln -sfn build/bin/main main`).
6. **`ffprobe -of csv=p=0`** mengeluarkan trailing comma ("1584,") →
   `Number()` langsung jadi NaN. Selalu parse dengan regex `/\d+/`.
7. **Frame QA tepat di detik bulat** sering jatuh pas frame pertama chunk
   (animasi pop-in mulai dari opasitas 0) → subtitle kelihatan "hilang".
   Bukan bug — sampling QA di offset .5-.7 detik.
8. **Proses background (`nohup ... &`) tetap dibunuh** saat tool call
   berakhir (konfirmasi § CATATAN-TEKNIS) — bootstrap WAJIB foreground,
   ulang sampai selesai (idempoten per langkah).

## 11. Upload GitHub: batas ukuran & metode yang jalan (TERVERIFIKASI)

- Repo target: `kasyaira/clip-sessions`, 1 folder per sesi
  (`sesi-XX-slug/`) + `metadata.json` per sesi (ikuti format sesi-08).
- **Contents API PUT** oke untuk ± file <±45MB. Mendekati batas sering
  balas **502/504** (transient — boleh retry sekali) atau **422** "file is
  too large to be processed" (permanent untuk ukuran itu).
- **Git Blobs API** juga menolak payload base64 yang sama besar (422
  "input was too large").
- **Metode yang JALAN untuk file besar (terpakai untuk 46-54MB)**:
  `scripts/gh-push-big.sh` = git plumbing:
  ```
  git init work; git remote add origin https://<user>:<PAT>@github.com/...
  git fetch --depth 1 --filter=blob:none origin main   # cuma commit+tree, kecil
  BLOB=$(git hash-object -w file.mp4)
  git read-tree origin/main^{tree}
  git update-index --add --cacheinfo 100644,$BLOB,path/di/repo.mp4
  git commit-tree $(git write-tree) -p origin/main -m "msg"
  git push origin <commit>:main
  ```
  PERINGATAN: proses `push` melakukan lazy-fetch SEMUA blob repo (repo ini
  ±1.4GB!) → work dir membengkak. **Hapus work dir gh-push setelah tiap
  push** (fetch ulang berikutnya cuma beberapa detik).
- Upload per-klip SEGERA setelah klip selesai (workflow user: satu-satu,
  tanpa nunggu batch) — urutan render pakai prioritas topik terkuat dulu
  supaya kalau sesi mati di tengah, yang sudah ter-upload adalah yang paling
  penting.

## 12. Word-level yellow highlight (upgrade subtitle sesi-09)

`src/components/Subtitles.tsx` + `src/config.ts` (nilai di
`SUBTITLE.activeWord`):
- Kata yang SEDANG diucap → warna **kuning #FFD60A**, scale 1.08x, glow
  drop-shadow lembut, opasitas penuh; ramp naik 2 frame, tahan 0.3s
  setelah kata selesai, fade balik 3 frame.
- Kata lain → putih, opasitas 0.85 (masih jelas), outline hitam 13px.
- Style single-active (hanya kata aktif yang kuning) — beda dari sesi-08
  yang progresif (kata yang sudah diucap tetap kuning). Keduvalidasi QA
  visual via VLM: highlight presisi mengikuti timestamp kata.
- Konfigurasi semua di `config.ts` (single source of truth) — ganti warna/
  timing di situ tanpa sentuh komponen.

## 13. Alur "langsung tembak" versi sesi-09 (menggantikan §7)

```
 1. oEmbed konfirmasi video → loader-download.mjs (skip yt-dlp/Piped/Invidious/cobalt)
 2. ffprobe CFR → re-encode HANYA kalau VFR (§3)
 3. cp video -> public/input/raw.mp4
 4. bash scripts/bootstrap.sh  (foreground, ulang sampai selesai;
    cek df -h kalau langkah mati diam-diam → bersihkan /tmp/remotion-*)
 5. transcribe-parts.mjs calibrate → init --part-len <hasil kalibrasi> →
    part 0..N (satu tool call per bagian) → merge (harus mono, 0 gap)
 6. dump-transcript.mjs + words-around.mjs → tentukan batas klip di batas
    KALIMAT (bukan asal detik), topik harus tuntas, 111-236s sesi ini
 7. render-inputs/clips.json → npm run build-data
 8. PER KLIP: rm -rf out/segments; render-retry.sh <id> (ulang sampai semua
    segmen); finalize-clip.mjs <id>; QA 1-2 frame (qa-frames / ffmpeg -ss);
    UPLOAD LANGSUNG (gh-upload.mjs / gh-push-big.sh) — jangan nunggu batch
 9. metadata.json per sesi (format sesi-08) → upload
10. Upload zip kit revisi + CARA-KERJA.md terbaru ke repo
```

---

# ADDENDUM SESI-10 (video 13:02 "Menolak Pakar Termasuk NPD Nggak Sih?" — Felix Siauw)

> Video pendek: alur §13 jalan tanpa modifikasi (cuma 2 bagian transkrip).
> TAPI sesi ini menemukan insiden penting soal TOKEN yang wajib diketahui
> semua sesi berikutnya — lihat §14.

## 14. INSIDEN TOKEN: hardcode di zip kit = AUTO-REVOKE oleh GitHub

**Apa yang terjadi:** token PAT yang di-hardcode di `gh-upload.mjs` +
`gh-push-big.sh` (per permintaan "simpan hardcode gapapa") IKUT TER-PUBLISH
ke repo PUBLIK `kasyaira/clip-sessions` lewat `ofc-clip-kit.zip`. GitHub
punya **secret scanning** yang otomatis mendeteksi fine-grained PAT yang
bocor di repo publik dan **langsung me-revoke-nya**. Akibatnya di sesi-10:
- REST API `api.github.com` → 401 "Bad credentials"
- `git push` → "Invalid username or token" (padahal fetch/ls-remote SUKSES
  — MENIPU, karena repo-nya publik: fetch jalan anonim tanpa auth sama
  sekali! Jangan pakai ls-remote/fetch sebagai bukti token valid.)

**Aturan mulai sesi-10 (SUDAH DITERAPKAN DI KIT):**
1. TOKEN TIDAK PERNAH LAGI DITULIS DI FILE KIT. `gh-upload.mjs` dan
   `gh-push-big.sh` sekarang membaca token dari file eksternal DI LUAR
   kit: `/home/z/my-project/work/.ghtoken` (satu baris, isi PAT saja).
2. Sebelum zip kit di-upload ke repo, SELALU scan dulu:
   `rg -l "github_pat_" scripts/ src/ *.md *.json` → harus kosong.
3. Kalau token baru diberikan user lewat chat: tulis ke `.ghtoken`,
   jangan pernah echo nilai token ke file yang akan di-upload.
4. Cara verifikasi token sebelum pakai: `git push --dry-run` (bukan
   ls-remote — lihat poin menipu di atas).

## 15. Catatan alur sesi-10 (video pendek 13 menit)

- Video 782s CFR 23.976fps → langsung `raw.mp4` tanpa re-encode (§3).
- Kalibrasi whisper: 0.96x realtime → part-len 460 → cuma 2 bagian
  (init otomatis hitung), merge 1713 kata 0 gap.
- 5 klip membagi HABIS seluruh video (0-782s, tanpa gap antar klip),
  batas potong di batas kalimat persis via words-around (§13 langkah 6):
  0-220.6 / 220.6-422.6 / 422.6-561.4 / 561.8-661.4 / 661.9-782.0
- Urutan render prioritas topik terkuat dulu (clip-02 ceklist NPD →
  clip-01 mitos → clip-03 → clip-04 → clip-05) — sesuai §11.
- QA piksel cepat (pengganti VLM kalau tidak sempat): ekstrak frame,
  cek 1080x1920 + ada piksel kuning #FFD60A di area subtitle dengan PIL
  — terbukti cukup untuk memastikan word-highlight jalan.
- gh-push-big.sh sekarang otomatis hapus work dir gh-push setelah tiap
  push (§11) — tidak perlu manual lagi.

---

# ADDENDUM SESI-11 (penyelesaian sesi-10: upload 5 klip Felix NPD)

> User kasih token PAT baru (lama di-revoke, lihat §14) + minta clip
> youtu.be/3SkVPuJnGBI. oEmbed judulnya ternyata = video yang SAMA dengan
> sesi-10 — dan hasil kerja sesi-10 MASIH ADA (lihat §16). Sesi ini tidak
> download/transkrip/render ulang sama sekali, cukup verifikasi + upload.

## 16. PENTING: folder upload/ SELAMAT dari reset sandbox

Direktori `/home/z/my-project/upload/` adalah mount jaringan (ossfs) yang
**TIDAK ikut ter-reset** bersama sandbox. Di sesi-11 ditemukan `upload/ofc-clip-kit/`
masih berisi DIRECTORI KERJA SESI-10 UTUH 1.9GB: whisper.cpp ter-build + model
small 487MB + node_modules + chrome headless shell + out/ (5 klip final, transcript
1713 kata, out/data) + cache-pack 54MB.

**Langkah pertama setiap sesi baru: CEK dulu `upload/` sebelum kerja apapun.**
Kalau ada `upload/ofc-clip-kit/` dari sesi lalu, pulihkan dengan rsync (§17)
daripada build dari nol / render ulang.

Konfirmasi video = video sesi lama: oEmbed ID-nya, cocokkan judulnya dengan
metadata render log / CARA-KERJA addendum sebelumnya.

## 17. Copy dari upload/ KE root project: pakai RSYNC, jangan mv

`mv upload/ofc-clip-kit ofc-clip-kit` = COPY antar-mount (~4.4MB/s), tool call
ke-timeout di 120s dan menyisakan copy setengah jadi. Yang benar:

```
rsync -a --exclude='out/' --exclude='clip-kit-cache.tar.gz' \
  --exclude='out-render-*.log' --exclude='out-seg*.log' --exclude='.git' \
  upload/ofc-clip-kit/ ofc-clip-kit/
```

- rsync lanjut otomatis dari file yang sudah tersalin (aman dipanggil ulang).
- `out/` dibiarkan di upload/ — klip final & transcript bisa dibaca/di-upload
  langsung dari path upload/ (gh-upload.mjs terima path absolut).
- Setelah rsync: tulis token baru ke `work/.ghtoken`, lalu `bootstrap.sh`
  (langsung skip semua karena node_modules + whisper + chrome sudah ada).

## 18. Verifikasi ulang klip warisan sebelum upload (sesi-11)

Sebelum upload klip hasil sesi lama, cek cepat (semua lolos di sesi-11):
1. ffprobe tiap klip: 1080x1920, 30fps, stream audio aac ada, durasi masuk akal.
2. QA piksel (§15): ffmpeg ekstrak 1 frame per klip + PIL hitung piksel kuning
   #FFD60A di area subtitle — >50 piksel = word-highlight jalan.
3. Transcript warisan: cek jumlah kata + timestamp akhir ≈ durasi video.

## 19. Metode upload terkonfirmasi ulang (sesi-11)

- 33.4MB / 25.5MB / 27.8MB → Contents API PUT langsung OK.
- 47.4MB / 49.6MB → Contents API 422 → Git Blobs API 422 → `gh-push-big.sh`
  SUKSES (cepat, beberapa puluh detik saja — catatan lazy-fetch 1.4GB di §11
  tidak terjadi lagi di sesi-11).
- Upload klip satu-satu tetap urut topik terkuat dulu (§11).
- README.md repo perlu dirapikan tabel sesinya (belum di-update sejak sesi-05;
  sesi-11 sudah lengkapi s/d sesi-10 — jaga tetap ter-update tiap sesi).

---

# ADDENDUM SESI-12 (video sesi-11: "Kenapa orang-orang pada ngomongin Mas Wapres?" — Ray Restu Fauzi)

> Catatan penomoran: addendum ini labelnya SESI-12 karena addendum sesi
> agent sebelumnya sudah memakai nama "SESI-11" (sesi agent yang hanya
> menyelesaikan upload sesi-10). Untuk FOLDER VIDEO di repo, video ini
> tetap terdaftar sebagai sesi-11 (penomoran mengikuti video, bukan
> sesi agent). Video 31:44, 1280x720, 60fps CFR ASLI (full-scan nol gap),
> dipakai langsung tanpa re-encode → 11 klip full-coverage 0-1904.5s.

## 20. Catatan operasional sesi ini (semua terverifikasi jalan)

1. **Sandbox reset LAGI** — pola pemulihan §16-17 terbukti: `upload/`
   selamat, rsync dari `upload/ofc-clip-kit/` (exclude out/, cache, .git,
   CARA-KERJA.md supaya versi repo tidak tertimpa versi lama), lalu
   `work/.ghtoken` ditulis ulang, bootstrap skip semua.
2. **JANGAN paralel rsync + loader-download** di dua tool call bersamaan —
   bandwidth berbagi, keduanya timeout. Jalankan berurutan.
3. **loader-download bisa "timeout" padahal SUDAH selesai** — tool call
   ke-timeout tepat setelah file ter-rename dari .part. SELALU cek
   `work/raw-new.mp4` ada + ffprobe valid SEBELUM retry download.
4. Sumber 60fps (pertama kali di-project ini) diproses normal — kit render
   30fps, video card 60fps tidak masalah, A/V sinkron (audio di-mux dari
   sumber, bukan hasil render).
5. Kalibrasi whisper 0.99x realtime → part-len 460 → 5 bagian → merge
   4147 kata, mono, 0 back-jump.
6. QA piksel: frame gagal kuning=0 di clip-05 @80.5s ternyata micro-pause
   antar chunk (kata "datang" selesai 840.40, "mulai" mulai 840.43) —
   frame tetangga (±1-2s) semua OK. Sebelum diagnosa gagal, SELALU cek
   3-4 frame tetangga + cek transkrip apakah sedang jeda hening.
7. Upload: 21-22MB → Contents API OK; 28-55MB → langsung gh-push-big.sh
   (semua sukses sekali jalan, cepat — jangan buang waktu coba Contents
   API untuk file >28MB).
8. 11 klip × render ≈ 2-3 panggilan render-retry per klip (masing-masing
   kena timeout 10 menit lalu lanjut) — total ~4 jam untuk video 31 menit.
   Pola: `rm -rf out/segments && render-retry.sh <id> 3` ulang sampai
   EXIT=0, lalu finalize + qa_clip.py + upload SEBELUH klip berikutnya.
9. README repo + metadata.json + CARA-KERJA.md + zip kit di-update tiap
   akhir sesi (tabel sesi di README jangan sampai tertinggal lagi).

## 21. Cache-pack LENGKAP (dengan model) tersimpan permanen di upload/

Bootstrap sesi ini membuat cache-pack baru 526MB yang SUDAH TERMASUK
model whisper small (yang lama 54MB tidak). Salinan sudah ditaruh di
mount persisten: `upload/clip-kit-cache.tar.gz`.

Sesi baru (setelah reset) punya 2 jalur pemulihan — pilih salah satu:
- **Jalur A (paling cepat)**: rsync dari `upload/ofc-clip-kit/` (§17) —
  dapat whisper+model+node_modules+chrome sekaligus (~5 menit).
- **Jalur B**: extract `upload/clip-kit-cache.tar.gz` ke root kit
  (`tar xzf` di dalam folder kit) untuk whisper+model+chrome, lalu
  `npm ci` untuk node_modules (~2-3 menit).

---

# ADDENDUM SESI-13 (video sesi-12: "Eps 1072 | 4 CARA LEPAS DARI KEMISKINAN DI INDONESIA" — guru gembul)

> Sesi agent ini menjalankan alur §13 end-to-end LAGI setelah sandbox reset.
> Semua di bawah terverifikasi jalan di sesi ini. 12 klip full-coverage
> 0-1796.7s (29:57) selesai render + QA + upload dalam satu sesi.

## 22. Pemulihan sesi ini: model hilang dari upload/ofc-clip-kit/

- Sandbox reset LAGI — pola §16-17 tetap berlaku: `upload/` selamat.
- BARU: `upload/ofc-clip-kit/whisper.cpp/` TIDAK lagi berisi
  `ggml-small.bin` (487MB) — entah dibersihkan antar sesi. Solusi cepat
  terbukti: extract SATU FILE dari cache-pack root, cuma 7 detik:
  ```
  tar xzf upload/clip-kit-cache.tar.gz -C ofc-clip-kit/ whisper.cpp/ggml-small.bin
  ```
- Temuan kecepatan mount: rsync per-file LAMBAT (~1.1MB/s, 1.25GB = 3
  tool call × 10 menit), tapi BACA SEKUENSIAL FILE BESAR SANGAT CEPAT
  (dd test 3.3 GB/s). Jadi: kode via rsync, barang berat via tarball
  cache-pack — jangan rsync model/binary besar kalau bisa dari tarball.
- Verifikasi rsync: bandingkan `find . -type f -printf "%s %p\n" | sort`
  + jumlah byte source vs target (du bisa menyesatkan di ossfs).

## 23. Catatan operasional sesi ini

1. Kalibrasi whisper 1.02x realtime → part-len 460 → 4 bagian → merge
   4.095 kata mono 0 back-jump (video 29:57).
2. **Jingle intro di tengah video di-SKIP** (preseden baru): klip-02
   berakhir di "Yuk kita bahas." (289.91), klip-03 mulai SETELAH jingle
   musik 290.26-301.98 → start 302.00. Full-coverage tetap berlaku
   kecuali segmen non-bicara yang jelas-jelas jingle/musik.
3. Script QA baru masuk kit: `scripts/qa_clip.py` — QA piksel batch
   (ambil N frame + hitung piksel kuning #FFD60A area subtitle +
   auto-saran cek tetangga). 2 kasus LOW @ frame sampling keduanya
   micro-pause antar kata (§20.6 terkonfirmasi lagi) — cek tetangga
   + transkrip words-around sebelum diagnosa gagal.
4. Pola upload sesi ini: 21.6MB & 27.5MB → Contents API OK; sisanya
   (27-58MB) langsung `gh-push-big.sh` — semua sekali jalan cepat.
5. Urutan render topik terkuat dulu (§11): nyogok-PNS → pesta-nikah →
   rumus-4 → moge-vs-gerobak → 4-ciri → S1-baso → kafe → tanda-miskin
   → mobil-macet → naik-ojek → bahan-bakar → bandingkan-diri.
6. Zip kit di-refresh + di-upload di akhir sesi (55 file kode + docs +
   render-inputs; TETAP tanpa node_modules/whisper/out/raw.mp4/cache).

## 24. Checklist penutupan sesi (jangan ada yang tertinggal)

1. Semua klip ter-upload (12/12) ✓
2. `metadata.json` per sesi (format sesi-08/11, topik dirangkum detail) ✓
3. `README.md` repo: tambah baris tabel sesi ✓
4. `CARA-KERJA.md`: addendum sesi ✓ (file ini)
5. `ofc-clip-kit.zip` refresh + upload ✓
6. Scan token sebelum zip: `rg -l "github_pat_" scripts/ src/ *.md *.json` harus kosong ✓

---

# ADDENDUM SESI-14 (video sesi-13: "RESPECT GONTOR! Harusnya Ulama itu Kayak Gini!" — Felix Siauw)

> Sesi agent menjalankan alur §13 end-to-end setelah sandbox reset, TAPI dengan
> kondisi BARU: mount `upload/` KOSONG total (§16-17 tidak berlaku — tidak ada
> warisan sesi sama sekali, mulai dari zip kit + token dari chat). 6 klip
> full-coverage 0-918.65s (15:19) selesai render + QA + upload dalam satu sesi.

## 25. PENTING: bootstrap.sh PUNYA BUG cmake → bisa bikin cache-pack RUSAK

Kondisi awal sesi ini: zip kit fresh extract, `upload/` kosong. Run PERTAMA
bootstrap.sh gagal diam-diam di langkah cmake:

1. **Bug**: bootstrap menjalankan `pip install cmake` LANGSUNG — ditolak PEP 668
   (`externally-managed-environment`), padahal fix yang terbukti (§10.2) adalah
   venv + `python -m pip`. Script meng-ekspor PATH ~/.venv/bin tapi TIDAK bikin
   venv-nya kalau belum ada.
2. **Akibat berantai**: whisper.cpp ke-clone tapi gagal build (cmake absen) →
   bootstrap tetap lanjut → **cache-pack 145M dibuat dari state RUSAK** (isi
   whisper.cpp source tanpa binary/model). Run bootstrap berikutnya extract
   cache rusak itu → gagal dengan "Whisper folder exists but the executable
   (whisper.cpp/main) is missing. Delete whisper.cpp and try again."
3. **Fix yang terbukti jalan**:
   ```
   python3 -m venv ~/.venv
   ~/.venv/bin/python -m pip install cmake
   cd ofc-clip-kit && rm -rf whisper.cpp clip-kit-cache.tar.gz
   export PATH="$HOME/.venv/bin:$PATH"
   bash scripts/bootstrap.sh     # selesai ~143s, cache-pack 573M BENAR
   ```
4. **Cegah berulang**: kalau bootstrap kedua kalinya extract cache lalu mati
   di "executable is missing" → JANGAN diagnosis whisper-nya, itu cache-pack
   rusak (dibuat dari run gagal). Hapus whisper.cpp + cache-pack + pastikan
   cmake venv ada, ulang bootstrap. (Ide perbaikan bootstrap: jangan bungkus
   cache-pack kalau whisper binary belum ada — belum di-patch, masih tugas
   sesi berikutnya kalau mau.)

## 26. ffprobe packet-pts itu DECODE ORDER (B-frame) — WAJIB sort dulu

Cek CFR §3 dengan `packet=pts_time`: output ffprobe TIDAK urut waktu
(reordering B-frame). Analisis gap tanpa sort menghasilkan anomali palsu
(sesi ini: 14.916 "gap" palsu dari 22.023 paket). **Sort dulu pts-nya baru
hitung grid** — hasil benar sesi ini: 100.00% interval tepat di grid
1001/24000 (23.976fps CFR asli) → dipakai langsung tanpa re-encode.

## 27. Catatan operasional sesi ini

1. Video 918.65s (15:19) 720p CFR → 3 bagian transkrip (kalibrasi 0.90x,
   part-len 460) merge 2.127 kata mono 0 back-jump.
2. 6 klip full-coverage: 0-158.85 / 158.85-320.11 / 320.11-523.50 /
   523.50-718.37 / 718.37-851.53 / 851.53-918.65 — semua batas di ujung
   kalimat persis via words-around. Klip penutup 67.6s (pesan punch-line
   "ulama tak bisa disetir") — boleh di bawah 111s asalkan topik tuntas.
3. Urutan render prioritas topik terkuat: fatwa-jam-miliaran →
   ulama-tak-bisa-disetir → juru-bicara-penguasa → agama-dasar →
   pukulan-Konstantinopel → penggembala-dan-ayah.
4. QA piksel: 3 frame LOW di 2 klip — SEMUA ternyata micro-pause antar kata
   atau pop-in kata baru (kata mulai 0.07s sebelum frame sampling). Frame
   tetangga ±1-2s semua OK → §20.6 terkonfirmasi LAGI: selalu cek tetangga
   + transkrip sebelum diagnosa gagal.
5. Upload: 12.2MB & 26.5MB → Contents API OK; 30-45MB → git plumbing.
   lihat §28 untuk pola timeout baru.
6. Whisper model `ggml-small.bin` sekali build langsung ikut cache-pack
   573M (bootstrap normal) — simpan cache-pack ke `upload/` di akhir sesi
   (§21) supaya sesi berikutnya jalur A/B pemulihan tersedia lagi.

## 28. gh-push-big.sh: timeout tool call di tengah lazy-fetch — jangan panic

Run pertama `gh-push-big.sh` (44MB) **ke-timeout tepat saat lazy-fetch blob
repo** (tool call 5 menit). Dua artefak yang ditinggalkan:

1. `work/gh-push/.git/index.lock` — run berikutnya tolak jalan
   ("Another git process seems to be running").
2. 1.7GB blob yang SUDAH ke-fetch tetap ada di work dir.

**Fix terbukti**: `rm -f work/gh-push/.git/index.lock` → jalankan LAGI
script yang sama → push sukses CEPAT (blob yang sudah lokal tidak di-fetch
ulang). Jangan `rm -rf` work dir-nya — justru itu aset yang bikin retry cepat.

**Optimisasi sesi ini** (simpan di luar kit): `gh-push-session.sh` — duplikat
gh-push-big.sh yang TIDAK menghapus work-dir setelah push. Push pertama
tetap bayar lazy-fetch sekali (~4-6 menit), push berikutnya di sesi yang
sama hanya hitungan detik. Hapus work-dir manual di akhir sesi.
(Lokasi agent: /home/z/my-project/scripts/gh-push-session.sh — tidak ikut
zip kit, sesi berikutnya bikin ulang 1 menit.)

## 29. Layout pemulihan di upload/ yang ditinggalkan sesi ini

Sesi ini meninggalkan mount `upload/` dalam struktur BERBEDA dari §16-17
(optimasi §22: barang berat via tarball, kode via rsync):

- `upload/clip-kit-cache.tar.gz` (600MB) — whisper.cpp TER-BUILD + model
  small + node_modules + chrome headless (SAMA dengan cache-pack root kit).
- `upload/ofc-clip-kit/` — kode lengkap (src, scripts, public, render-inputs,
  config) + `out/clips` (6 klip final) + `out/transcripts` + `out/data` +
  `public/input/raw.mp4`. TANPA whisper.cpp/node_modules (sengaja dihapus —
  ambil dari tarball, jangan rsync per-file: ossfs rsync ~0.8MB/s TAPI cp
  sekuensial ~97MB/s — terukur sesi ini: 600MB = 6 detik).

**Alur pemulihan sesi berikutnya ( tercepat ):**
```
1. rsync -a upload/ofc-clip-kit/ ofc-clip-kit/           # kode+out, ~30s
2. tar xzf upload/clip-kit-cache.tar.gz -C ofc-clip-kit/ # whisper+model+nm+chrome, ~1-2 menit
3. tulis token baru ke work/.ghtoken
4. bash scripts/bootstrap.sh  # harus skip semua (verifikasi biner ada)
```
Jangan pakai Jalur A §17 apa adanya (rsync full) — itu menyalin
node_modules/whisper per-file LAMBAT; pakai kombo rsync-kode + tarball di atas.

---

# ADDENDUM SESI-15 (video sesi-14: "GJ 160 | ALASAN PRABOWO TIDAK BISA MELAWAN MAFIA HUKUM DI INDONESIA?" — guru gembul)

> Sesi agent ini menjalankan alur §13 end-to-end di workspace warisan (sandbox
> TIDAK di-reset: ofc-clip-kit/ + node_modules + whisper + chrome masih utuh —
> rsync §29 instan karena identik). 6 klip full-coverage 0-692.29s (11:32)
> selesai render + QA + upload dalam satu sesi. Temuan penting baru: §30.

## 30. PENTING: cache transcribe-parts TIDAK ter-key per video — WAJIB bersihkan saat ganti video

Sandbox warisan masih berisi `out/tmp/parts/part-XX.words.json` + `part-XX.wav`
dari video SESI LALU. `init` memang meng-extract `raw-full.16k.wav` baru, tapi
`part N` tetap bilang "sudah ada — skip" karena cek idempotensinya hanya
lihat ADA/TIDAK-nya file cache (tidak ada identitas video). Akibatnya `merge`
bisa menggabungkan TRANSKRIP VIDEO LAMA ke video baru — salah total tanpa
error.

**Aturan mulai sekarang**: saat memproses video BARU di workspace bekas
sesi lama (apapun jalur pemulihannya), SEBELUM `init` jalankan:
```
rm -f out/tmp/parts/part-*.wav out/tmp/parts/part-*.words.json \
      out/tmp/parts/calib-120s.wav out/transcripts/raw.json
```
(Ide perbaikan script: simpan hash/durasi video di parts-meta.json dan
invalidasi cache otomatis — belum di-patch, tugas sesi berikutnya.)

## 31. Catatan operasional sesi ini (semua terverifikasi jalan)

1. Video 692.29s (11:32) 720p **CFR 30fps asli** (full-scan 20.766 paket
   sorted-pts: 100% di grid 1/30s, 0 drift — §26 terkonfirmasi lagi) →
   langsung tanpa re-encode.
2. Download loader.to: kena `UND_ERR_SOCKET` di 92MB → retry sukses.
   Tool call bisa ke-timeout SETELAH file selesai ter-rename — selalu
   ffprobe dulu sebelum ulang download (§8 terkonfirmasi lagi).
3. Kalibrasi whisper 0.92x realtime → part-len 460 → 2 bagian → merge
   **1.495 kata** mono 0 back-jump.
4. 6 klip full-coverage 0-692.29s, semua batas di ujung kalimat persis via
   words-around: 0-128.14 / 128.14-231.06 / 231.06-376.00 / 376.00-472.72 /
   472.72-552.02 / 552.02-692.29 (user minta eksplisit: tidak boleh ada
   topik terpotong — video padat, batas diangka di ujung kalimat tuntas).
5. Urutan render prioritas topik terkuat dulu: clip-03 tantangan-prabowo
   (topik judul video) → clip-01 sidak-viral → clip-06 uang-haram →
   clip-02 → clip-05 → clip-04. Setiap klip: rm -rf out/segments →
   render-retry (masing-masing cukup 1-2 panggilan tool) → finalize →
   qa_clip.py → upload LANGSUNNG.
6. QA piksel: 3 frame LOW semuanya micro-pause antar kata / pop-in awal
   kata (§20.6 + §10.7 terkonfirmasi lagi) — frame tetangga ±1-2s semua
   OK, QA LULUS.
7. Upload: 19.5MB & 27.6-27.7MB → git plumbing session (§32); 33.4-39.5MB
   → git plumbing session. Semua sukses.
8. `qa_clip.py` kadang exit code -9/255 SETELAH print hasil lengkap
   (dibunuh saat cleanup) — output QA tetap valid, baca stdout-nya.

## 32. §28 dioptimalkan: gh-push-session.sh VERIFIKASI — push berikutnya 10 detik

`gh-push-big.sh` versi kit menghapus work dir setelah push → SETIAP push
bayar lazy-fetch blob repo (~8 menit di sesi ini, 2x). Varian §28 dibuat
di `/home/z/my-project/scripts/gh-push-session.sh` (TIDAK ikut zip kit —
sesi berikutnya bikin ulang 1 menit, atau copy dari addendum ini):

- WORK dir terpisah `work/gh-push-session/` yang TIDAK dihapus tiap push
  (+ auto `rm -f .git/index.lock` §28 sebelum jalan).
- Push pertama: 8m02s (lazy-fetch sekali). Push kedua dst: **10-11 detik**.
- Token PAT nyangkut di `work/gh-push-session/.git/config` (remote URL) —
  aman karena DI LUAR kit, tapi **WAJIB `rm -rf work/gh-push-session` di
  akhir sesi**.

---

# ADDENDUM SESI-16 (video sesi-15: "UST FELIX SIAUW TAJEM BANGET MULUTNYA! WENDI & ANDHIKA JADI NGERI!" — Ngobrol di WA Eps.73, Wendi Cagur)

> Sesi agent ini menjalankan alur §13 end-to-end setelah sandbox reset (root
> project kosong, mount `upload/` selamat seperti §16). Video TERPANJANG di
> project ini: 69:11 (4151.12s) → intro jingle suara air 0-457.5s di-skip
> (preseden §23.2), full-coverage ucapan 457.5-4151.12s = **24 klip** selesai
> render + QA + upload dalam satu sesi. User minta kit diambil DARI REPO.

## 33. Pemulihan versi "kit dari repo" — kombinasi tercepat terverifikasi

User eksplisit minta "ambil klip kit dari repo dan file cara kerja md".
Urutan pemulihan yang terbukti (~5 menit total):

1. `CARA-KERJA.md` + `ofc-clip-kit.zip` di-download dari root repo via
   Contents API → zip di-extract ke `ofc-clip-kit/` (zip TANPA folder
   induk — `mkdir -p ofc-clip-kit && unzip -d ofc-clip-kit/`).
2. whisper.cpp TER-BUILD + model: `cp -a upload/ofc-clip-kit/whisper.cpp
   ofc-clip-kit/` — 29 detik (model 487MB = 1 file besar sekuensial, cepat).
3. node_modules: **JANGAN `cp -a`** (file kecil ribuan → timed out 5 menit,
   terhenti setengah). Cache-pack tarball juga TIDAK berisi node_modules
   penuh — hanya `node_modules/.remotion/chrome-headless-shell`. Solusi
   tercepat: `npm ci` = **8,6 DETIK** (npm cache lokal masih hangat) lalu
   `tar xzf upload/clip-kit-cache.tar.gz -C . node_modules/.remotion`
   (7 detik) untuk chrome.
4. `bash scripts/bootstrap.sh` → harus skip semua (verifikasi).

## 34. ENOSPC terjadi 3x — daftar pemakan disk yang WAJIB dipantau

Disk sandbox cuma 9.9GB; render 24 klip (612MB sumber + ~1GB output)
menabrak batas 3x (gejala: render mati diam-diam errno -28 di
screenshotTask). Pembersihan yang terbukti, urut dampak:

1. **`/tmp/my-project` = 5.4GB SALINAN BASI** project dari sesi lalu (isi
   ofc-clip-kit 2.8G + upload 1.9G lama) — ditemukan sesi ini, HAPUS TOTAL
   (dir kosongnya "Operation not permitted", biarkan). SELALU cek
   `du -sh /tmp/*` saat ENOSPC.
2. `out/tmp/finalize/` — intermediat concat/audio per klip menumpuk ~1GB
   setelah ~20 finalize. Aman dihapus tiap beberapa klip (file final sudah
   di out/clips).
3. `out/tmp/parts/*.wav` + `work/raw-new.mp4` (duplikat raw.mp4) — ~850MB,
   aman dihapus setelah merge transkrip selesai.
4. Klip yang SUDAH ter-upload repo → hapus salinan lokalnya di out/clips
   (repo = source of truth; push terverifikasi OK dulu).
5. `/tmp/react-motion-render*` menumpuk tiap percobaan render gagal.

## 35. Catatan operasional sesi ini

1. Video 4151.12s 720p **CFR 25fps asli** (full-scan 103.776 paket sorted:
   100% grid 0.04s, 0 gap) → tanpa re-encode. loader.to smooth sekali jalan
   (612MB; tool call timeout SETELAH file selesai — ffprobe dulu, §8).
2. Kalibrasi whisper 0.66x realtime → part-len 460 → **10 bagian** → merge
   9.145 kata mono 0 back-jump. Bagian 0 hanya 86 kata (intro jingle ikut
   kepotong bagian pertama — normal).
3. 24 klip full-coverage ucapan, semua batas ujung kalimat via words-around.
   Klip 80-239s; clip-07 (94.8s) & clip-20 (80s) di bawah 111s boleh karena
   topik tuntas (preseden §27.2 klip 67.6s).
4. QA piksel: 9 klip ada frame LOW, SEMUA micro-pause antar kata/frasa
   cepat (§20.6 terkonfirmasi N-kali) — frame tetangga ±1s selalu OK.
   `qa_clip.py` butuh PATH file (bukan clip-id) + exit -9/255 setelah print
   hasil adalah normal (§31.8).
5. Upload: 19.5MB & 25-32MB juga lewat git plumbing (Contents API cuma
   dipakai metadata/README — file <5MB). `gh-push-session.sh` (§32) dibuat
   ulang di `scripts/` agent: push pertama lazy-fetch sekali, push 2-24
   masing-masing ~10 detik. 24 klip + metadata + README semua sukses.
6. Prioritas render topik terkuat dulu: logika-vs-perasaan → empati-rosul
   → pemimpin-bodoh → penutup → curhat-wendi → dst (urutan lengkap di
   metadata.json).

---

# ADDENDUM SESI-17 (video sesi-16: "JADI IMAM SHOLAT GAMAU, KENAPA JADI PRESIDEN REBUTAN?! | RADIO BAHLUL" — C8 Podcast)

> Sesi agent menjalankan alur §13 end-to-end setelah sandbox reset (kit diambil
> dari repo via zip + upload/ mount, pola §33). Dua pekerjaan besar dalam satu
> sesi: (1) UPGRADE KIT ke v1.1 (badge source, visual) per permintaan user,
> (2) 20 klip full-coverage 0-3325.05s selesai render + QA + upload. Temuan
> paling penting: §38 (render crash = disk) dan §39 (upload file besar).

## 36. Pemulihan & operasional transkrip sesi ini

1. Pemulihan §33 terkonfirmasi lagi: zip repo + `cp -a upload/ofc-clip-kit/
   whisper.cpp` + `npm ci` (8 dtk) + `tar xzf upload/clip-kit-cache.tar.gz
   node_modules/.remotion` + bootstrap skip-semua = total ~5 menit.
2. Video 3325.05s (55:25) 720p **CFR 50fps ASLI** (full-scan 166.249 paket:
   100.000% grid 1/50s) → tanpa re-encode. loader.to 855MB sekali jalan
   (ter-rename SEBELUM tool call mati — selalu ffprobe dulu, §8).
3. Kalibrasi whisper 0.90x → part-len 460 → 8 bagian. **Bagian 6 dua kali
   kebablas limit 10 menit** (load CPU sandbox naik-turun, kecepatan whisper
   per sesi TIDAK konstan — kalibrasi awal hanya patokan). Solusi baru yang
   terbukti: **split paruh** — potong wav bagian jadi 2 paruh (overlap 2s),
   whisper masing-masing paruh (~5 menit, muat di satu panggilan), gabung
   dengan aturan titik-tengah overlap (A: start < mid, B: start >= mid,
   waktu B digeser +mid-1). Skrip eksternal agent:
   `/home/z/my-project/scripts/part-split.mjs` (init|half|join). Hasil merge
   akhir tetap dicek seperti biasa (mono, 0 back-jump).
4. Merge 8 bagian = 8.665 kata mono 0 back-jump. §30 (bersihkan cache parts
   lama SEBELUM init) tetap WAJIB.
5. 20 klip full-coverage ucapan 0-2024 + 2110.95-3325.05 (iklan read Dilan
   Macak 2024-2110.95 di-SKIP, preseden §23.2); semua batas ujung kalimat
   via words-around; durasi 88-243 dtk.

## 37. UPGRADE KIT v1.1 (diminta user: "source:" + visual lebih bagus)

Perubahan yang masuk zip kit terbaru (semua tervalidasi TSC + QA piksel +
review VLM 8-9/10 sebelum dipakai produksi):

1. **Badge `source: <channel>`** pojok kiri-bawah — komponen baru
   `src/components/SourceBadge.tsx` (chip frosted + ikon play segitiga CSS
   murni, tanpa glyph font = bebas tofu). Nama channel mengalir:
   `render-inputs/clips.json` field `sourceChannel` → build-clips.mjs →
   `out/data/*.json` → komponen. Kosong = badge hidden otomatis.
2. **Washi tape** (`TapeCorners.tsx`) — 2 strip translucent menyilang tepi
   atas kartu, dirender DI LUAR kartu (wrapper terpisah dari div
   overflow-hidden) supaya boleh menjorok keluar tepi kartu.
3. **Watermark jadi chip pill** + titik aksen kuning; **progress bar pindah
   ke bawah** (pill + head dot kuning ala story IG, `position: 'bottom'`);
   **animasi intro** kartu (scale 0.962 + rise, spring — tanpa fade opacity
   supaya frame pertama tidak gelap); **subtitle pindah ke area kertas**
   (centerY 0.595 -> 0.71, sepenuhnya di bawah kartu — VPM merekomendasikan,
   tidak lagi menumpuk tepi kartu); VIDEO.centerY 0.44 -> 0.465;
   WATERMARK.top 84 -> 170 (ritme vertikal seimbang).
4. Semua nilai di `src/config.ts` (single source of truth); README kit
   di-update; versi package.json 1.1.0.
5. **QA visual upgrade wajib sebelum produksi**: render still via
   `qa-frames.mjs <id-test>` (buat data uji manual dari demo-words + video
   asli + sourceChannel), lalu cek piksel per elemen (script eksternal
   `scripts/qa_upgrade_check.py`) + 1-2 putaran review VLM
   (`z-ai vision -i frame.png`). Iterasi VLM: subtitle overlap -> geser
   centerY; spacing kurang seimbang -> fine-tune watermark/cardY.

## 38. PENTING: render crash "Target closed / Compositor SIGTERM" = DISK /tmp, bukan bug video

Gejala: satu klip (clip-13) gagal render 5+ percobaan, selalu mati di
frame tertentu (~35-55% segmen 0), error campuran "Protocol error
(Page.bringToFront): Target closed" + "Compositor quit with signal SIGTERM"
+ proxy 500 pada `?time=<t>`. Diagnosa keliru yang BUKAN penyebab:
- sumber video zona itu (ffmpeg extract frame OK, dan mini-klip 5 dtk
  yang MELINTASI zona itu render sempurna)
- memori (3.2GB bebas), timeout Remotion (sudah dinaikkan tanpa efek)

**Penyebab sebenarnya: disk /tmp mepet (~1.7GB bebas).** Render
concurrency 2 menaruh bundle (~830MB) + assets compositor (~800MB/proses)
di /tmp — makin sempit disk, makin cepat compositor mati diam-diam.
Fix yang terbukti: **bereskan disk sampai >=2.5GB** (hapus salinan lokal
klip yang SUDAH ter-upload §34.4, /tmp/remotion-*, out/tmp/finalize)
→ render langsung jalan normal sekali coba. Setelah itu: hapus klip lokal
otomatis begitu upload OK (sudah ditambahkan ke finish-one.sh agent).
Urutan diagnosa untuk sesi berikutnya: (1) df -h, (2) mini-klip uji di
zona crash, (3) baru curiga video/Remotion.

## 39. PENTING: upload file besar — git plumbing MATIKAN untuk repo sebesar ini; Contents API + CRF 26

Repo sudah ±550MB per sesi × 16 sesi. Yang terjadi di sesi ini saat coba
git plumbing (gh-push-session varian §32):

1. `git push` pada partial clone (blob:none) memicu **lazy-fetch SEMUA blob
   repo** (bukan sekadar delta-base): work dir bengkak 6.7-7.6GB → ENOSPC
   → fetch gagal diam-diam (stderr dibuang `2>/dev/null`, exit 128, LOG
   KOSONG — hati-hati mendiagnosa).
2. `GIT_NO_LAZY_FETCH=1` bikin `read-tree` instan (0.002s, 196KB) TAPI push
   tetap butuh verifikasi blob → "fatal: could not fetch <blob> from
   promisor remote". Jalan buntu dua arah — **jangan pakai git plumbing
   lagi untuk upload klip di repo ini**.
3. **Contents API (gh-upload.mjs) = satu-satunya jalur yang jalan**, batas
   empiris: ±40MB OK (39.5MB lolos), 63-92MB gagal 409 "Timed out
   validating the rule" (server-side, konsisten, bukan transient).
4. **Akar masalah ukuran: render Remotion default CRF 18 → klip ~3Mbps =
   0.4MB/s** (clip 100s = 40MB, clip 243s = 92MB). Fix permanen di kit:
   `renderMedia({crf: 26})` di render-segments.mjs (HATI-HATI: nama opsi
   `crf`, BUKAN `x264Crf` — salah nama = diam-diam diabaikan). Hasil: klip
   20-40MB langsung dari render, QA piksel kuning tetap LULUS.
5. Klip yang SUDAH kebesaran: re-encode `ffmpeg -crf 26 -preset medium`
   (243s = 39.3MB, terverifikasi). **`-preset veryfast` PATOLOGIS di CPU
   sandbox ini** (30 dtk video >5 menit encode, penyebab tidak ketemu;
   `medium` justru normal 0.3-0.43x realtime) — SELALU pakai medium.
6. Pipe `cmd | tail -N; echo $?` MENGEMBALIKAN exit code tail, bukan cmd —
   skrip upload/push harus log ke file (`> log 2>&1`) lalu `echo $?`.

## 40. Pola operasional rantai yang terbukti (20 klip dalam ~5 jam)

- Skrip agent `/home/z/my-project/scripts/`: `clip-cycle.sh` (usang, tergantikan),
  `finish-one.sh` (finalize → QA 3 titik + auto cek tetangga LOW → upload →
  bersih-bersih + HAPUS klip lokal setelah upload OK), `chain.sh <id-selesai|->
  <id-berikut>` (finalisasi klip A + langsung mulai render klip B dengan sisa
  waktu panggilan tool; marker `out/segments/.clip-id` mencegah reset segmen
  saat panggilan ulang — JANGAN rm -rf out/segments tanpa cek marker).
- Rata-rata: klip 100-243 dtk = 2-3 panggilan render + 1 panggilan chain.
  QA LOW di 5 klip semuanya micro-pause (§20.6 ke-N kalinya) — cek tetangga
  otomatis di finish-one.sh, semua LULUS tanpa intervensi.
- Prioritas render topik terkuat dulu (§11): imam-sholat-presiden (judul) →
  keadilan → circus-and-bread → pemimpin-bodoh-akhir-zaman → sirkel-F → dst.

# ADDENDUM SESI-18 (video sesi-17: "#ngopenk OBROLAN SERIUS YANG SEDIKIT ABSURD BERSAMA INDRA FRIMAWAN!" — Tirta PengPengPeng)

> Dua pekerjaan satu sesi lagi: (1) UPGRADE KIT v1.2 per permintaan user
> ("bakground lebih baik seperti kertas saja, ambil dari stock gratis online,
> dan reposition") + push zip pengganti, (2) 11 klip full-coverage 0-1137.4s
> selesai render + QA + upload.

## 41. UPGRADE KIT v1.2 — background kertas stock + reposition

1. **Pemulihan §33 masih valid** (~2 menit): zip repo → cp -a whisper.cpp
   (model 487MB ada di ROOT whisper.cpp, BUKAN models/ — SDK @remotion/
   install-whisper-cpp mencarinya di root; salin dua-duanya aman) → npm ci
   → tar chrome → bootstrap skip semua.
2. **Cari tekstur stock gratis** — urutan yang terbukti sesi ini:
   - z-ai image-search: upstream DOWN (400 Bad Request konsisten) — jangan
     buang waktu lama, langsung fallback
   - Wikimedia Commons: API jalan TAPI upload.wikimedia.org kena 429
     rate-limit IP (semua file 2KB HTML error) — CDN-nya diblok, bukan API
   - rawpixel.com langsung: 403 Cloudflare
   - **Openverse API JALAN**: `api.openverse.org/v1/images/?q=paper+texture
     &size=large&license_type=commercial` → JSON lengkap, preview
     rawpixel CC0 editor_1024 bisa di-curl langsung (6 kandidat sekaligus)
   - **YouTube oEmbed** (`youtube.com/oembed?url=...&format=json`) =
     cara tercepat dapat JUDUL + NAMA CHANNEL (author_name) tanpa yt-dlp —
     berguna utk field sourceChannel; jangan bergantung web-search (juga
     429/400 sesi ini)
3. **Preview 1024px cukup tajam** utk kanvas 1080x1920 dengan trik
   mirror-tile: Lanczos scale ke LEBAR 1080 (1.055x saja), lalu tile
   vertikal dgn flip-top-bottom bergantian (sambungan tak terlihat utk
   serat kertas stokastik). JANGAN object-fit: cover dari 1024x536
   (= stretch 3.5x). Skrip olah: scripts/make-paper-v2.py (agent);
   provenance+lisensi WAJIB dicatat di public/textures/paper-source.txt.
4. Pemilihan kandidat: contact sheet PIL + 1 putaran VLM ("pilih kandidat
   terbaik utk backdrop") — efektif & murah. Kandidat terpilih: kertas
   kraft oatmeal hangat (serat organik, bersih).
5. Reposition v1.2 (semua di config.ts): SOURCE badge pindah KIRI-bawah →
   **KANAN-bawah** (pojok kiri dipakai UI username/caption TikTok/Reels);
   VIDEO.centerY 0.465→0.455; SUBTITLE.centerY 0.71→0.70; WATERMARK.top
   170→156; PAPER.color #F1EBDD→#C9C2B7 (match tekstur baru) + vignette
   0.55→0.42 (tekstur asli sudah punya depth). SourceBadge.tsx: left→right.
6. QA visual upgrade (wajib sebelum produksi, pola §37.5): qa-make-test.mjs
   (BARU di kit) — slice 45s video asli + whisper + parsing persis
   transcribe.mjs (tokenLevelTimestamps + offsets ms + merge token) →
   out/data/qa-style-test.json; qa-frames render f0/15/60/240/900; cek
   piksel (tekstur semua zona, kuning kata aktif, scan chip kanan-bawah
   x580-1030 y1804-1858); VLM grid 3 frame → 8.5/10 LULUS.
   CATATAN: qa-frames.mjs pakai bundle lama kalau .remotion-bundle/ masih
   ada — SETELAH ubah style, HAPUS .remotion-bundle dulu supaya re-bundle.
7. Zip v1.2: JANGAN lupa public/fonts/ (Poppins) + CATATAN-REVISI.md —
   zip lama berisi keduanya; diff namelist zip lama vs baru sebelum push
   (scripts agent: diff namelist python zipfile). Scan token ketat
   `github_pat_[A-Za-z0-9_]{20,}` → push pengganti via gh-upload.mjs ✓.

## 42. loader.to sesi ini: koneksi mati diam-diam — bukan bug script

- Gejala: 3x proses download (node & curl) mati tanpa error di 90-151MB;
  pola ±75-100 detik per koneksi. Server savenow.to TIDAK dukung Range
  (GET Range diabaikan → stream penuh dari byte 0; resume mustahil).
- Solusi yang jalan: **buat sesi download BARU** (ajax/download.php lagi)
  → dapet server acak (leo3 mati di 151MB; **emma18** lolos full 159MB).
  Kalau mati lagi, ulangi start sampai kena server yang seumur hidup.
- TIP Diagnosis: `curl -D - -o /dev/null -H "Range: bytes=0-1023" <url>`
  dengan timeout — kalau hang/streaming penuh = server abaikan Range.
  Jangan tarik kesimpulan dari `alive=0` saja: **cek dulu ukuran file vs
  bitrate** — sesi ini curl "keluar" karena file SELESAI (159,109,120
  bytes = 1143.33s x 1.11Mbps persis), bukan mati. ffprobe .part dgn
  moov di depan langsung kasih durasi penuh.
- Video 1143.33s 720p **CFR 24fps asli** (27.439 paket 0 error) — tanpa
  re-encode. Whisper 0.94x → part-len 420 → 3 bagian (aman < 10 menit,
  tidak perlu split paruh §36.3). Merge 2.797 kata mono 0 back-jump.

## 43. Operasional 11 klip (rantai §40 dipakai ulang)

- 11 klip full-coverage ucapan 0-1137.4s, semua batas ujung kalimat via
  words-around; durasi 55-172.5 dtk. Prioritas render: vo2max (judul
  kuat) → dokter-memangsa → breakup-gym → dst (urutan lengkap di
  metadata.json).
- Skrip agent chain dibuat ulang (sandbox fresh): scripts/finish-one.sh
  (finalize → QA 3 titik dgn titik proporsional durasi + auto tetangga
  LOW → upload → bersih + HAPUS klip lokal) & scripts/chain.sh (finish A
  + render B budget sisa waktu; render log → file, tail saja ke stdout).
- Pola panggilan stabil: klip ≤96 dtk selesai 1 panggilan render; klip
  128-172 dtk butuh 2 panggilan (marker .clip-id resume pending). Exit
  -9 di akhir panggilan setelah "semua pending selesai" = timeout tool
  biasa, BUKAN gagal — cek dulu baris terakhir log sebelum ulang.
- QA: hanya clip-06 ada 1 titik LOW, tetangga ±1s semua OK (micro-pause
  §20.6 ke-N kalinya) — upload tetap jalan. clip-08 QA 3/3 langsung OK.
- Upload semua via Contents API (7.4-23.0MB @ CRF 26 — batas §39 aman).
  11 klip + metadata.json + README row terverifikasi di repo.

## 44. Checklist penutupan sesi (semua ✓ sesi ini)

zip kit v1.2 ter-push pengganti ✓ · 11 klip + metadata + README ✓ ·
lokal klip dihapus pasca-upload ✓ · out/tmp/finalize dibersihkan ✓ ·
transcript raw.json dipertahankan utk audit ✓ · PAT tetap hanya di
work/.ghtoken (scan ketat sebelum tiap push) ✓.

---

# ADDENDUM SESI-19 (video sesi-18: "TERNYATA NABI ADA YANG DARI JAWA??" + sesi-19: "KONSPIRASI REZIM & OPOSISI PALSU" — dua-duanya Risyad and Son ft. Pandji & Felix Siauw)

> SATU sesi agent, DUA video selesai total (user: "selesaikan itu secara total,
> kemudian lanjut..."). Sandbox fresh (upload/ mount selamat, pola §33):
> 16 klip sesi-18 + 19 klip sesi-19 = 35 klip render+QA+upload dalam satu sesi.

## 45. REPO BARU clip-sessions-2 — repo lama 5.4GB, PAT bisa bikin repo

- Repo `clip-sessions` sudah **5.4 GB** (di atas batas wajar GitHub 5GB) — user
  eksplisit: "kalau kepenuhan, kamu diperbolehkan membuat repo lagi, bebas".
- PAT fine-grained user TERNYATA punya izin Administration:write —
  `POST /user/repos` langsung jalan: buat `kasyaira/clip-sessions-2` (public).
- Repo baru = struktur mulai sesi-18: folder `sesi-XX-slug/` + metadata.json +
  README.md (tabel sesi) + CARA-KERJA.md + ofc-clip-kit.zip (semua file kecil).
- `gh-upload.mjs` + `gh-push-big.sh` di kit lokal di-arahkan ke repo baru via
  `sed` satu baris (REPO constant). Di repo BARU yang kecil, git plumbing
  (gh-push-big.sh) JALAN MULUS lagi untuk file >40MB (§39 untuk repo lama
  5.4GB tidak berlaku di sini) — Contents API tetap jalur utama <40MB.

## 46. BUG skrip agent finish-one.sh v1: klip "hilang" setelah render selesai

Gejala: render klip selesai → chain memanggil finish-one → kelihatannya
jalan, tapi klip TIDAK ter-upload dan out/clips KOSONG. Akar (dua bug):
1. Guard `[ -f out/clips/<id>.mp4 ] || exit 2` SALAH — hasil render-retry itu
   SEGMENT di out/segments/, file final justru DIBUAT oleh finalize-clip.mjs
   yang dipanggil finish-one. Guard harus: kalau final belum ada, cek segmen.
2. `node ... | tail -3` menelan exit code (§39.6 persis — berlaku juga untuk
   skrip agent sendiri, bukan cuma skrip kit).
Akibat: 1 klip harus render ulang 30 menit (segmen sudah ke-reset oleh chain
berikutnya). FIX sudah masuk finish-one.sh v2: finalize idempoten (skip kalau
out/clips/<id>.mp4 sudah ada = resume), semua log ke FILE dulu baru tail.

## 47. Catatan operasional dua video ini

1. Pemulihan §33 standar (~1 menit): zip repo + cp -a whisper.cpp + npm ci
   + tar chrome + bootstrap skip-semua.
2. **Bahan 1** (sesi-18): 2395.87s 720p CFR 60fps asli (143.748 paket sorted
   100% on-grid) → tanpa re-encode. Whisper kalibrasi 1.03x TAPI bagian 0
   kebablas 10 menit (load CPU fluktuatif, §36.3 terulang) → split paruh
   part-split.mjs utk bagian 0 saja; bagian 1-5 full normal (0.9-1.1x).
   Merge 6.435 kata mono 0 back-jump.
3. **Bahan 2** (sesi-19): 2383.5s 720p CFR 60fps asli → tanpa re-encode.
   Kalibrasi 1.18x → part-len **360** (bukan 460) = 7 bagian SEMUA jalan
   full tanpa split (370-380s/bagian, muat di 590s timeout). Pelajaran:
   kalau kalibrasi >1.1x, turunkan part-len supaya margin vs fluktuasi.
4. Bahan 1 skip: jingle musik 247-266s + promo PUTBAL comedy show 1041-1310s
   (preseden §23.2). Bahan 2 full-coverage murni tanpa skip.
5. Batas klip semuanya di ujung kalimat persis via words-around (2-3 putaran
   verifikasi per video). Durasi klip 52-266s; klip >243s (klip-02 sesi-18
   266s = topik judul) sengaja tidak dipecah — topik padu, render 3 panggilan.
6. QA LOW total 4 klip (05/08/02/10) — SEMUA micro-pause setelah cek tetangga
   rapat ±1-4s (§20.6 ke-N kalinya). 2 klip (klip-02+10 sesi-19) uploadnya
   sempat TERTINGGAL karena tool call timeout di tengah finish-one — klip
   final utuh di out/clips, cukup QA+upload manual (selalu cek repo vs
   daftar klip di akhir sesi!).
7. Pola rantai §40/§43 stabil: klip ≤100s = 1 panggilan render; 120-180s =
   1-2 panggilan; >200s = 2-3 panggilan. Rata-rata chain (finish+render
   berikutnya) 1 panggilan per klip.
8. part-split.mjs SEKARANG IKUT kit (ofc-clip-kit/scripts/part-split.mjs) —
   sesi berikutnya tidak perlu tulis ulang (dulu eksternal agent §36.3).

## 48. Checklist penutupan sesi (semua ✓ sesi ini)

35 klip ter-upload (16+19) ✓ · metadata.json 2 sesi ✓ · README.md repo baru
(tabel sesi 18-19) ✓ · CARA-KERJA.md addendum ini ✓ · zip kit v1.2 refresh
(+ part-split.mjs) + scan token ketat `github_pat_[A-Za-z0-9_]{20,}` kosong ✓
· cache-pack + kode disimpan ulang ke upload/ (layout §29) ✓ · PAT tetap
hanya di work/.ghtoken ✓.

---

# ADDENDUM SESI-20 (video sesi-20: "Saatnya GuruGembul DiGeprek Ade Rai ‼️" — GEMBULIKUM)

> SATU sesi agent end-to-end setelah sandbox reset: pemulihan §33 (~2 menit),
> lalu 15 klip full-coverage 0-2108.0s (35:08) render + QA + upload SEMUA selesai
> dalam satu sesi tanpa jalan buntu baru. Video Guru Gembul konsultasi kesehatan
> kembali bersama mentor Ade Rai.

## 49. Catatan operasional sesi ini (semua verifikasi jalan)

1. Pemulihan §33 standar: zip repo + `cp -a upload/ofc-clip-kit/whisper.cpp`
   (model 487MB di root, ikut ter-copy 27 detik) + `npm ci` 5.6 dtk (cache hangat)
   + `tar xzf upload/clip-kit-cache.tar.gz node_modules/.remotion` + bootstrap
   skip-semua + re-pack cache 620M dalam 33 dtk.
2. **gh-upload.mjs + gh-push-big.sh di zip kit masih REPO='clip-sessions' (lama)** —
   sesi sebelumnya cuma sed-nya lokal, tidak masuk zip. WAJIB sed ulang ke
   'clip-sessions-2' setiap fresh extract dari zip repo (cek §45 masih perlu).
3. Video 2108.08s (35:08) 720p **CFR 30fps ASLI** (full-scan 63.240 paket sorted:
   100.000% on-grid 1/30s) → tanpa re-encode. loader.to 161MB sekali jalan
   (tool call timeout SETELAH file ter-rename — ffprobe dulu, §8 ke-N kalinya).
4. Kalibrasi whisper 0.93x → part-len **420** (margin vs fluktuasi CPU, §47.3)
   → 6 bagian SEMUA jalan full tanpa split-paruh → merge **5.356 kata** mono
   0 back-jump. §30 (bersihkan parts lama) tetap dijalankan sebelum init.
5. **Alat bantu batas klip baru (agent, `/home/z/my-project/scripts/boundary-helper.mjs`)**:
   transkrip whisper untuk dialog cepat 2 orang sering TANPA tanda baca sama
   sekali di zona jam-jam tertentu → kandidat batas dicari dengan DUA kriteria:
   (a) kata berujung [.?!] ATAU (b) jeda hening >= 0.45s, jendela ±18s dari
   target, konteks 9 kata sebelum/4 sesudah. Zona tanpa keduanya → dump
   `words-around.mjs <t> 10` dan pilih manual di aliran kata. Trik cepat:
   cari timestamp kata kunci topik ("fatty", "tabungan", "gojek", "ketogenics",
   "kantin", "likepress") dulu untuk peta topik, baru perhalus batas.
6. 15 klip full-coverage 0-2108.0s TANPA skip (dialog padat sejak detik 0),
   semua batas di titik natural (punct / hening / pergantian topik):
   0-136.1 / 136.1-319.79 / 319.79-441 / 441-580 / 580-687 / 687-822 /
   822-985.54 / 985.54-1068.84 / 1068.84-1263.92 / 1263.92-1444.64 /
   1444.64-1558.64 / 1558.64-1660.39 / 1660.39-1793.96 / 1793.96-1911.93 /
   1911.93-2108. Durasi 83-196 dtk (4 klip >180s by design, topik padu).
7. Rantai render §40 dipakai penuh: `render-one.sh` (marker resume) +
   `finish-one.sh` (finalize idempoten → QA 3 titik proporsional → auto cek
   tetangga LOW → upload → HAPUS klip lokal → bersih segments/tmp) +
   `chain.sh <A> <B>`. Klip 107-196 dtk = 2-3 panggilan per klip. Rata-rata
   chain 1 panggilan/klip. Exit -9 setelah "semua pending selesai" = normal.
8. QA piksel: 4 klip ada 1 frame LOW (11/05/09/13) — SEMUA micro-pause
   terkonfirmasi via tetangga ±1.5s OK otomatis (§20.6 ke-N kalinya).
9. Upload SEMUA lewat Contents API @ CRF 26 (ukuran 15-29MB, batas §39 aman).
   15 klip + metadata.json + README row + CARA-KERJA.md + zip kit refresh.
10. Prioritas render topik terkuat dulu (§11): badan-bagus-korupsi (jembatan
    finansial-genjang) → sugar-crash-roller-coaster → latihan-kaki-7-hari →
    makanan-pertama → puasa-jendela-8-jam → dst (urutan lengkap di metadata).

## 50. Checklist penutupan sesi (semua ✓)

15 klip ter-upload ✓ · metadata.json sesi-20 ✓ · README.md repo +baris sesi-20 ✓ ·
CARA-KERJA.md addendum ini ✓ · zip kit refresh + scan token ketat
`github_pat_[A-Za-z0-9_]{20,}` kosong ✓ · cache-pack 620M + kode ke upload/
(layout §29) ✓ · PAT tetap hanya di work/.ghtoken ✓.

---

# ADDENDUM SESI-21 (video sesi-21: "Benarkah Agama Menghambat Sains? - Felix Siauw")

> SATU sesi agent end-to-end setelah sandbox reset: pemulihan §33 (~2 menit),
> lalu 13 klip full-coverage 0-1415.08s (23:35) render + QA + upload semua
> selesai. Permintaan BARU user mulai sesi ini: NAMA FILE SPASI.

## 51. Penamaan file SPASI (permintaan user sesi-21, permanen)

User: 'nama file jadi "contoh nama file.mp4" saja kalau bisa, bukan
"contoh-nama-file.mp4", kalau gabisa gapopa'. Implementasi yang terbukti
mulus di sesi ini: **ID klip lokal TETAP hyphen** (out/data, out/clips,
marker, log — semua tooling aman dari quoting bug), HANYA nama file REMOTE
saat upload yang di-spasi-kan: `REMOTE_NAME="${ID//-/ }"` di finish-one.sh
→ repo jadi `sesi-21-.../clip 08 ayat pertama iqro.mp4`. Semua 13 klip +
metadata (field "file" per klip) konsisten memakai spasi; gh-upload.mjs
sudah encodeURI otomatis. SARAN: sesi berikutnya ikut pola yang sama.

## 52. Bug BARU: whisper token-timestamp mundur DI TENGAH bagian (bukan sambungan)

Merge sesi ini dua kali non-mono padahal sambungan bagian bersih:
- Gejala: run 7 kata (75.96-78.93s) punya timestamp MUNDUR berurutan
  ('Tapi' 75.96-73.73, 'percaya' 73.73-69.82, dst) = artefak token-level
  whisper 'small' (halusinasi pada speech cepat), BUKAN bug merge.
- Fix terverifikasi: skrip agent `scripts/fix-monotonic.py` — deteksi run
  non-monotonik (start < prev.end ATAU end < start), INTERPOLASI linear
  antara kata baik terakhir sebelum run dan kata baik pertama sesudah run
  (slot = rentang/n-kata, min durasi 0.05s). Sesi ini: 2 run diperbaiki
  (7 kata + 1 kata), hasil 3.097 kata 0 back-jump. Idempoten: kalau sudah
  mono, tidak mengubah apa pun.
- PENTING: cek `merge` output "mono=false" TIDAK selalu berarti sambungan
  bagian — dump kata di zona back-jump dulu; kalau timestamp-nya mundur
  BERURUTAN di dalam satu bagian → pakai fix-monotonic.py, JANGAN
  geser split-point (bakal sia-sia).

## 53. Catatan operasional sesi ini (semua terverifikasi jalan)

1. Pemulihan §33 standar ~2 menit: zip repo (clip-sessions-2, REPO const
   SUDAH benar — §49.2 fix sudah masuk zip) + `cp -a upload/ofc-clip-kit/
   whisper.cpp` + `npm ci` 6 dtk + tar chrome 11 dtk + bootstrap skip-semua.
   Catatan: part-split.mjs TIDAK ada di zip repo (hilang saat zip sesi-20)
   — disalin dari upload/ofc-clip-kit/scripts/, dan dimasukkan lagi ke
   zip refresh akhir sesi ini.
2. Video 1415.08s (23:35) 720p **CFR 23.976fps ASLI** (33.927 paket sorted:
   100.000% on-grid) → tanpa re-encode. loader.to: koneksi pertama MATI
   DIAM-DIAM di 1.4MB & 56MB (§42 terulang) — skrip agent baru
   `scripts/dl-retry.sh` (monitor pertumbuhan .part tiap 10 dtk, kill &
   sesi baru saat stall 30 dtk) lolos full 119MB sekali jalan di attempt
   berikutnya. WAJIB pakai wrapper ini untuk download berikutnya.
3. Kalibrasi whisper 0.86x → part-len 420 → 4 bagian semua jalan full
   (374s/370s/373s/161s) → merge 3.097 kata (setelah fix §52).
4. 13 klip full-coverage TANPA skip, semua batas di ujung kalimat natural:
   0-118.84 / 118.84-219.67 / 219.67-355.43 / 355.43-428.86 /
   428.86-586.52 / 586.52-726.77 / 726.77-806.34 / 806.34-937.86 /
   937.86-1033.02 / 1033.02-1126.90 / 1126.90-1240.57 / 1240.57-1339.61 /
   1339.61-1415.08. Durasi 73-158 dtk.
5. Rantai §40 dipakai penuh (render-one/finish-one/chain agent, log ke file
   + tail, marker .current-clip). Klip 73-158 dtk = 1-2 panggilan render.
   Exit -9/255 setelah "SELESAI OK"/"semua pending" = normal (§31.8/§43).
   Satu insiden: typo id klip di argumen chain ("diangkat" vs "dianggap")
   → render-one reset segmen + tulis marker id-salah; untung data tidak
   ada → exit 1 tanpa efek samping. PELAJARAN: selalu copy-paste id dari
   out/data/ ls, jangan ketik manual.
6. QA piksel: clip-03/06/10 ada frame LOW (42-51 piksel, dekat threshold)
   — SEMUA micro-pause/jeda hening (tetangga ±1.5s OK 3.5k-18k piksel,
   §20.6 ke-N kalinya); verifikasi silang kata di transkrip (frame jatuh
   di sela kata/frasa). 6 klip QA LULUS langsung.
7. Upload semua via Contents API @ CRF 26 (8.4-17.8MB, batas §39 aman),
   13 klip + metadata + README row.
8. Prioritas render topik terkuat dulu: ayat-pertama-iqro (judul) →
   islam-dianggap-penghambat → khawarizmi-ibn-rushd → dark-ages →
   biruni-haitham-khaldun → pertanyaan → kiblat → neoplatonis → dst.
9. finish-one.sh v1 sesi ini MENIMPA log tiap run (`>` bukan `>>`) —
   log QA klip yang di-retry jadi hilang. Diperbaiki untuk sesi berikutnya:
   gunakan `>>` setelah baris header `>`.

## 54. Checklist penutupan sesi (semua ✓)

13 klip ter-upload ✓ · metadata.json sesi-21 (format sesi-20 + field "file"
spasi) ✓ · README.md +baris sesi-21 ✓ · CARA-KERJA.md addendum ini ✓ ·
zip kit refresh (+part-split.mjs kembali, +fix-monotonic.py &
dl-retry.sh & boundary-helper.mjs di scripts agent — 3 skrip itu eksternal
kit, disalin manual sesi berikutnya kalau perlu) + scan token ketat
`github_pat_[A-Za-z0-9_]{20,}` kosong ✓ · PAT tetap hanya di
work/.ghtoken ✓.

---

# ADDENDUM SESI-22 (video sesi-22: "GJ 161 | JADI WANTIMPRES, ROCKY GERUNG JADI PENJILAT PRABOWO?" — guru gembul)

> SATU sesi agent end-to-end setelah sandbox reset: pemulihan §33 (~2 menit),
> 13 klip full-coverage 0-1569.45s (26:09) render + QA + upload semua selesai.
> PERMINTAAN USER BARU & PERMANEN mulai sesi ini: nama file TANPA NOMOR URUT
> (lihat §55 — user eksplisit minta aturan ini disimpan di file ini "agar
> tidak pernah salah menamai file").

## 55. ATURAN NAMA FILE PERMANEN (permintaan user sesi-22) — WAJIB SETIAP SESI

Evolusi aturan penamaan (jangan tertukar antar versi):

| Versi | Format | Contoh | Status |
|---|---|---|---|
| s/d sesi-20 | hyphen + nomor | `clip-01-judul-topik.mp4` | USANG |
| sesi-21 (§51) | spasi + nomor | `clip 01 judul topik.mp4` | USANG |
| **sesi-22+ (§55)** | **spasi, TANPA nomor urut** | **`judul topik.mp4`** | **BERLAKU (default)** |
| sesi-27 (§70) | mode "part": `part N - topik.mp4` | `part 2 - tepe salah baca setengah enam jadi jam enam.mp4` | KONDISIONAL — hanya kalau user minta eksplisit utk konten yang bakal banyak dicari |

Aturan lengkap §55:
1. **ID klip lokal** = slug topik murni TANPA prefix `clip-NN` (contoh:
   `gaji-wantimpres-naik-lima-kali-lipat`). Dipakai di out/data, out/clips,
   marker, log — tooling aman quoting karena tetap hyphen (pola §51 dipertahankan).
   `build-clips.mjs` menerima id apa pun yang cocok `^[a-zA-Z0-9._-]+$`
   (angka boleh kalau memang bagian topik, mis. `...-2029`).
2. **Nama file REMOTE** = ID dengan hyphen diganti spasi:
   `REMOTE_NAME="${ID//-/ }"` di finish-one.sh → `gaji wantimpres naik lima
   kali lipat.mp4`. TANPA `clip NN` di depan.
3. **Urutan klip TIDAK PERAH ada di nama file** — hanya di `metadata.json`
   per sesi: field `urutan` (array nama file urut tonton) + array `clips`
   yang memang urut waktu. README repo TIDAK menampilkan nomor klip.
4. Nama topik harus MENGGAMBARKAN ISI (bisa panjang): jangan generik
   ("bagian 3"), pakai frasa punchy dari isi klip.
5. Skrip rantai (render-one/finish-one/chain) SUDAH mengimplementasikan ini
   dan SEKARANG IKUT KIT (scripts/ kit) — tidak perlu ditulis ulang tiap sesi;
   cukup copy dari kit ke /home/z/my-project/scripts/ kalau mau path agent.

## 56. dl-retry.sh bug lama ketemu: path relatif ENOENT setelah cd internal

Gejala: 12 attempts langsung gagal, `work/dl-retry.log: No such file or
directory` + node ENOENT `work/raw-new.mp4.part`. Akar: loop skrip melakukan
`cd /home/z/my-project/ofc-clip-kit` tapi LOG (relatif) dan OUT (relatif)
dihitung dari CWD LAMA → setelah attempt pertama semua path rusak. Fix
(sudah masuk kit): `OUT="$(readlink -f "$OUT")"` + LOG absolut
`/home/z/my-project/work/dl-retry.log`. Pelajaran umum: skrip yang cd di
tengah jalan WAJIB absolut-kan semua path di header.

## 57. Insiden finish-one dobel: guard frame-count menyelamatkan — SELALU cek repo dulu

Pola kejadian: panggilan chain (finish A + render B) ke-timeout SETELAH
selesai semua kerjanya (exit -9, §53.5). Karena output kepotong, terlihat
seperti finish A belum jalan → agent jalanin `finish-one A` manual LAGI.
Apa yang terjadi & kenapa AMAN:
- Klip A SUDAH ter-upload & lokalnya dihapus oleh run pertama.
- Run manual: out/clips kosong → guard `ls out/segments/seg-*.mp4` lolos
  (karena segments sekarang milik klip B!) → finalize-clip MENOLAK dengan
  "jumlah frame tidak cocok (target A ≠ segmen B)" → exit 3, tidak ada file
  salah yang ter-upload. Guard frame-count = pertahanan TERAKHIR yang bekerja.
- ATURAN: setelah chain timeout, JANGAN langsung ulang finish-one — cek dulu
  (a) baris `SELESAI OK` di out/finish-<id>.log, (b) daftar file di folder
  sesi repo via API. finish-one re-run MENIMPA log lama (header `>`), jadi
  log bukan bukti kalau sudah ke-timpa — repo sumber kebenaran.
- Bonus kecil: log progress Remotion penuh `\r` (satu baris panjang) —
  filter stdout pakai `tr '\r' '\n' | grep -vE '^\[segmen\] *([0-9]+%|bundle)'`.

## 58. Catatan operasional sesi ini (semua terverifikasi jalan)

1. Pemulihan §33 standar ~2 menit: zip repo-2 (REPO const benar) + cp -a
   upload/ofc-clip-kit/whisper.cpp (model 487MB ikut, 27 dtk) + npm ci 6 dtk
   + tar chrome + bootstrap skip-semua (re-pack cache 620M 33 dtk).
2. Video 1569.45s (26:09) 720p **CFR 30fps ASLI** — full-scan 47.080 paket
   sorted: gap 0.033333s (66.7%) + 0.033334s (33.3%) = 100% grid 1/30s
   (dua nilai itu rounding 6-desimal dari 1/30 yang sama — JANGAN baca
   sebagai VFR; cek paksa skrip agent `check-cfr.py`, hapus prefix `packet,`
   dari csv ffprobe, dan hitung gap dengan toleransi).
3. loader.to 260MB sekali jalan via dl-retry (setelah fix §56).
4. Kalibrasi whisper 0.99x → part-len **420** (aturan §47.3: kalau >0.95x
   turunkan dari saran 460 supaya margin vs fluktuasi CPU) → 4 bagian SEMUA
   jalan full tanpa split-paruh → merge **3.789 kata** mono 0 back-jump
   (fix-monotonic.py tidak diperlukan).
5. 13 klip full-coverage TANPA skip, semua batas ujung kalimat persis via
   boundary-helper (punct ATAU gap>=0.45s, §49.5): 0-75.65 / 75.65-160.32 /
   160.32-310.18 / 310.18-441.67 / 441.67-525.67 / 525.67-679.96 /
   679.96-749.96 / 749.96-900.75 / 900.75-1062.32 / 1062.32-1148.47 /
   1148.47-1336.72 / 1336.72-1501 / 1501-1569.45. Durasi 68-188 dtk
   (sebut-satu-satu 188s by design: daftar nama satu tarikan napas, preseden
   §49.6 klip >180s topik padu).
6. Rantai §40 dipakai penuh dengan skrip KIT (baru, §55.5): render-one
   (marker .current-clip) + finish-one (QA 3 titik proporsional + auto
   tetangga LOW + upload nama-spasi-tanpa-nomor + hapus lokal) + chain.
   Klip 68-86 dtk = 1 panggilan; 131-188 dtk = 2 panggilan. QA LOW semua
   micro-pause (tetangga OK otomatis, §20.6 ke-N kalinya).
7. Upload SEMUA via Contents API @ CRF 26 (10.0-28.7MB, batas §39 aman).
   13 klip + metadata + README row terverifikasi di repo.
8. Prioritas render topik terkuat dulu: tidak-pernah-mengkritik-prabowo
   (inti tuduhan video) → jadi-pejabat-itu-tidak-dosa → yang-dihujat-dulu-
   jadi-atasannya → mesin-2029 → gaji-5x → dst (urutan lengkap di metadata).
9. metadata.json sesi-22 menambah field `urutan` eksplisit (array nama file
   urut tonton) — jaga field ini di sesi berikutnya.

## 59. Checklist penutupan sesi (semua ✓)

13 klip ter-upload ✓ · metadata.json sesi-22 (+field urutan) ✓ · README.md
+baris sesi-22 + catatan aturan nama baru ✓ · CARA-KERJA.md addendum ini
(§55 = aturan nama permanen sesuai permintaan user) ✓ · zip kit refresh
(+render-one/finish-one/chain masuk kit, +fix dl-retry §56) + scan token
ketat `github_pat_[A-Za-z0-9_]{20,}` kosong ✓ · cache-pack + kode ke upload/
(layout §29) ✓ · PAT tetap hanya di work/.ghtoken ✓.

---

# ADDENDUM SESI-23 (video sesi-23: "Podcast Keluarga Artis S2 | Ep. 41 – Selesai Podcast, dr. Tirta Langsung Cek Tensi" — Mario Caesar)

> SATU sesi agent end-to-end setelah sandbox reset: pemulihan §33 (~2 menit),
> lalu 29 klip full-coverage render + QA + upload semua selesai — batch
> terbesar sejak sesi-19 (35 klip). User meng-ulang permintaan aturan nama
> file (§55) di pesan tugasnya — sudah dipatuhi tanpa perubahan aturan.

## 60. Catatan operasional sesi ini (semua terverifikasi jalan)

1. Pemulihan §33 standar ~2 menit: zip repo-2 (REPO const benar 'clip-
   sessions-2') + `cp -a upload/ofc-clip-kit/whisper.cpp` (28 dtk, model ikut)
   + `npm ci` 8 dtk + tar chrome + bootstrap skip-semua (re-pack cache 620M).
2. Video 4080.37s (68:00) 720p **CFR 25fps ASLI** (102.007 paket sorted: 100%
   grid 0.04s) → tanpa re-encode. loader.to 734MB sekali jalan via dl-retry
   (attempt 2; attempt pertama koneksi mati — pola §42 standar).
3. Kalibrasi whisper **1.11x** → part-len **380** (aturan §47.3: kalau >1.1x
   turunkan part-len supaya margin vs fluktuasi CPU; saran skrip 434
   DIABAIKAN) → 11 bagian SEMUA jalan full tanpa split-paruh → merge 10.530
   kata.
4. **Merge non-mono = kombinasi §52 + kasus mikro baru**: 3 run diperbaiki
   fix-monotonic.py (2 tumpang-tindih 1 kata + 1 run mundur 6 kata "sekali
   kamu radang nyiritalan" 3112-3135s). Sisa 1 overlap 0.04s antar kata
   bersebelahan ("di"→"katup" — rounding, BUKAN back-jump) → cukup clamp
   manual `start = prev.end`. Pelajaran: setelah fix-monotonic, hitung ulang
   non-mono; overlap <=0.05s antar kata bersebelahan aman di-clamp, jangan
   dianggap artefak.
5. **Preseden SKIP sponsor murni** (perluasan §23.2): podcast ini punya
   sponsor mouthwash yang MENJELMA jadi konten edukasi (gargle, povidon
   iodine, pita suara — SEMUA klip edukasi itu TETAP DIPERTAHANKAN).
   Yang di-skip CUMA dua segmen promo eksplisit: kompetisi "Next Bintang
   Gargle" 3803.96-3845.96s + ad-read outro 4036.67-4080.37s. Batas
   edukasi-vs-promo: penyebutan produk dalam penjelasan mekanisme = edukasi;
   ajakan ikut lomba/CTA beli = promo.
6. 29 klip, durasi 68-210 dtk; 4 klip >180s by design (fat-burn 208.7s,
   jersey 207s, mouthwash 210s, golden-amandel 190.7s — topik padu, preseden
   §49.6). Klip terpendek back-to-back-copenhagen 68.5s (preseden §27.2).
   Rata-rata rantai 1.4 panggilan/klip — paling efisien sejauh ini.
7. **QA piksel: 29/29 klip LULUS 3/3 LANGSUNG — nol frame LOW pertama kali
   dalam sejarah project** (sesi-sesi sebelumnya selalu ada micro-pause
   §20.6). Tidak ada perubahan apa pun di pipeline — kemungkinan karena
   dialog podcast ini padat bicara tanpa jeda mikro.
8. Upload: 28 via Contents API (9.6-26.6MB @ CRF 26); SATU kena 502 →
   fallback otomatis ke Git blob API (§19) sukses — tidak perlu intervensi.
9. Exit -9/255 setelah "SELESAI OK"/"semua pending selesai" terjadi ~8x
   (§31.8/§43/§57 ke-N kalinya) — SELALU cek log finish + daftar file repo
   dulu sebelum ulang apa pun.

## 61. Checklist penutupan sesi (semua ✓)

29 klip ter-upload ✓ · metadata.json sesi-23 (+field urutan, batasKlip
lengkap) ✓ · README.md +baris sesi-23 ✓ · CARA-KERJA.md addendum ini ✓ ·
zip kit refresh (diff namelist vs zip lama: hanya CARA-KERJA.md berubah) +
scan token ketat `github_pat_[A-Za-z0-9_]{20,}` kosong ✓ · cache-pack +
kode disimpan ulang ke upload/ (layout §29) ✓ · PAT tetap hanya di
work/.ghtoken ✓.

---

# ADDENDUM SESI-24 (video sesi-24: "#suaratirta UNGKAP JAWABAN SEPUTAR MITOS & FAKTA KESEHATAN!" — Tirta PengPengPeng)

> SATU sesi agent end-to-end TANPA pemulihan §33 — pertama kalinya working
> copy ofc-clip-kit/ ditemukan utuh dari sesi sebelumnya (model + node_modules
> + chrome + skrip semua masih ada; bootstrap skip-semua 8 dtk). Bahan user
> berganti ke mA-zAGGXmX4; 11 klip Q&A mitos-fakta render + QA + upload semua
> selesai. Aturan nama §55 dipatuhi tanpa perubahan.

## 62. Dua temuan teknis penting sesi ini

1. **Sandbox membunuh SEMUA proses latar saat tool call berakhir — SETSID
   PUN TIDAK SELAMAT.** Gejala: `nohup bash dl-retry.sh ... &` dan
   `setsid nohup ... & disown` dua-duanya mati <10 dtk SETELAH tool call
   peluncurnya selesai (ps kosong, log monitor berhenti). Artinya: dl-retry.sh
   WAJIB jalan di FOREGROUND tool call (timeout 580 dtk), seperti pola yang
   memang selama ini terbukti. Jangan buang waktu coba detach lagi.
2. **Probe URL download sebelum unduh (skrip agent scripts/dl-url-get.mjs)**:
   start session loader.to → poll → print download_url + total ukuran +
   test Range. Tersesat berkah: server savenow ABAIKAN header Range (balas
   200 + body penuh), jadi `arrayBuffer()` pada probe malah mengunduh file
   utuh 68MB — sekalian membocorkan total size tanpa ffprobe. Gunakan utk
   estimasi ukuran SEBELUM memutuskan strategi unduh; kalau >300MB dan
   server abaik Range, siapkan beberapa attempt foreground (tiap tool call
   dapat satu koneksi penuh).

## 63. Catatan operasional sesi ini (semua verifikasi jalan)

1. Bersih artefak stale sesi lama WAJIB sebelum mulai (§30 + out/segments
   + out/data + out/transcripts + render log + public/input/raw.mp4 lama):
   video sesi-23 734MB terhapus → disk 4.5G lega.
2. Video 1457.21s (24:17) 720p **CFR 25fps ASLI** (36.428 paket sorted: 100%
   grid 0.04s) → tanpa re-encode. loader.to 68.15MB attempt-2 (attempt-1
   stall diam-diam §42; wrapper restart bekerja).
3. Kalibrasi whisper 0.87x → part-len **420** (aturan margin §58.4 dipakai
   walau saran skrip 460) → 4 bagian SEMUA jalan full → merge **3.006 kata
   mono 0 back-jump** (fix-monotonic TIDAK diperlukan).
4. **Preseden SKIP baru: sketch komedi intro** (perluasan §23.2/§60.5):
   0-99.42s sketch "tim kami" scripted (bukan iklan, bukan ucapan edukasi)
   di-SKIP; batas edukasi-vs-hiburan: segmen Q&A dr. Tirta = konten;
   banter/komedi peluncur & outro CTA = skip. Outro 1437.04s+ ikut skip.
   Banter transisi antar-pertanyaan (602-629, 708-720, 1076-1086, dsb.)
   juga di-skip — klip mulai persis di kata pertama pertanyaan.
5. **Preseden klip gabungan 2 pertanyaan**: ingus-bangun-tidur (36 dtk, di
   bawah minimum §27.2) digabung dengan pusing-berdiri jadi satu klip tema
   "bangun tidur" 134 dtk (bangun-tidur-beringus-dan-pusing) — sah kalau
   dua pertanyaan satu payung tema.
6. 11 klip 79-153 dtk; klip terpanjang atlet-berhenti-olahraga 153.3 dtk
   (topik padu + bintang: Ronaldo/Rooney/Neymar/Vettel/Ramsey, §49.6).
7. Rantai §40 efisien: 5 dari 10 chain menyelesaikan finish+render dalam
   SATU panggilan (sisa waktu cukup); total 13 panggilan utk 11 klip.
   QA LOW hanya 2 klip (atlet 131.2s, amandel) — semua micro-pause,
   tetangga OK otomatis (§20.6 ke-N kalinya).
8. Upload semua via Contents API @ CRF 26 (9.9-17.9MB, batas §39 aman).
   metadata.json + README row + CARA-KERJA addendum ini + zip refresh.

## 64. Checklist penutupan sesi (semua ✓)

11 klip ter-upload ✓ · metadata.json sesi-24 (urutan + renderPrioritas +
batasKlip) ✓ · README.md +baris sesi-24 ✓ · CARA-KERJA.md addendum ini ✓ ·
zip kit refresh (hanya CARA-KERJA.md berubah, diff namelist identik 67
file) + scan token ketat `github_pat_[A-Za-z0-9_]{20,}` kosong ✓ · kode +
cache-pack tersimpan di upload/ (layout §29) ✓ · PAT tetap hanya di
work/.ghtoken ✓.

---

# ADDENDUM SESI-25 (video sesi-25: "Aku Benci Bahas ini, Tapi Aku Harus Ngomong, Tentang Pesantren Hari ini" — Felix Siauw)

> SATU sesi agent end-to-end setelah sandbox reset: pemulihan §33 (~2 menit),
> lalu 15 klip full-coverage 0-1675.87s (27:56) render + QA + upload semua
> selesai. Temuan penting baru: §65 (loader.to kadang kasih ad-gateway DEAD
> END — cara membedakan + solusinya). Aturan nama §55 dipatuhi tanpa
> perubahan.

## 65. PENTING: loader.to punya 2 jenis download_url — ad-gateway = DEAD END

Setelah 12 attempt dl-retry.sh SEMUA gagal dengan gejala sama (file 962 byte
HTML), ditemukan pola BARU yang belum ada di §42:

1. **Jenis BAIK (langsung)**: `download_url` host = `*.savenow.to`
   (contoh `penny83.savenow.to`, `logan14.savenow.to`, dulu `emma18`,
   `leo3`) + path `/api/v2/download/<hash>` → curl langsung = file mp4 utuh.
2. **Jenis BURUK (ad-gateway)**: `download_url` host =
   `lto2.affadaffa.com` (atau domain "affadaffa" lain) → HTML meta-refresh →
   `p.savenow.to/ajax/ad/b.php?id=<session>` → 302 ke jaringan iklan
   (`ey43.com/4/...`) → JS redirect ke google.com. **Rantai ini TIDAK
   pernah sampai ke file** — bukan masalah cookie/Referer (sudah dicoba
   lengkap dengan cookie jar; ad-nya tetap dead-end).

**Diagnosa cepat**: probe sesi BARU sebelum download — skrip agent
`scripts/dl-url-get.mjs` (dari upload/agent-scripts/, ikut upload mount) atau
`dl-probe-formats.mjs` (varian multi-format). Lihat host pada `download_url`:
- `*.savenow.to` → LANGSUNG curl download (aman, sekali jalan).
- `*.affadaffa.com` → BATALKAN sesi itu, start sesi BARU (POST download.php
  lagi) sampai dapat server savenow langsung. Sesi ini: attempt-1 probe dapat
  affadaffa; probe berikutnya langsung dapat penny83/logan14 (server acak
  per sesi). Kalau mentok terus, coba format beda (360/1080) — sesi baru
  selalu dapat server acak baru.
- **Probe `Range: bytes=0-99` TIDAK hemat**: server savenow ABAIKAN Range
  (balas 200 + file penuh) — probe = download penuh; `probeLen` besar +
  `first=000000246674797069736f6d` (ftyp isom) = video valid (§62.2
  terkonfirmasi; skrip probe menerima [format, url] dan sekaligus kasih
  total size utk estimasi).
3. Download 142.3MB logan14 sekali jalan via curl biasa (deterministik,
   bukan dl-retry — URL sudah diverifikasi baik lewat probe).

## 66. Catatan operasional sesi ini (semua terverifikasi jalan)

1. Pemulihan §33 standar ~2 menit: zip repo-2 (REPO const benar) + `cp -a
   upload/ofc-clip-kit/whisper.cpp` (model 487MB + binary + symlink ikut)
   + `npm ci` 8 dtk + `tar xzf upload/clip-kit-cache.tar.gz
   node_modules/.remotion` + bootstrap skip-semua (re-pack cache 620M 33 dtk).
   Bersih artefak stale §63.1 dijalankan SEBELUM mulai (out kosong semua).
2. Video 1675.87s (27:56) 720p **CFR 23.976fps ASLI** (40.178 paket sorted:
   gap 0.041708s 66.7% + 0.041709s 33.3% = 100% grid 1001/24000 — dua nilai
   itu rounding 6-desimal dari grid yang sama, JANGAN baca VFR, §58.2) →
   tanpa re-encode.
3. Kalibrasi whisper 0.87x → part-len **420** (aturan margin §58.4 walau
   saran skrip 460) → 5 bagian SEMUA jalan full tanpa split-paruh → merge
   **3.980 kata** mono 0 back-jump (fix-monotonic TIDAK diperlukan).
4. 15 klip full-coverage TANPA skip (monolog padat sejak detik 0; kata
   terakhir "awal daripada ilmu" berakhir 1671.4s + outro hening — klip
   terakhir ditutup di 1675.87 = ujung video). Batas semua di ujung
   kalimat/hening natural via boundary-helper (punct ATAU gap>=0.45s §49.5).
   Durasi 53.8-174.9 dtk; 2 klip pendek by design (islam-atur-dosis 58s,
   korban-bapak-mau-bunuh 53.8s — topik tuntas, preseden §27.2).
5. Rantai §40 stabil: mayoritas klip selesai dalam 1 panggilan render
   (render percobaan 1 langsung EXIT=0 di dalam budget), chain untuk
   finish+render berikutnya. Exit -9/255 setelah "SELESAI OK" = normal
   (§31.8/§43/§57 ke-N kalinya) — SELALU cek log finish + daftar repo
   sebelum ulang (§57 dipatuhi 3x sesi ini, semua ternyata sudah selesai).
6. QA piksel: 4 klip ada frame LOW (bapak-bilang 26.6s, tarbiatul 45.0s,
   cek-sistem 35.4s, dst) — SEMUA micro-pause, tetangga ±0.8-1.5s OK
   otomatis (§20.6 ke-N kalinya). 7 klip QA LULUS langsung 3/3.
7. Upload SEMUA via Contents API @ CRF 26 (6.0-22.4MB, batas §39 aman).
   15 klip + metadata.json (urutan + renderPrioritas + batasKlip) + README
   row (sekaligus rapikan baris sesi-24 yang lepas dari tabel) terverifikasi.
8. Prioritas render topik terkuat dulu: yang-salah-muslimnya (tesis) →
   wala-takrobu-zina → bapak-bilang-tarik-anak (hook emosional) →
   tarbiatul-jinsiyah (solusi) → power-tends-to-corrupt → dst (urutan
   lengkap di metadata.json).

## 67. Checklist penutupan sesi (semua ✓)

15 klip ter-upload ✓ · metadata.json sesi-25 ✓ · README.md +baris sesi-25 ✓ ·
CARA-KERJA.md addendum ini ✓ · zip kit refresh + scan token ketat
`github_pat_[A-Za-z0-9_]{20,}` kosong ✓ · kode + cache-pack tersimpan ke
upload/ (layout §29) ✓ · PAT tetap hanya di work/.ghtoken ✓.

---

# ADDENDUM SESI-26 (video sesi-26: "Koiyocabe Mengenal Member Yukngaji" — YNTV)

> SATU sesi agent end-to-end setelah sandbox reset: pemulihan §33 (~2 menit),
> lalu 29 klip full-coverage 0-4651.0s render + QA + upload semua selesai.
> Video TERPANJANG di project: 4733.77s (78:53) — video sesi-23 (68:00)
> terlampaui; transkrip 12.849 kata = terbesar sejauh ini. Aturan nama §55
> dipatuhi tanpa perubahan.

## 68. Catatan operasional sesi ini (semua terverifikasi jalan)

1. Pemulihan §33 standar ~2 menit: zip repo-2 + `cp -a upload/ofc-clip-kit/
   whisper.cpp` (model 487MB ikut) + `npm ci` + tar chrome + bootstrap
   skip-semua (re-pack cache 620M). CARA-KERJA di `upload/` (77KB, s/d
   sesi-23) LEBIH LAMA dari di repo-2 (86KB, s/d sesi-25) — SELALU pakai
   versi repo-2 sebagai sumber kebenaran sesudah sesi-19.
2. Video 4733.77s (78:53) 1280x640 **CFR 23.976fps ASLI** (113.497 paket
   sorted: 100% grid 1001/24000) → tanpa re-encode. **Materi #13 PluqEnYEZuM
   sesudah 12x ganti URL di chat** — selalu oEmbed dulu sebelum kerja
   (judul+channel: "Koiyocabe Mengenal Member Yukngaji" / YNTV).
3. loader.to: probe dl-url-get sekali jalan → server **aiden90.savenow.to**
   (jenis BAIK §65) → curl langsung 661.158.402 byte utuh dalam ~5 menit
   (EXIT=0, ukuran PERSIS = probeLen §62.2). Probe-first makin terkonfirmasi:
   tanpa download sia-sia sama sekali.
4. Kalibrasi whisper 1.05x → part-len **420** (aturan margin §47.3/§58.4,
   saran skrip 459 diabaikan) → 12 bagian SEMUA jalan full 388-448s/bagian
   tanpa split-paruh → merge **12.849 kata mono 0 back-jump** SEKALI JALAN
   (fix-monotonic TIDAK diperlukan).
5. **Variety show multi-topik 79 menit = 29 klip** (rekor bersama sesi-23).
   Preseden SKIP yang dipakai: HANYA outro ad-read jualan event 4651.0-
   4733.87s (82.9s, §63.4/§60.5) — seluruh obrolan termasuk banter pre-show
   0-663s TETAP konten (beda dari sesi-24 yang skip sketch intro: di sini
   banter-nya adalah isi video "mengenal member", bukan peluncur).
6. **Zona dialog cepat tanpa punct/gap**: 3 batas dipilih MANUAL di aliran
   kata via words-around (§49.5 fallback): 1836.90 ("tapi satu hal..."
   mulai image kapitalis), 2138.90 ("Oh gue mau tanya member keberapa"),
   2905.50 ("Jadi katanya semuanya tergantung pemikiran"). Semua lain via
   boundary-helper. Identitas pembicara di transkrip whisper sering garbled
   ("usah tidayat" = Ustaz Hidayat) — nama klip pakai TOPIK, bukan nama
   orang, kalau ragu.
7. **UPLOAD ECONNRESET 2x (klip trauma-dihujat & bintangnya-ada-di-yukngaji)**:
   gejala = "fetch failed / read ECONNRESET" di tengah PUT, TAPI file
   TERNYATA SUDAH masuk repo (create-nya lolos, response-nya yang putus).
   Retry gh-upload menampilkan "update" (bukan "create") dan sukses —
   idempoten, aman. Pelajaran: ECONNRESET ≠ upload gagal total; SELALU
   cek daftar file repo sebelum mengulang upload yang sama.
8. Rantai §40 stabil: rata-rata ~1.5 panggilan/klip (klip ≤130s = 1-2
   panggilan; 165-235s = 2-3 panggilan). Exit -9/255 setelah "SELESAI OK"/
   "semua pending selesai" terjadi ~8x (§31.8/§43/§57 ke-N kalinya) — cek
   log + repo dulu, semuanya ternyata sudah selesai.
9. QA piksel: LOW hanya di 3 klip (tidur 141.0s, dst) — semua micro-pause,
   tetangga ±1.5s OK otomatis (§20.6 ke-N kalinya). Mayoritas klip QA 3/3
   langsung LULUS.
10. Upload 29 klip @ CRF 26 (15.1-27.7MB): 27 via Contents API, 1 via Git
    blob API fallback otomatis (502), 1 via manual retry setelah ECONNRESET.
    metadata.json (urutan + renderPrioritas + batasKlip) + README row ✓.

## 69. Checklist penutupan sesi (semua ✓)

29 klip ter-upload ✓ · metadata.json sesi-26 ✓ · README.md +baris sesi-26 ✓ ·
CARA-KERJA.md addendum ini ✓ · zip kit refresh + scan token ketat
`github_pat_[A-Za-z0-9_]{20,}` kosong ✓ · kode + cache-pack tersimpan ke
upload/ (layout §29) ✓ · PAT tetap hanya di work/.ghtoken ✓.

---

# ADDENDUM SESI-27 (video sesi-27: "DI SINI ADA SUSHIIIII!!!" — Raditya Dika)

> SATU sesi agent end-to-end setelah sandbox reset: pemulihan workspace warisan
> (~2 menit), lalu 27 klip full-coverage 0-3337.21s (55:37) render + QA + upload
> semua selesai. Bahan #14 NFPlhThtKAc (Raditya Dika traktir Tepe omakase sushi);
> bahan #13 PluqEnYEZuM ternyata SUDAH diproses sebagai sesi-26 oleh sesi agent
> sebelumnya — oEmbed dulu sebelum kerja (§68.2) makin penting karena pergantian
> bahan di chat kini bisa lintas sesi agent. PERMINTAAN USER BARU: mode nama
> "part N" (lihat §70).

## 70. ATURAN NAMA MODE "part N - topik" (permintaan user sesi-27, KONDISIONAL)

User: "khusus ini, di nama nama nya di kasih 'part 1 - xxxxxx xxxxx' soalnya
pasti banyak yang nyari podcast ini karena Tepe bodoh banyak blunder". Jadi
untuk konten yang DIPREDIKSI BANYAK DICARI (guest viral / blunder / konten
berpasangan), user bisa minta nomor part TAMPIL di nama file:

1. **Format**: `part N - topik dengan spasi.mp4` (contoh produksi:
   `part 2 - tepe salah baca setengah enam jadi jam enam.mp4`). N = urutan
   tonton klip (sekaligus urutan waktu di video, karena klip full-coverage).
2. **Implementasi (sudah masuk kit v1.2+)**: `finish-one.sh` sekarang
   mengenali id lokal berpola `^part-([0-9]+)-(.+)$` (contoh id:
   `part-2-tepe-salah-baca-setengah-enam-jadi-jam-enam`) dan meng-upload-nya
   sebagai `part N - <slug spasi>.mp4`. Id TANPA pola itu tetap pakai aturan
   §55 biasa (spasi, tanpa nomor) — backwards-compatible, tidak ada sesi lama
   yang rusak.
3. **Kapan dipakai**: HANYA kalau user minta eksplisit (default tetap §55
   tanpa nomor). metadata.json tetap menyimpan field `urutan` + `batasKlip`
   + `renderPrioritas` seperti biasa.
4. Penomoran ikut urutan WAKTU di video (part 1 = pembuka), bukan prioritas
   render — prioritas render (topik terkuat duluan, §11) tetap boleh beda
   urutan (di sesi ini render mulai dari part 2, blunder utama).

## 71. Catatan operasional sesi ini (semua terverifikasi jalan)

1. Pemulihan INSTAN ~2 menit: `upload/ofc-clip-kit/` dari sesi-26 UTUH
   (node_modules + whisper + chrome + model) → rsync kode (exclude out/,
   node_modules, whisper.cpp, raw.mp4, cache, log) + `cp -a upload/ofc-clip-kit/
   whisper.cpp` (27 dtk) + `npm ci` 6 DTK (cache npm ternyata selamat dari
   reset) + `tar xzf upload/clip-kit-cache.tar.gz node_modules/.remotion` +
   bootstrap skip-semua 33 dtk (re-pack cache 620M).
2. Video 3337.21s (55:37) 720p **CFR 25fps ASLI** (83.428 paket sorted: 100%
   grid 0.04s) → tanpa re-encode. loader.to probe-first (§65): attempt-1
   langsung dapat server **leo3.savenow.to** (jenis BAIK) → curl 232.634.324
   byte (persis probeLen §62.2) dalam 101 dtk sekali jalan.
3. Kalibrasi whisper 0.84x → part-len **420** (aturan margin §58.4) → 9 bagian
   SEMUA jalan full tanpa split-paruh → merge **8.798 kata mono 0 back-jump**
   sekali jalan (fix-monotonic TIDAK diperlukan).
4. 27 klip full-coverage TANPA skip (makan-makan obrolan dari detik 0 sampai
   outro thanks). Batas semua di ujung kalimat/hening natural via
   boundary-helper + verifikasi words-around 2 putaran. Durasi 54.6-229.7s;
   5 klip >180s by design (§49.6); part-21 (ikan kerajaan) 54.6s topik tuntas
   (preseden §66.4 klip 53.8s).
5. **FIX KIT: gh-upload.mjs fallback 504** — Contents API 504 (gateway timeout)
   dulu TIDAK memicu fallback Git API (cuma 422/502), part-4 31.4MB sempat gagal
   upload. Patch: 504 ditambahkan ke kondisi fallback. Retry sukses. 502/504
   memang satu kategori (transient server-side), 422 permanen ukuran.
6. Rantai §40 stabil: rata-rata ~1.5 panggilan/klip (klip ≤112s = 1 panggilan;
   137-230s = 2-3 panggilan). Exit -9/255 setelah "SELESAI OK"/"semua pending
   selesai" ~10x (§31.8/§43/§57 ke-N kalinya) — SELALU cek log finish + daftar
   repo dulu, semuanya ternyata sudah selesai.
7. QA piksel: LOW hanya di 2 klip (part-9, part-27) — SEMUA micro-pause,
   tetangga ±1.5s OK otomatis (§20.6 ke-N kalinya). 25 klip lain QA 3/3
   langsung LULUS.
8. Upload: 27 klip @ CRF 26 (7.2-31.4MB); 2 file lewat fallback Git API
   (part-2 27.9MB setelah 502, part-4 31.4MB setelah 504-patch), sisanya
   Contents API langsung. 27 klip + metadata.json terverifikasi di repo.

## 72. Checklist penutupan sesi (semua ✓)

27 klip ter-upload ✓ · metadata.json sesi-27 (urutan format "part N - ..." +
renderPrioritas + batasKlip) ✓ · README.md +baris sesi-27 + catatan mode nama
part (§70) ✓ · CARA-KERJA.md addendum ini + tabel §55 diperluas ✓ · zip kit
refresh (+patch finish-one.sh mode part & gh-upload.mjs 504) + scan token
ketat `github_pat_[A-Za-z0-9_]{20,}` kosong ✓ · kode + cache-pack tersimpan
ke upload/ (layout §29) ✓ · PAT tetap hanya di work/.ghtoken ✓.

---

# ADDENDUM SESI-29 (video sesi-29: "Eps 1076 | IMAM SYAFI'I VS ARISTOTELES SIAPA YANG LEBIH CERDAS?" — guru gembul)

> SATU sesi agent end-to-end setelah sandbox reset: pemulihan §33 (~1 menit),
> lalu 13 klip full-coverage 0-1523.52s (25:23) render + QA + upload semua
> selesai. Bahan #15 XZBabm_fWzo setelah 14x ganti URL di chat (bahan #13
> PluqEnYEZuM = sesi-26, bahan #14 NFPlhThtKAc = sesi-27 — oEmbed dulu
> selalu, §68.2). ATURAN NAMA §55 dipakai (user TIDAK minta mode "part N"
> utk video ini — mode itu §70 kondisional per permintaan eksplisit).

## 73. PENTING: sesi-28 KORUPSI PARSIAL — warisan upload/ hanya utuh kalau DISIMPAN

Keadaan ditemukan sesi ini: repo-2 punya folder `sesi-28-felix-beliin-mami-
mobil-listrik/` isinya CUMA 1 klip, TANPA metadata.json, TANPA baris README,
TANPA addendum CARA-KERJA. Rekonstruksi: sesi agent sebelumnya selesai
render+upload 1 klip lalu terputus (sandbox reset); transkrip + rencana klip
+ segmen sisanya HILANG karena TIDAK pernah disalin ke mount `upload/`
(state di upload/ masih milik sesi-27: raw.mp4 232MB + raw.json 8.798 kata
sesi-27, out/data 27 klip sesi-27, out/clips kosong).

Pelajaran & aturan baru:
1. **`upload/` itu warisan yang cuma ada kalau DISIMPAN** — sesi yang
   terputus sebelum menyimpan = kerjanya hilang total. Kalau sesi terasa
   bakal panjang (video >30 menit / >15 klip), selipkan rsync state ke
   upload/ di tengah sesi (setelah merge transkrip + setelah beberapa klip),
   jangan cuma di akhir (§29).
2. **Deteksi sesi korupsi parsiel**: bandingkan daftar folder sesi di repo
   vs README vs metadata.json. Folder tanpa metadata.json + tanpa baris
   README = sesi yang terputus. Jangan dipakai sebagai patokan penomoran
   sesi berikutnya yang bingung — sesi lanjutan tetap nomor berikutnya
   (video sesi-28 yang belum selesai bisa dilanjutkan kalau user kirim
   ulang URL-nya; namai foldernya sama, lengkapi klip sisanya nanti).
3. README repo-2 sekarang menandai sesi-28 sebagai "(parsial)" supaya
   keadaannya transparan.

## 74. Catatan operasional sesi ini (semua terverifikasi jalan)

1. Pemulihan §33 standar ~1 menit: zip repo-2 (REPO const benar) + `cp -a
   upload/ofc-clip-kit/whisper.cpp` (27 dtk, model 487MB ikut) + `npm ci`
   6 dtk + `tar xzf upload/clip-kit-cache.tar.gz node_modules/.remotion` +
   bootstrap skip-semua 33 dtk (re-pack cache 620M).
2. Video 1523.52s (25:23) 720p **CFR 30fps ASLI** (45.702 paket sorted: 100%
   grid 1/30s — dua nilai gap 0.033333/0.033334 = rounding grid yang sama,
   §58.2) → tanpa re-encode. loader.to probe-first (§65): attempt-1 langsung
   dapat server **sophia28.savenow.to** (jenis BAIK) → curl 154.839.744 byte
   (persis probeLen §62.2) dalam 66 dtk sekali jalan.
3. Kalibrasi whisper 0.95x → part-len **420** (aturan margin §58.4, saran
   skrip 460 diabaikan) → 4 bagian SEMUA jalan full tanpa split-paruh →
   merge **3.334 kata mono 0 back-jump** sekali jalan (fix-monotonic TIDAK
   perlu). §30 (bersihkan parts lama) dijalankan sebelum init.
4. 13 klip full-coverage TANPA skip (monolog padat sejak salam pembuka
   sampai salam penutup). Batas semua di ujung kalimat natural via
   boundary-helper + verifikasi words-around. Durasi 52.9-171.3s; klip
   terpendek pembuka 57.8s (hook tesis) & penutup 52.9s (punchline "jangan
   dihujat ya nanti ditembak", preseden §27.2/§66.4).
5. Rantai §40 efisien: rata-rata ~1.6 panggilan/klip (klip 53-118s = 1
   panggilan; 146-171s = 2 panggilan). SATU insiden §57 terulang: chain
   ke-timeout setelah selesai → agent khawatir finish-one klip itu belum
   jalan → re-run finish-one → guard frame-count menolak finalize (segmen
   sudah milik klip berikutnya, 1600 ≠ 2747) → TANPA efek samping, dan
   cek repo membuktikan klip TERSEBUT SUDAH ter-upload sejak chain pertama.
   Guard §46 = pertahanan terakhir yang bekerja PERSIS seperti desainnya.
6. QA piksel: LOW hanya di 1 klip (bulu kucing @~100s) — micro-pause,
   tetangga ±0.7-1.5s semua OK otomatis (§20.6 ke-N kalinya). 12 klip lain
   QA 3/3 langsung LULUS.
7. Upload SEMUA via Contents API @ CRF 26 (8.8-25.1MB, batas §39 aman).
   13 klip + metadata.json + README (baris sesi-29 + catatan sesi-28
   parsial) terverifikasi di repo.
8. Prioritas render topik terkuat dulu (§11): aristoteles-anak-tangga
   (judul/inti tesis) → bulu-kucing (fatwa paling viral-able) →
   aristoteles-perempuan (lanjutan VS) → peradaban-mentok (hook) → dst
   (urutan lengkap di metadata.json renderPrioritas).

## 75. Checklist penutupan sesi (semua ✓)

13 klip ter-upload ✓ · metadata.json sesi-29 (urutan + renderPrioritas +
batasKlip) ✓ · README.md +baris sesi-29 +catatan sesi-28 parsial (§73) ✓ ·
CARA-KERJA.md addendum ini ✓ · zip kit refresh (hanya CARA-KERJA.md berubah,
namelist identik) + scan token ketat `github_pat_[A-Za-z0-9_]{20,}` kosong ✓ ·
kode + cache-pack tersimpan ke upload/ (layout §29) ✓ · PAT tetap hanya di
work/.ghtoken ✓.

---

# ADDENDUM SESI-30 (video sesi-30: "KORUPSI budaya bangsa yang terus dipelihara? #WTFIndonesia" — WTF WORLD)

> SATU sesi agent end-to-end lagi: pemulihan §33 varian baru (lihat §76.1),
> 19 klip full-coverage 0-1815.02s (30:15) render + QA + upload semua selesai.
> Bahan #17 No3FXIzdly4. ATURAN NAMA §55 dipakai (user tidak minta mode
> "part N" — mode §70 tetap kondisional per permintaan eksplisit).

## 76. Catatan operasional sesi ini (semua terverifikasi jalan)

1. **Varian baru state "setengah hilang"**: sandbox TIDAK di-reset (kode,
   log, out/, cache-pack, raw.mp4 sesi-29 semuanya utuh dari kemarin), TAPI
   `node_modules` dan isi `whisper.cpp` (binary+model) HILANG tanpa jejak
   (dir whisper.cpp jadi kosong). Pemulihan §33 tetap berlaku persis:
   `cp -a upload/ofc-clip-kit/whisper.cpp .` (29 dtk) + `npm ci` (6 dtk,
   cache npm masih hangat) + `tar xzf upload/clip-kit-cache.tar.gz -C .
   node_modules/.remotion` + bootstrap skip-all — total < 1 menit.
   CATATAN PATH: model ada di `whisper.cpp/ggml-small.bin` (ROOT whisper.cpp,
   BUKAN `whisper.cpp/models/`) — cek keberadaan model pakai path itu;
   binary di `whisper.cpp/build/bin/main` + symlink `whisper.cpp/main`.
2. Video 1815.02s (30:15) 720p **CFR 29.97fps ASLI** (30000/1001; 54.393
   paket sorted 100% grid 1/29.97s — dua nilai gap 0.033366/0.033367 =
   rounding grid sama, §58.2) → tanpa re-encode. loader.to probe-first
   (§65): server `leo3.savenow.to` (BAIK) sekali jalan → curl 175.531.781
   byte (persis probeLen) 60 dtk.
3. Kalibrasi whisper **0.74x** (lebih cepat dari biasanya 0.95-0.99x) →
   saran skrip part-len **460** LANGSUNG dipakai (aturan §47.3 hanya
   menurunkan kalau rasio >0.95; 0.74 < 0.95 → 460 aman, margin 5.7 menit
   proses per bagian) → 4 bagian → merge 3.491 kata dengan **1 run 16 kata
   timestamp mundur DI TENGAH bagian (~872s, bukan di sambungan)** — pola
   §52 ke-2 kalinya → fix-monotonic.py interpolasi → 0 back-jump.
4. 19 klip full-coverage TANPA skip. Batas semua ujung kalimat natural via
   boundary-helper + verifikasi words-around. Durasi 52.8-171.1s.
5. **QA LOW false-alarm JENIS BARU**: klip penutup LOW kuning=36 di 60.4s +
   SEMUA tetangga (±1.5s) juga LOW 39-49 — bukan micro-pause. Penyebab:
   12 detik TERAKHIR video (1803-1815s) adalah outro TANPA ucapan (kata
   terakhir "ini." selesai di 1803.0) → subtitul memang kosong. Solusi
   diagnosis: `words-around.mjs <absolut-titik-LOW>` DULU — kalau tidak ada
   kata di zona itu = zona hening/outro = bukan bug, klip tetap valid
   (poin QA lain di zona bicara 15497/5181 kuning). Tambahkan ke protokol
   §20.6: cek transkrip SEBELUM frame tetangga kalau tetangga ikut LOW.
6. Rantai §40 normal: klip 53-98s = 1-2 panggilan, 125-171s = 2 panggilan.
   Pola exit-code aneh berulang: chain/render panggilan sering mati -9/255
   DI AKHIR setelah baris "render selesai (percobaan 1)" tercetak —
   pekerjaan sebenarnya SUDAH selesai; SELALU verifikasi via marker
   `.current-clip` + isi repo (§74.5/§57) sebelum ulang apapun.
7. Upload SEMUA via Contents API @ CRF 26 (9.9-22.0MB) + metadata.json +
   README baris sesi-30. Repo-2 setelah sesi ini ±4.1GB — masih di bawah
   ambang 5GB, repo ke-3 belum perlu.

## 77. Checklist penutupan sesi (semua ✓)

19 klip ter-upload ✓ · metadata.json sesi-30 (urutan + renderPrioritas +
batasKlip) ✓ · README.md +baris sesi-30 ✓ · CARA-KERJA.md addendum ini ✓ ·
zip kit refresh (namelist identik) + scan token ketat
`github_pat_[A-Za-z0-9_]{20,}` kosong ✓ · kode + cache-pack + state ke
upload/ (layout §29) ✓ · PAT tetap hanya di work/.ghtoken ✓.
---

# ADDENDUM SESI-31 (BUKAN sesi video — eksperimen GitHub Actions runner)

> User minta: riset mandiri menunjukkan GitHub Actions (GA) runner specs lebih
> bagus dari sandbox; test semua tugas berat di GA; kalau berhasil, catat untuk
> implementasi ke depan. Eksperimen dijalankan NYATA di `kasyaira/clip-sessions-2`
> via workflow `.github/workflows/ga-lab.yml` + `ga-lab-d.yml` (workflow_dispatch),
> bahan uji = video sesi-30 `No3FXIzdly4` (30:15, 167MB) memakai SKRIP PRODUKSI
> KIT ASLI (loader-download.mjs, transcribe-parts.mjs, render-retry.sh,
> finalize-clip.mjs, qa-frames) — bukan tiruan mainan. Run eksperimen:
> 38239986651 (dibatalkan, checkout), 38240817692 (B ok, C gagal symlink),
> 38241641540 (C gagal merge back-jump — pola §52), 38244372359 (A+B+C sukses),
> 38248650802 (D render sukses via artifact run-id re-use).

## 78. VERDICT: GA runner jauh lebih kuat untuk SEMUA tugas berat — layak jadi "mesin berat" resmi

Hasil pengukuran langsung (ubuntu-latest public runner, run di atas):

| Metrik | GA runner (terukur) | Sandbox agent | Rasio |
|---|---|---|---|
| CPU | 4 vCPU AMD EPYC 7763 | 2 vCPU | 2x |
| RAM | 15Gi total (14Gi avail) | 3.9Gi, 0 swap | ~4x |
| Disk / avail | **85G dari 145G** | 9.3G dari 9.9G | ~9x |
| apt cmake+ffmpeg+build-essential | **26-70s** | venv hack manual, menit | ~4x |
| Download loader.to 167MB | **34s** (±5MB/s) | 3-15 menit, sering putus (§42) | ~10x |
| Whisper small kalibrasi 120s | 49-58s = **0.41-0.49x realtime** | 0.74-1.2x (fluktuatif §36.3) | ~2x |
| Transkrip penuh 1815s (2 bagian part-len 1500) | 1016s (part 846s/2889 kata + 170s/588 kata) SATU job tanpa intervensi | ±22-36 menit via 4+ tool call + risiko split-paruh | ~2x waktu, tapi 1 panggilan vs banyak |
| Render clip uji 45s (1274 frame, CRF 26) | **155s incl. bundle ~30s** + finalize 3s | pakai ±2-5 menit + bundle (1-2 panggilan) | ~2x |
| Cold start kit di runner | curl zip 1s + apt 26s + npm ci 11s + warm-whisper (build+model 466MB) 69s + calibrate 58s = **±2.7 menit** | pemulihan §33 ±1-5 menit + cache-pack 620MB | setara! |
| Job D render end-to-end (download artifact + apt + npm + render + finalize + QA piksel) | **±205s total** | - | - |
| Biaya | $0 — repo publik = Actions gratis, tanpa batas menit | - | - |
| Batas per job | 6 JAM (vs tool call 5-10 menit) | - | 40-70x ruang gerak |

Kesimpulan tegas — semua pain-point terbesar sandbox teratasi di GA:
- **Tidak perlu chunking transkrip karena takut timeout**: satu job boleh jalan 6
  jam. part-len 1500 terbukti jalan mulus (video 30 menit = cuma 2 bagian);
  teoretis part-len 1800-2400 masih nyaman utk video 1-2 jam. Titik sambung
  merge makin sedikit = risiko bug sambungan turun.
- **ENOSPC (§34, §38) tidak mungkin terjadi**: disk 85GB vs kebutuhan puncak
  pipeline <10GB. "Target closed / Compositor SIGTERM" karena disk mepet
  (§38) tidak akan terulang.
- Download loader.to 10x lebih cepat & stabil (server savenow.to yang lambat
  pun kelihatan cepat di bandwidth runner).
- Whisper konsisten 4 core (0.41-0.56x sepanjang eksperimen) — bukan naik-
  turun seperti sandbox yang kadang kebablas limit tool call (§36.3).
- Render Chrome compositor jalan stabil 4 core, clip uji 45s selesai ~2.5
  menit SATU percobaan tanpa retry.

## 79. Arsitektur "heavy mode" yang terbukti jalan

Pembagian kerja yang benar:
- **GA runner = otot**: download video, transkrip penuh, render segmen,
  finalize, QA piksel awal.
- **Agent sandbox = otak + tangan ringan**: push workflow, dispatch via API,
  PILIH BATAS KLIP dari transkrip (keputusan editorial TETAP di agent —
  jangan pernah otomatisasi ini), words-around verifikasi, QA final,
  upload klip ke repo, metadata/README/CARA-KERJA.
- **Jembatan data** (semua terverifikasi eksperimen ini):
  - GA -> agent: artifact Actions API (`GET /actions/runs/{id}/artifacts`
    -> download zip; transcript raw.json 3.6MB/3468 kata turun dalam detik).
  - agent -> GA: input `workflow_dispatch` (URL video, part-len) + file kecil
    di repo yang GA ambil via raw URL.
  - GA job lanjutan -> job/artifact run SEBELUMNYA: `actions/download-artifact@v4`
    dengan parameter `run-id:` + `github-token:` (terverifikasi di run D —
    ini cara skip transkrip ulang 20 menit saat hanya butuh re-run render).
- **PAT TIDAK PERNAH masuk workflow** — workflow hanya butuh GITHUB_TOKEN
  bawaan (permissions: contents:read + actions:read). Repo publik juga
  tidak butuh token untuk curl raw zip.

Pola workflow terverifikasi (lihat ga-lab.yml di repo-2, job A/B/C/D):
1. Rantai job via `needs:` + artifact `raw-video` + `transcript`.
2. Kit TIDAK di-checkout — curl raw URL (lihat §80.1, ini WAJIB).
3. `unzip ofc-clip-kit.zip -d kit` -> semua skrip kit jalan apa adanya
   (loader-download, transcribe-parts, render-retry, finalize-clip,
   fix-monotonic — tanpa modifikasi sama sekali).
4. Deps runner: `sudo apt-get install -y cmake ffmpeg build-essential
   python3-pil` (~30s).
5. Artifact: `compression-level: 0` (mp4/json tidak terkompresi lagi,
   deflate hanya buang CPU), `retention-days: 1` (repo tetap source of
   truth; artifact bukan penyimpanan permanen).
6. QA piksel kuning #FFD60A di runner = identik hasil sandbox
   (yellow_px 10569/12328/23298 pada 3 titik sampling, ambang LULUS >50).

## 80. Jalan buntu & bug yang DITEMUKAN eksperimen ini (jangan diulang)

1. **`actions/checkout` pada repo 4GB = jebakan terbesar**: fetch seluruh
   tree = SEMUA blob video sesi ter-download ke runner — >11 menit belum
   selesai (run 38239986651 dibatalkan). JANGAN checkout repo-2 (apalagi
   repo lama 5.4GB) di workflow. Yang dibutuhkan hanyalah `ofc-clip-kit.zip`
   → `curl -sL https://raw.githubusercontent.com/kasyaira/clip-sessions-2/main/ofc-clip-kit.zip`
   (3MB, <1s). Kalau repo kelak private: tambahkan header Authorization
   Bearer GITHUB_TOKEN, tetap tanpa PAT.
2. **Symlink `whisper.cpp/main` hilang LAGI** (pola §6/§13, ke-3 kalinya):
   `warm-whisper.mjs` tidak membuat symlink (biasanya bootstrap.sh yang
   menambal). Di GA kita tidak jalanin bootstrap.sh → WAJIB step eksplisit
   `ln -sfn build/bin/main whisper.cpp/main` setelah warm-whisper.
   (TODO kit: pindahkan symlink fix ini KE DALAM warm-whisper.mjs supaya
   aman dipakai di mana pun — belum dikerjakan, catat untuk sesi kit
   berikutnya.)
3. **`cmd | tee` menelan exit code** (§39.6, ke-3 kalinya): step calibrate
   tampak "success" padahal whisper gagal symlink. Semua step pipeline yang
   pakai pipe WAJIB `set -o pipefail`.
4. **Dispatch API 404 beberapa puluh detik** setelah PUT workflow baru —
   index GitHub belum sinkron; tunggu 10-30s lalu retry.
5. **Logs run in-progress tidak bisa diunduh** (`GET /runs/{id}/logs` 404
   untuk run yang masih jalan; blob-nya juga kadang 404 saat roll-over) —
   pakai PER-JOB logs: `GET /repos/.../actions/jobs/{job_id}/logs` (live),
   dan step timing presisi dari `GET /runs/{id}/jobs`.
6. **`download-artifact@v4` memangkas LCA path**: upload
   `kit/out/transcripts/raw.json` + `kit/out/data/qa-style-test.json` ->
   file mendarat di `./transcripts/` + `./data/` (LCA = kit/out dipangkas).
   Jangan asal `mv`; cek dulu keberadaan file di kedua layout (workflow
   final sudah handle keduanya).
7. **Back-jump whisper §52 muncul ke-3 kali di part 1500s** (run
   38241641540: mono=false maxBackJump 6.44s DI TENGAH bagian — bukan di
   sambungan). Run berikutnya mono=true natural — back-jump itu INTERMITTEN.
   Fix permanen: `scripts/fix-monotonic.py` SEKARANG IKUT KIT v1.2.1
   (interpolasi linear §52, idempoten, teruji lokal 7-kata run + GA merge
   step auto-invoke). Merge step di workflow otomatis memanggilnya kalau
   `mono=false` — tidak perlu lagi intervensi manual.
8. **Body PUT >±100KB jangan via argv curl** (base64 zip 3MB = "Argument
   list too long") — pakai python urllib atau `curl -d @file`.
9. **`zip -r` menambah entri direktori eksplisit** (`public/`,
   `public/input/`, `render-inputs/`) — diff namelist zip lama vs baru
   harus FILTER entri yang berakhiran `/` dulu, kalau tidak diff-nya
   false-alarm.

## 81. Resep operasional heavy-mode (siap pakai sesi berikutnya)

1. **Trigger + pantau dari sandbox** (semua via API, PAT cukup dari
   work/.ghtoken):
   ```
   POST /repos/kasyaira/clip-sessions-2/actions/workflows/ga-lab.yml/dispatches
        {"ref":"main","inputs":{"video_url":"https://youtu.be/<ID>",
                                 "format":"720","part_len":"1500"}}
   GET  /repos/.../actions/runs?per_page=3       (id run terbaru)
   GET  /repos/.../actions/runs/{id}/jobs        (status + step timing)
   GET  /repos/.../actions/jobs/{job_id}/logs    (log live per job)
   GET  /repos/.../actions/runs/{id}/artifacts   (daftar artifact)
   GET  /repos/.../actions/artifacts/{aid}/zip   (unduh artifact)
   ```
   Skrip agent yang terbukti (dipakai persis di eksperimen ini, ada di
   sandbox `scripts/`): `push_and_dispatch.py`, `ga_poll.py`, `ga_logs.py`,
   `repack_kit.py`, `push_d_and_dispatch.py`.
2. **Timeline tipikal dari dispatch sampai semua data siap** (video 30
   menit): A spec ~2m (paralel) + B download ~2m -> C transcribe ~20m
   (cold start 2.7m + transkrip 17m) -> agent unduh transcript artifact,
   pilih batas klip -> D render (bisa per-klip atau batch; clip uji 45s =
   3.4m cold start + render). Estimasi untuk video 30 menit 19 klip
   penuh: ~1.5-2.5 jam wall-clock total di GA vs 5-7 jam tool call di
   sandbox — dan agent cuma intervensi beberapa kali singkat.
3. **part-len di GA**: 1500 terbukti (2 bagian/30 menit, tiap bagian
   selesai ~14 menit). Video 1-2 jam: 1800-2400 masih nyaman (job limit
   6 jam; 2 jam audio = 4 bagian x ~10-20 menit = ~1 jam transkrip).
   Overlap tetap 6. Kalibrasi tetap jalan dulu sebagai sanity check,
   tapi angkanya tidak lagi menentukan survival — cuma estimasi.
4. **Yang TIDAK berubah**: pemilihan batas klip di agent (baca transkrip
   via artifact), QA piksel + protocol micro-pause §20.6/§76.5, naming
   §55/§51 (spasi di remote, urutan di metadata), upload Contents API
   <40MB / git-plumbing repo baru >40MB, scan PAT sebelum push apa pun.
5. **Re-run selektif tanpa ulang kerja berat**: kalau hanya D yang perlu
   diulang, pakai ga-lab-d.yml + `source_run_id` = id run sukses —
   artifact raw-video + transcript di-re-use via download-artifact
   run-id (terverifikasi: hemat 20 menit transkrip).
6. **Optimisasi yang BELUM teruja** (opsi eksperimen lanjutan, catat saja):
   - `actions/cache` utk `whisper.cpp` (build+model ±700MB) + `node_modules`
     -> cold start 2.7 menit bisa turun ke <1 menit.
   - render `concurrency` naik dari 2 ke 3-4 di render-segments.mjs
     (sekarang hard-coded 2; runner 4 core 16GB kuat lebih) — perlu uji
     stabilitas compositor dulu.
   - GA langsung push klip ke repo pakai GITHUB_TOKEN (permissions
     contents:write) supaya artifact download ke sandbox tidak perlu —
     tapi hati-hati: commit dari Actions tidak memicu Actions lain
     (aman), dan token hanya hidup selama job.
   - whisper model `medium` utk akurasi lebih (belum diperlukan; small
     sudah 0.41-0.49x di GA).

## 82. Kapan pakai GA vs sandbox (keputusan final eksperimen ini)

- **Video >= 30 menit ATAU >= 10 klip**: pakai heavy mode GA untuk download
  + transkrip + render. Agent tetap pegang: pilih batas, QA visual final,
  upload, metadata, README, CARA-KERJA.
- **Video pendek (< 30 menit, <= 6 klip)**: sandbox biasa (§13) masih lebih
  sederhana — setup GA + dispatch + pantau tidak sebanding dengan hematnya
  (jalur sandbox sudah langsung jalan).
- **Kondisi khusus**: kalau butuh SPLIT PARUH (§36.3) atau render ulang
  banyak klip, GA jelas menang — jangan tahan di sandbox.
- **Darurat**: kalau Actions outage / loader.to mati di GA, jalur sandbox
  §13 tidak dihapus — GA adalah LAPISAN TAMBAHAN, bukan pengganti.

## 83. Checklist penutupan eksperimen ini (semua terverifikasi)

Workflow `ga-lab.yml` (4 job) + `ga-lab-d.yml` (render-only re-use) aktif di
repo-2 ✓ · kit v1.2.1 (+ scripts/fix-monotonic.py) ter-push (sha 627f3200) ✓
· PAT scan ketat sebelum push zip kosong ✓ · lima eksperimen A/B/C/D/E sukses:
spec 4-core/15GB/85GB, download 167MB=34s, transkrip 30m=17m satu job, render
45s clip QA LULUS, artifact round-trip ke sandbox ✓ · addendum ini ✓.

# ADDENDUM SESI-31 (video sesi-31: "Bisakah Sains Membuktikan Adanya Tuhan ?" — Felix Siauw)

> Dua perubahan proses sesi ini: (1) DELIVERY MODEL BARU — video tidak lagi
> di-upload ke repo, deliverable final = artifact zip run render (user:
> "bagus begitu daripada simpan video di github"), (2) FIX NAMING di dalam
> zip artifact — sekarang pakai spasi sesuai §55, bukan hyphen. 19 klip
> full-coverage 0-1480.16s di-render via heavy mode GA.

## 84. DELIVERY MODEL BARU: artifact = deliverable final, repo cukup metadata (permintaan user, permanen)

1. **Mulai sesi-31 video TIDAK di-upload ke repo.** User menikmati download
   zip video langsung dari halaman artifact run GA Render — repo tidak lagi
   tumbuh 150-250MB per sesi (repo-2 di 4GB jadi awet lama; rencana repo
   ke-3 ditunda tanpa batas).
2. **Folder sesi-XX di repo tetap dibuat tapi hanya berisi metadata.json**
   (urutan + catatan + clips) — peran repo berubah jadi INDEKS + arsip
   metadata, bukan storage video.
3. **Retensi artifact 1 hari** (setelan lama, biar quota artifact aman) —
   user harus download hari yang sama dengan render. Kalau user minta lebih
   lama: naikkan `retention-days` di ga-render.yml (maks 90 hari utk repo
   publik, tapi hati-hati quota).
4. Konsekuensi utk skrip agent: `finish-one.sh` / jalur upload Contents API
   utk VIDEO tidak dipakai lagi di heavy mode (tetap dipakai utk metadata/
   README/CARA-KERJA/zip kit). Artifact diunduh via API `ga_ops.py
   get-artifact` (lihat §86.2 utk jebakan redirect).

## 85. FIX NAMING ARTIFACT: step rename spasi sebelum upload (§55.2 kini berlaku juga utk artifact)

1. **Akar masalah**: aturan §55.2 (remote name = hyphen diganti spasi)
   selama ini hanya diimplementasi di `finish-one.sh` — skrip jalur upload
   repo. Ketika delivery pindah ke artifact (mulai sesi-30), rename itu
   tidak pernah jalan → zip berisi `big-bang-volume-nol-massa-tak-terhingga.mp4`
   padahal user mau `big bang volume nol massa tak terhingga.mp4`.
2. **Fix**: step baru di `ga-render.yml` — "Rename nama file ke SPASI
   (§55.2 — artifact = deliverable final)" — ditaruh SETELAH render loop dan
   SEBELUM verify, jadi QA piksel/durasi memvalidasi nama file final yang
   benar-benar sampai ke user.
3. **ID lokal TETAP hyphen** (§55.1 tidak berubah): out/data, out/clips,
   marker, log, clips.json sheet — semua tetap hyphen demi tooling aman
   quoting. Rename hanya di lapisan paling akhir (ini persis arsitektur
   §55, cuma "remote" sekarang = artifact).
4. Skrip rename: python glob `out/clips/*.mp4` → `base.replace('-', ' ')`,
   print mapping RENAME tiap file, assert tidak kosong. Kata berulang
   ber-hyphen ikut kena ("berang-berang" → "berang berang", "gara-gara"
   → "gara gara") — konsisten dengan perilaku §55.2 lama, tidak
   di-special-case.

## 86. Catatan operasional sesi ini (terverifikasi jalan)

1. **ga-lab run 38277365717** (video 24:45, 720p 23.976fps, 193.5MB):
   download loader.to 73s · transkrip 1 bagian (part-len 1500, overlap 6)
   job C 992s termasuk cold start · ga-lab total sukses (job D QA render
   45s juga sukses).
2. **Jebakan unduh artifact via API**: `GET /actions/artifacts/{id}/zip`
   merespon 302 ke Azure blob. Kalau HTTP client otomatis ikut redirect
   DENGAN header Authorization → Azure menolak 401 InvalidAuthenticationInfo.
   Solusi: intercept 302, ambil `Location`, lalu GET polos tanpa header
   auth (blob URL sudah signed). Sudah benar di `scripts/ga_ops.py
   get-artifact` (class NoRedirect).
3. **Pemilihan batas klip tanpa node**: transkrip artifact dibaca pakai
   `scripts/tscript.py` (python murni, pengganti dump-transcript.mjs +
   words-around.mjs) — sub-perintah `dump <win>` / `around <t> <win>` /
   `gaps <min>` / `stats`. Berguna karena sandbox tidak perlu npm ci cuma
   buat baca transkrip.
4. **Ceramah flow tanpa jeda panjang** (jeda >= 1s cuma 9 titik di 1480s):
   strategi pilih batas = tentukan batas TOPIK dulu dari dump 30s window,
   lalu snap ke jeda kata terkecil terdekat yang jatuh di ujung kalimat
   sempurna. Tiga batas pakai jeda mikro 0.03-0.09s yang kebetulan persis
   setelah kalimat komplet ("...valuable bagi manusia" 183.22 → "jadi fami
   ya", "...itu adalah manusia" 615.58 → "contoh lagi", "paham ya" → "engga
   usah raudoh"). Klip tetap mulai/berhenti di keheningan (meski 0.03s)
   bukan di tengah kata — aman untuk word-highlight.
5. **Sheet + dispatch**: clips.json di-push ke `ga-tmp/sesi-31-clips.json`
   (sha a1e4e3b4), ga-render dispatch dengan `source_run_id=38277365717`
   re-use artifact raw-video + transcript — hemat download ulang + 16 menit
   transkrip ulang (pola §81.5).

## 87. Checklist penutupan sesi (semua terverifikasi)

ga-render.yml + step rename spasi ter-push (sha f8c7c898) ✓ · ga-lab sukses
(38277365717) ✓ · sheet 19 klip ter-push ✓ · ga-render sukses (38280935420)
✓ · zip artifact berisi 19 mp4 NAMA SPASI ✓ · durasi + 1080x1920 + pixel QA
kuning LULUS semua klip ✓ · metadata.json sesi-31 (folder video-less) ✓ ·
README baris sesi-31 + catatan delivery model baru ✓ · CARA-KERJA addendum
ini ✓ · zip kit di-update (sinkron CARA-KERJA.md dalam kit) ✓ · PAT scan
sebelum semua push ✓.
