import React from 'react';
import {random, useCurrentFrame, useVideoConfig} from 'remotion';
import {CHAT} from '../config';

/**
 * CHAT BUBBLES — reaksi "chat" melayang naik di kolom kanan video,
 * overlay gaya Twitch pada moment-moment meme. Ini elemen dekoratif
 * edit (bukan kutipan asli) — username & pesan generik dari pool.
 *
 * TEKS SAJA, tanpa emoji: runner GA (ubuntu-latest) tidak meng-install
 * font emoji warna — glyph emoji jadi kotak tofu di render. Jangan
 * tambahkan emoji ke pool sampai runner punya Noto Color Emoji.
 *
 * Deterministik: pilihan pesan/nama/warna di-seed dari id klip +
 * index spawn, jadi render ulang hasilnya identik pixel-per-pixel.
 */
export const ChatBubbles: React.FC<{clipId: string}> = ({clipId}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;

  if (!CHAT.enabled) {
    return null;
  }

  const firstDelay = 0.5;
  // index bubble yang mungkin masih hidup pada waktu t
  const iMax = Math.floor((t - firstDelay) / CHAT.every);
  const iMin = Math.max(0, Math.ceil((t - firstDelay - CHAT.life) / CHAT.every));

  const bubbles: React.ReactNode[] = [];
  for (let i = iMin; i <= iMax && i - iMin < CHAT.maxVisible + 2; i++) {
    const born = firstDelay + i * CHAT.every;
    const age = t - born;
    if (age < 0 || age > CHAT.life) continue;

    const rName = random(`chat-${clipId}-n${i}`);
    const rMsg = random(`chat-${clipId}-m${i}`);
    const rX = random(`chat-${clipId}-x${i}`);
    const rLane = random(`chat-${clipId}-l${i}`);

    const msg = CHAT.messages[Math.floor(rMsg * CHAT.messages.length)];
    const name = CHAT.names[Math.floor(rName * CHAT.names.length)];
    const color = CHAT.nameColors[i % CHAT.nameColors.length];

    // naik dari bawah ke atas + jitter-x kecil deterministik
    const prog = age / CHAT.life;
    const y = CHAT.yFrom + (CHAT.yTo - CHAT.yFrom) * prog;
    const xJitter = (rX - 0.5) * 56;
    // 2 lajur tipis supaya bubble tidak selalu segaris
    const lane = rLane > 0.5 ? 1 : 0;

    // opasitas: fade-in cepat, tahan, fade-out di akhir
    let opacity = 1;
    if (prog < CHAT.fadeIn) opacity = prog / CHAT.fadeIn;
    else if (prog > CHAT.fadeOut)
      opacity = Math.max(0, (1 - prog) / (1 - CHAT.fadeOut));

    // pop masuk: 0.86 -> 1 dalam 0.16 detik pertama
    const sp = Math.min(1, age / 0.16);
    const scale = 0.86 + 0.14 * (1 - Math.pow(1 - sp, 3));

    bubbles.push(
      <div
        key={i}
        style={{
          position: 'absolute',
          right: CHAT.right + lane * 26 + xJitter,
          top: 0,
          transform: `translateY(${y}px) scale(${scale})`,
          transformOrigin: 'center right',
          opacity,
          maxWidth: CHAT.width,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'flex-start',
          gap: 2,
          padding: `${CHAT.chipPadV}px ${CHAT.chipPadH}px`,
          background: CHAT.chipBg,
          border: CHAT.chipBorder,
          borderRadius: CHAT.chipRadius,
          boxShadow: '0 8px 22px rgba(0,0,0,0.45)',
          backdropFilter: 'blur(2px)',
        }}
      >
        <span
          style={{
            fontFamily: CHAT.fontFamily,
            fontWeight: CHAT.nameWeight,
            fontSize: CHAT.nameSize,
            color,
            letterSpacing: '0.01em',
            lineHeight: 1.1,
          }}
        >
          {name}
        </span>
        <span
          style={{
            fontFamily: CHAT.fontFamily,
            fontWeight: CHAT.msgWeight,
            fontSize: CHAT.msgSize,
            color: CHAT.msgColor,
            lineHeight: 1.15,
          }}
        >
          {msg}
        </span>
      </div>
    );
  }

  if (bubbles.length === 0) {
    return null;
  }

  return (
    <div
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        pointerEvents: 'none',
        zIndex: 20,
        overflow: 'hidden',
      }}
    >
      {bubbles}
    </div>
  );
};
