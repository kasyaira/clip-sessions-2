#!/usr/bin/env python3
"""Repair non-monotonic word timestamps in merged transcript (sesi-21).
Pattern: whisper 'small' kadang menghasilkan run token timestamp mundur di
tengah bagian (bukan di sambungan). Fix: cari run kata bermasalah, interpolasi
linear antara kata baik terakhir sebelum run dan kata baik pertama sesudah run.
Idempoten: kalau sudah mono, tidak mengubah apa pun."""
import json, sys

PATH = '/home/z/my-project/ofc-clip-kit/out/transcripts/raw.json'
data = json.load(open(PATH))
words = data['words'] if isinstance(data, dict) else data

def is_bad(w, prev_end):
    # kata bermasalah: start < prev_end (mundur) ATAU end < start (terbalik)
    return w['start'] < prev_end - 0.02 or w['end'] < w['start'] - 0.01

fixed_runs = 0
i = 0
out = []
while i < len(words):
    out.append(words[i])
    prev_end = words[i]['end']
    i += 1
    # deteksi run bermasalah yang diikuti kata baik
    run = []
    j = i
    while j < len(words) and is_bad(words[j], prev_end):
        run.append(j)
        j += 1
    if run and j < len(words):
        # interpolasi run antara prev_end dan words[j].start
        t0 = prev_end
        t1 = words[j]['start']
        n = len(run) + 1  # slot termasuk kata baik pertama
        slot = (t1 - t0) / n
        if slot <= 0:  # tidak ada ruang — jadikan run seketika setelah prev
            t0, t1 = prev_end, prev_end + 0.05 * (len(run) + 1)
            slot = 0.05
        for k, idx in enumerate(run):
            s = t0 + slot * (k + 1)
            e = min(t0 + slot * (k + 2), t1)
            words[idx]['start'] = round(s, 2)
            words[idx]['end'] = round(max(s + 0.05, e), 2)
        fixed_runs += 1
        print(f'run diperbaiki idx {run[0]}-{run[-1]} ({len(run)} kata): '
              f'interpolasi {t0:.2f}->{t1:.2f}s')
        # lanjut dari kata baik tsb
        out.extend(words[i:j+1]) if False else None
        for k in run:
            out.append(words[k])
        # kata baik pertama sesudah run
        out.append(words[j])
        prev_end = words[j]['end']
        i = j + 1
    elif run:
        # run di ujung akhir tanpa kata baik sesudah — buang timestamp aneh,
        # ratakan setelah prev_end
        for k, idx in enumerate(run):
            words[idx]['start'] = round(prev_end + 0.2 * (k + 1), 2)
            words[idx]['end'] = round(prev_end + 0.2 * (k + 1) + 0.15, 2)
        fixed_runs += 1
        print(f'run ujung diratakan: {len(run)} kata')
        for k in run:
            out.append(words[k])
        i = j

# verifikasi monotonik
bad = 0
prev = None
for w in out:
    if prev is not None and w['start'] < prev - 0.02:
        bad += 1
    prev = w['start']
print(f'hasil: {len(out)} kata, back-jump tersisa: {bad}, run diperbaiki: {fixed_runs}')

if fixed_runs > 0 or bad == 0:
    if isinstance(data, dict):
        data['words'] = out
        json.dump(data, open(PATH, 'w'), ensure_ascii=False)
    else:
        json.dump(out, open(PATH, 'w'), ensure_ascii=False)
    print('TERSIMPAN:', PATH)
    sys.exit(0 if bad == 0 else 1)
else:
    print('TIDAK ADA PERUBAHAN')
    sys.exit(1)
