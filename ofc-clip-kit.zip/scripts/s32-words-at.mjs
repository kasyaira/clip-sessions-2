#!/usr/bin/env node
/** Helper sesi-28: kata + timestamp di sekitar banyak titik sekaligus.
 *  Pemakaian: node s32-words-at.mjs t1 t2 t3 ... */
import fs from 'node:fs';
const {words} = JSON.parse(fs.readFileSync('out/transcripts/raw.json', 'utf8'));
const pts = process.argv.slice(2).map(Number);
for (const t of pts) {
  const lo = t - 6, hi = t + 6;
  const around = words.filter(w => w.end > lo && w.start < hi);
  const line = around.map(w => `${w.start.toFixed(1)}:${w.text}`).join(' ');
  console.log(`\n=== sekitar ${t}s ===`);
  console.log(line.slice(0, 900));
}
