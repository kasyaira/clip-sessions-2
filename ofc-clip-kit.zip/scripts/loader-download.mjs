#!/usr/bin/env node
/**
 * Download YouTube video via loader.to API (proven method, see CARA-KERJA.md §2/§65).
 * Usage: node loader-download.mjs <youtube_url> <output_file> [format]
 * format: 360 | 480 | 720 | 1080 (default 720)
 *
 * v1.2.2 (CARA-KERJA §65): loader.to kadang membalas download_url ad-gateway
 * (*.affadaffa.com) yang TIDAK PERNAH sampai ke file — script ini sekarang:
 *   1. deteksi host affadaffa -> mulai SESI BARU (server acak per sesi)
 *   2. validasi hasil unduhan: magic bytes 'ftyp' (mp4) + ukuran >= 1 MB
 *   3. retry sampai MAX_SESSIONS sesi berhasil
 */
import { createWriteStream, statSync, renameSync, openSync, readSync, closeSync } from 'node:fs';

const [, , url, out, formatArg] = process.argv;
const format = formatArg || '720';
if (!url || !out) {
  console.error('usage: node loader-download.mjs <url> <out> [format]');
  process.exit(1);
}

const MAX_SESSIONS = 5;
const MIN_BYTES = 1024 * 1024; // 1 MB

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function startDownload() {
  const u = `https://loader.to/ajax/download.php?format=${format}&url=${encodeURIComponent(url)}`;
  console.log('[1] start:', u);
  const res = await fetch(u, { headers: { 'User-Agent': UA } });
  const j = await res.json();
  console.log(JSON.stringify(j).slice(0, 300));
  if (!j.success || !j.id) throw new Error('start failed: ' + JSON.stringify(j).slice(0, 200));
  return j.id;
}

async function poll(id) {
  const t0 = Date.now();
  while (Date.now() - t0 < 10 * 60 * 1000) {
    await sleep(3000);
    const res = await fetch(`https://loader.to/ajax/progress.php?id=${id}`, {
      headers: { 'User-Agent': UA },
    });
    const j = await res.json();
    const pct = j.progress ? (j.progress / 10).toFixed(1) : '?';
    process.stdout.write(`\r[2] progress: ${pct}%  ${j.text || ''}          `);
    if (j.download_url) {
      console.log('\n[2] got download_url');
      return j.download_url;
    }
    if (j.error) throw new Error('progress error: ' + JSON.stringify(j));
  }
  throw new Error('timeout polling progress');
}

function hostOf(u) {
  try { return new URL(u).hostname; } catch { return ''; }
}

function isAdGateway(u) {
  const h = hostOf(u);
  return h.includes('affadaffa') || h.includes('ad-gateway');
}

async function fetchFile(dlUrl, outFile) {
  console.log('[3] downloading from', hostOf(dlUrl), '...');
  const res = await fetch(dlUrl, { headers: { 'User-Agent': UA } });
  if (!res.ok) throw new Error('download HTTP ' + res.status);
  const total = +(res.headers.get('content-length') || 0);
  let got = 0;
  const tmp = outFile + '.part';
  const fh = createWriteStream(tmp);
  for await (const chunk of res.body) {
    fh.write(chunk);
    got += chunk.length;
    if (total) process.stdout.write(`\r[3] ${(got / 1024 / 1024).toFixed(1)}/${(total / 1024 / 1024).toFixed(1)} MB`);
    else process.stdout.write(`\r[3] ${(got / 1024 / 1024).toFixed(1)} MB`);
  }
  await new Promise((r) => fh.end(r));
  renameSync(tmp, outFile);
  const sz = statSync(outFile).size;
  console.log(`\n[3] done: ${outFile} (${(sz / 1024 / 1024).toFixed(1)} MB)`);
  return sz;
}

function looksLikeMp4(file) {
  // ISO-BMFF: bytes 4..8 = 'ftyp' (CARA-KERJA §62.2)
  const fd = openSync(file, 'r');
  const buf = Buffer.alloc(12);
  let n = 0;
  try { n = readSync(fd, buf, 0, 12, 0); } finally { closeSync(fd); }
  return n >= 8 && buf.toString('latin1', 4, 8) === 'ftyp';
}

let lastErr = null;
for (let attempt = 1; attempt <= MAX_SESSIONS; attempt++) {
  try {
    const id = await startDownload();
    const dl = await poll(id);

    if (isAdGateway(dl)) {
      console.log(`[!] ad-gateway terdeteksi (${hostOf(dl)}) — DEAD END §65, mulai sesi baru (${attempt}/${MAX_SESSIONS})`);
      lastErr = 'ad-gateway ' + hostOf(dl);
      continue;
    }

    const sz = await fetchFile(dl, out);
    if (sz < MIN_BYTES) throw new Error(`file terlalu kecil (${sz} B) — kemungkinan halaman error`);
    if (!looksLikeMp4(out)) throw new Error('magic bytes ftyp tidak ketemu — bukan file mp4');

    console.log('SUCCESS');
    process.exit(0);
  } catch (e) {
    console.log(`[!] percobaan ${attempt}/${MAX_SESSIONS} gagal: ${e.message}`);
    lastErr = e.message;
  }
}
console.error(`GAGAL setelah ${MAX_SESSIONS} sesi loader.to. Terakhir: ${lastErr}`);
process.exit(1);
