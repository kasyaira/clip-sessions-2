#!/bin/bash
# chain.sh <id-selesai|-> <id-berikut> <sesi-dir>
# Finalisasi klip A (finish-one) + langsung mulai render klip B dengan sisa
# waktu panggilan tool (§40). Argumen '-' utk A = langsung render B saja.
set -uo pipefail
A="${1:?Pemakaian: bash chain.sh <id-selesai|-> <id-berikut> <sesi-dir>}"
B="${2:?Pemakaian: bash chain.sh <id-selesai|-> <id-berikut> <sesi-dir>}"
SESI_DIR="${3:?Pemakaian: bash chain.sh <id-selesai|-> <id-berikut> <sesi-dir>}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ "$A" != "-" ]; then
  bash "$HERE/finish-one.sh" "$A" "$SESI_DIR"
fi
bash "$HERE/render-one.sh" "$B"
