export type Word = {
  /** teks kata (tanda baca menempel, mis. "keren!") */
  text: string;
  /** detik, relatif dari awal klip */
  start: number;
  end: number;
};

export type Chunk = {
  words: Word[];
  start: number;
  end: number;
};

export type ClipData = {
  id: string;
  /** path video di dalam folder public/, mis. "input/raw.mp4". Kosongkan untuk mode demo. */
  video: string;
  /** detik: posisi potong awal di video sumber */
  clipStart: number;
  /** detik: posisi potong akhir di video sumber */
  clipEnd: number;
  words: Word[];
  /** nama channel sumber — ditampilkan badge "source: ..." pojok kanan bawah */
  sourceChannel?: string;
  /** hook meme: teks judul strip lime di awal klip (opsional — fallback: id) */
  hook?: string;
};

/** Sheet potongan yang diisi AI agent (render-inputs/clips.json) */
export type ClipSheet = {
  /** path video relatif terhadap folder public/ */
  video: string;
  /** nama channel sumber untuk badge "source:" (diteruskan ke semua klip) */
  sourceChannel?: string;
  clips: {
    id: string;
    /** detik di video sumber */
    start: number;
    /** detik di video sumber */
    end: number;
    /** teks hook banner (opsional — fallback: id di-spasi-kan) */
    hook?: string;
  }[];
};
