#!/usr/bin/env node
// boundary-helper.mjs <target-seconds> [window] — cari kandidat batas klip
// (pola §49.5): (a) kata berujung [.?!] ATAU (b) jeda hening >= 0.45s,
// jendela ±window (default 18s) dari target. Output: kandidat + konteks.
import fs from 'node:fs';
const PATH = '/home/z/my-project/ofc-clip-kit/out/transcripts/raw.json';
const target = parseFloat(process.argv[2]);
const win = parseFloat(process.argv[3] || '18');
const data = JSON.parse(fs.readFileSync(PATH, 'utf8'));
const words = data.words || data;

const cands = [];
for (let i = 0; i < words.length; i++) {
  const w = words[i];
  if (w.start < target - win || w.start > target + win) continue;
  const punct = /[.?!]$/.test(w.text);
  const gapNext = i + 1 < words.length ? words[i + 1].start - w.end : 99;
  if (punct || gapNext >= 0.45) {
    cands.push({t: w.end, punct, gap: gapNext, i, w: w.text});
  }
}
console.log(`kandidat batas sekitar ${target}s (±${win}s):`);
for (const c of cands) {
  const ctx = words.slice(Math.max(0, c.i - 4), c.i + 5)
    .map(x => x.text).join(' ');
  console.log(`  ${c.t.toFixed(2)}s ${c.punct ? 'PUNCT' : `GAP ${c.gap.toFixed(2)}s`} | ...${ctx}...`);
}
