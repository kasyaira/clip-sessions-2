---
name: meme-clip-kit-ops
description: Cara mengoperasikan preset render klip vertikal MEME/HIBURAN @ofkiehme (Remotion). Kit ini adalah varian dark-neon dari ofc-clip-kit — pipeline identik, gaya visual beda total. WAJIB dibaca sebelum memproses bahan streamer/gaming/meme jadi klip TikTok/Reels/Shorts.
---

# meme-clip-kit-ops

Kamu adalah agent yang menjalankan **meme-clip-kit** (preset Remotion klip
vertikal khusus meme/hiburan, lihat `README.md`). Skill ini adalah
**entrypoint wajib** — baca ini dulu sebelum menyentuh file apa pun.

## Aturan #1 — pipeline IDENTIK ofc-clip-kit, jangan riset ulang

Semua operasional (download, transkrip, render, finalize, QA, heavy-mode
GitHub Actions) sudah terdokumentasi di **`CARA-KERJA.md`** (addendum §78-92
untuk heavy mode GA). Kit ini hanya mengganti **lapisan visual** (`src/`) +
satu field opsional `hook`. Baca dulu:

1. `README.md` — gaya visual, keputusan desain, QA piksel lime.
2. `CATATAN-REVISI.md` — apa saja yang berubah vs ofc-clip-kit.
3. `CARA-KERJA.md` — operasional penuh (sama dengan ofc kit).

## Aturan #2 — kapan kit ini dipakai

- Bahan **streamer / gaming / reaksi / meme / hiburan** → kit ini.
- Bahan **podcast / ceramah / konten serius** → `ofc-clip-kit.zip`.
- Jangan pakai dua kit di satu sheet render — satu sesi satu kit
  (gaya harus konsisten antar klip dalam satu sesi).

## Aturan #3 — larangan keras (spesifik meme kit)

1. **Emoji DILARANG** di chat bubble / banner / caption / hook — runner GA
   tidak punya font emoji warna (glyph jadi kotak tofu). Teks murni saja.
2. **Jangan crop samping video** (objectFit cover pada box lebih tinggi
   dari 9/16) — facecam streamer ada di tepi kiri/kanan. Layout video
   full-width 16:9 adalah keputusan sadar setelah analisis VLM sesi-33.
3. **Chat bubble = dekorasi generik**, jangan mengutip kalimat nyata
   seolah-olah dari penonton sungguhan.
4. Semua angka gaya ada di `src/config.ts` — jangan ubah komponen untuk
   mengubah gaya.

## Aturan #4 — input sheet

Field opsional per klip: `hook` (teks banner lime awal klip, KAPITAL,
maks ±32 karakter enak dibaca; kosong = otomatis dari id). Durasi meme
ideal 12-90 detik. Semua field lain sama dengan ofc kit.

## Aturan #5 — render & QA

- Heavy mode GA (lihat CARA-KERJA §78-92): dispatch `ga-render.yml` dengan
  input `kit_url` = URL raw `meme-clip-kit.zip` + `qa_color` = `120,210,110`
  (threshold lime, ofc default `200,160,120` kuning).
- Nama file deliverable tetap pakai pola §55: id hyphen → nama file spasi
  (step rename di workflow, sudah ada).
