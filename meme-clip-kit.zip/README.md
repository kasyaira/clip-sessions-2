# MEME CLIP KIT v1.0

Preset Remotion klip vertikal **khusus konten meme / hiburan** — kebalikan
total dari `ofc-clip-kit` (paper/kertas elegan). Pipeline data & render
**100% identik** dengan ofc-clip-kit (loader-download → transcribe-parts →
build-clips → render-segments → finalize-clip); yang berubah total hanya
gaya visual (src/) + field opsional `hook` di sheet.

## Kapan pakai kit ini vs ofc-clip-kit

| Bahan | Pakai |
|---|---|
| Podcast / ceramah / konten serius-berbobot | `ofc-clip-kit.zip` (paper elegan) |
| Streamer / gaming / reaksi / meme / hiburan | `meme-clip-kit.zip` (dark neon) |

## Gaya visual (semua nilai di `src/config.ts`)

- **Background**: hitam pekat `#0A0A12` + garis diagonal miring bergerak
  pelan + glow purple di belakang video + glow cyan di zona caption + vignette.
- **Video**: kartu 16:9 **full-width** di zona atas (y 132-740), border neon
  purple + glow. **TANPA crop horizontal** — facecam streamer (sering di tepi
  kiri/kanan, kadang pindah) tidak boleh terpotong; reaksi wajah = bahan meme.
- **Hook banner**: strip lime `#A6FF2F` miring -2.5° menimpa jahitan bawah
  video, teks KAPITAL font Luckiest Guy, masuk overshoot → tahan 2.8s →
  melesat keluar. Teks = field `hook` di sheet (fallback: id klip).
- **Chat bubbles**: reaksi "chat" melayang naik kolom kanan video (gaya
  overlay Twitch). Pool pesan generik dekoratif, deterministik per id klip.
- **Subtitle**: KAPITAL semua, Luckiest Guy + stroke hitam pekat, masuk
  BOUNCE per kata dengan jitter rotasi kecil, kata aktif **LIME `#A6FF2F`**
  + glow (karaoke word-level whisper — sama dengan ofc, beda warna).
- **Watermark** `@ofkiehme` chip gelap kiri-bawah + **badge source** chip
  gelap kanan-bawah + **progress bar** neon gradient lime→cyan.

## Emoji DILARANG di semua elemen

Runner GitHub Actions (ubuntu-latest) tidak punya font emoji warna —
glyph emoji jadi kotak tofu di render headless Chrome. Semua pool chat
bubble & teks lain HARUS teks murni. (Ikon play badge source = CSS murni.)

## Font

- `public/fonts/LuckiestGuy-Regular.ttf` — subtitle + banner (Google Fonts,
  OFL license, di-bundle lokal supaya render offline aman).
- `Poppins-*` — chip UI (watermark, badge, chat) — sama dengan ofc kit.

## Perbedaan input vs ofc-clip-kit

Field opsional `hook` per klip di `render-inputs/clips.json`:

```json
{
  "video": "input/raw.mp4",
  "sourceChannel": "Windah Basudara",
  "clips": [
    {"id": "windah-i-can-fix-her", "start": 3370.0, "end": 3395.0,
     "hook": "I CAN FIX HER"}
  ]
}
```

- `hook` = teks banner. Kosong → otomatis dari id (`windah-i-can-fix-her`
  → `WINDAH I CAN FIX HER`).
- Durasi meme: 12-90 detik per klip (warning build-data disesuaikan;
  ofc: 40-180s).
- Semua field lain (`video`, `sourceChannel`, `id`/`start`/`end`,
  transcript, out/data format) identik ofc — skrip workflow GA sama.

## QA piksel (workflow ga-render)

Kata aktif LIME `#A6FF2F` = rgb(166, 255, 47). Threshold QA piksel utk
kit ini: `r > 120 && g > 210 && b < 110` (ofc kuning: r>200, g>160, b<120).
Workflow `ga-render.yml` punya input `qa_color` utk ini (format
`"r_min,g_min,b_max"` → meme: `"120,210,110"`).
