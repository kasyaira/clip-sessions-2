import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';
import {WATERMARK} from '../config';

/**
 * Watermark @ofkiehme — chip pill di atas-tengah area kertas.
 * Titik aksen kuning kecil di kiri teks mengikat warna highlight
 * subtitle; chip frosted-paper seirama dengan badge source di bawah.
 */
export const Watermark: React.FC = () => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [0, 14], [0, 1], {
    easing: Easing.out(Easing.cubic),
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <div
      style={{
        position: 'absolute',
        top: WATERMARK.top,
        left: 0,
        width: '100%',
        display: 'flex',
        justifyContent: 'center',
        opacity: p,
        transform: `translateY(${(1 - p) * -10}px)`,
        userSelect: 'none',
        zIndex: 30,
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          padding: `${WATERMARK.chipPaddingV}px ${WATERMARK.chipPaddingH}px`,
          borderRadius: 999,
          background: WATERMARK.chipBg,
          border: WATERMARK.chipBorder,
          boxShadow: WATERMARK.chipShadow,
        }}
      >
        <div
          style={{
            width: WATERMARK.dotSize,
            height: WATERMARK.dotSize,
            borderRadius: 999,
            background: WATERMARK.dotColor,
            boxShadow: WATERMARK.dotGlow,
          }}
        />
        <span
          style={{
            fontFamily: WATERMARK.fontFamily,
            fontWeight: WATERMARK.fontWeight,
            fontSize: WATERMARK.fontSize,
            letterSpacing: WATERMARK.letterSpacing,
            color: WATERMARK.color,
          }}
        >
          {WATERMARK.text}
        </span>
      </div>
    </div>
  );
};
