/**
 * ============================================================
 *  MEME CLIP KIT — STYLE CONFIG (SINGLE SOURCE OF TRUTH)
 * ============================================================
 *  Preset klip vertikal khusus konten MEME / HIBURAN.
 *  Kebalikan total dari ofc-clip-kit (paper/kertas elegan):
 *  dark neon "streamer gamer" — hitam pekat, aksen lime &
 *  purple, font komik Luckiest Guy, chat bubble melayang,
 *  hook banner miring, animasi bounce di mana-mana.
 *
 *  SEMUA pengaturan tampilan ada di file ini.
 *  Jangan ubah komponen lain untuk mengubah gaya visual:
 *  ubah nilai di sini, dan SEMUA klip ikut berubah konsisten.
 * ============================================================
 */

import project from './project.json';

/** Dimensi kanvas & frame rate output (identik ofc — pipeline sama) */
export const CANVAS = {
  width: 1080,
  height: 1920,
  fps: 30,
} as const;

export const COMPOSITION_ID = project.compositionId;

/** Padding waktu (detik) — meme klip pendek: tanpa lead, tail napas */
export const TIMING = {
  lead: project.lead,
  tail: project.tail,
} as const;

/**
 * VIDEO — landscape 16:9 FULL-WIDTH di zona atas.
 * TIDAK ada crop horizontal: banyak stream punya facecam di tepi
 * kiri/kanan (Windah: kiri-bawah, pindah kadang) — crop samping
 * akan memotong wajah, padahal reaksi wajah = bahan meme utama.
 */
export const VIDEO = {
  /** tinggi kartu = lebar penuh * 9/16 = 608 */
  radius: 26,
  /** border neon purple + glow ganda — "neon frame" gamer */
  border: '3px solid rgba(139, 92, 246, 0.60)',
  boxShadow:
    '0 0 0 1px rgba(166, 255, 47, 0.10), 0 0 44px rgba(139, 92, 246, 0.38), 0 26px 70px rgba(0, 0, 0, 0.55)',
  /** volume audio video sumber */
  volume: 1,
  /** posisi atas kartu (px dari tepi atas kanvas) */
  top: 132,
} as const;

/** Intro PUNCHY (vs intro halus ofc): kartu "boing" masuk dari 1.10 → 1.0 */
export const INTRO = {
  enabled: true,
  scaleFrom: 1.1,
  frames: 16,
  spring: {damping: 11, stiffness: 300, mass: 0.6},
} as const;

/** BACKGROUND dark neon — kebalikan total kertas beige ofc */
export const BG = {
  color: '#0A0A12',
  /** garis diagonal miring bergerak lambat (repeating gradient) */
  stripes: {
    enabled: true,
    size: 46,
    /** derajat kemiringan */
    angle: -18,
    color: 'rgba(139, 92, 246, 0.055)',
    /** kecepatan geser px/detik */
    drift: 26,
  },
  /** glow radial di belakang kartu video */
  glowTop: 'radial-gradient(ellipse 62% 34% at 50% 23%, rgba(139,92,246,0.30), rgba(139,92,246,0) 70%)',
  /** glow lembut di zona caption bawah */
  glowBottom: 'radial-gradient(ellipse 70% 30% at 50% 78%, rgba(34,211,238,0.10), rgba(34,211,238,0) 72%)',
  /** vignette tepi */
  vignette: 0.5,
} as const;

/** Grain halus menyatukan video & background (tekstur sama dengan ofc) */
export const GRAIN = {
  enabled: true,
  texture: 'textures/grain.png',
  opacity: 0.13,
  blend: 'overlay' as const,
  animated: true,
};

/**
 * HOOK BANNER — strip lime miring "sticker" menimpa tepi bawah video.
 * Teks hook otomatis dari field "hook" di sheet (atau fallback: id klip
 * di-spasi-kan & kapitalisasi). Muncul dgn overshoot, tahan, keluar.
 */
export const BANNER = {
  enabled: true,
  fontFamily: 'Luckiest Guy',
  fontSize: 54,
  minFontSize: 34,
  color: '#0A0A12',
  bg: '#A6FF2F',
  /** strip sedikit lebih lebar dari teks (px kiri+kanan) */
  padH: 46,
  padV: 20,
  rotate: -2.5,
  /** y pusat strip (px) — menimpa jahitan bawah video (video bottom = 740) */
  centerY: 726,
  maxWidthRatio: 0.86,
  /** timing (detik): masuk / tahan penuh / keluar */
  inAt: 0.12,
  hold: 2.8,
  outFrames: 8,
  inSpring: {damping: 12, stiffness: 260, mass: 0.7},
  shadow: '0 12px 34px rgba(0, 0, 0, 0.55)',
  /** strip bayangan tipis di bawah utk kesan sticker terangkat */
  underlay: 'rgba(10, 10, 18, 0.55)',
} as const;

/**
 * CHAT BUBBLES — reaksi "chat" melayang naik di sisi KANAN video,
 * gaya overlay Twitch. TEKS SAJA tanpa emoji (runner GA tidak punya
 * font emoji warna — emoji jadi kotak tofu, dilarang). Deterministik:
 * pilihan pesan di-seed dari id klip, jadi render ulang = identik.
 */
export const CHAT = {
  enabled: true,
  /** interval kemunculan (detik) */
  every: 1.05,
  /** umur satu bubble (detik) terbang dari bawah ke atas */
  life: 2.6,
  /** jarak antar bubble aktif berdampingan (px) */
  laneGap: 108,
  /** area kolom bubble: kanan video */
  right: 26,
  width: 356,
  /** mulai dari y ini (dekat bawah video) naik ke atas */
  yFrom: 690,
  yTo: 150,
  maxVisible: 3,
  fontFamily: 'Poppins',
  nameSize: 22,
  nameWeight: '600',
  msgSize: 25,
  msgWeight: '600',
  chipBg: 'rgba(13, 13, 22, 0.86)',
  chipBorder: '1px solid rgba(139, 92, 246, 0.35)',
  chipRadius: 18,
  chipPadH: 18,
  chipPadV: 12,
  nameColors: ['#A6FF2F', '#8B5CF6', '#22D3EE', '#F472B6', '#FBBF24'],
  msgColor: '#F4F2FA',
  /** opasitas penuh saat 15%-75% umur, fade di kedua ujung */
  fadeIn: 0.15,
  fadeOut: 0.75,
  /** pesan reaksi generik (hiasan edit, bukan kutipan) */
  messages: [
    'WKWKWKWK',
    'GILA SIH',
    'HAHAHAHA',
    'NAH INI',
    'BENER BANGET',
    'TOBAT WOI',
    'WADAW',
    'GELAK BANG',
    'BUSYET',
    'GARA-GARA DIA',
    'NOOO NGGAK',
    'FIX DIA',
    'SANTUY WOY',
    'MALU BANG',
    'LARI PAK',
    'HUHAHAHA',
    'BANGUN BANG',
    'SABAR YA',
  ],
  /** username generik lucu (dekorasi, jelas bukan akun nyata) */
  names: [
    'bocil_galau',
    'chat_baik',
    'rand_5000',
    'pak_budi',
    'memelord',
    'warga_id',
    'sleepy_viewers',
    'tetangga_mas',
    'anon_imoet',
    'soto_boy',
  ],
} as const;

/** SUBTITLE meme: kapital semua, font komik, kata aktif LIME + glow */
export const SUBTITLE = {
  fontFamily: 'Luckiest Guy',
  /** font display satu bobot — weight 400 saja */
  fontWeight: '400',
  fontSize: 100,
  minFontSize: 64,
  color: '#FFFFFF',
  strokeColor: '#0A0A12',
  /** stroke < 2x margin antar kata (lihat catatan di Subtitles.tsx) */
  strokeWidth: 12,
  lineHeight: 1.08,
  letterSpacing: '0.015em',
  shadow: 'drop-shadow(0 7px 22px rgba(0, 0, 0, 0.65))',
  maxWidthRatio: 0.88,
  /** zona caption: bawah banner, di atas watermark (canvas 1920) */
  centerY: 0.635,
  /** bounce masuk per kata: stagger tipis + spring overshoot kencang */
  staggerFrames: 1.4,
  entryFrames: 11,
  spring: {damping: 10, stiffness: 320, mass: 0.5},
  /** jitter rotasi kecil per kata — chunk beda sudut = hidup (deterministik) */
  rotJitterDeg: 1.6,
  exitFrames: 4,
  holdAfterEnd: 0.8,
  activeWord: {
    enabled: true,
    scale: 1.12,
    dimOpacity: 0.88,
    /** LIME — identitas meme kit (ofc pakai kuning #FFD60A) */
    color: '#A6FF2F',
    onFrames: 2,
    fadeFrames: 3,
    holdBuffer: 0.3,
    glow: '0 0 26px rgba(166, 255, 47, 0.65)',
  },
  chunk: {preferWords: 3, maxWords: 4},
  /** kapitalisasi semua teks (gaya meme) */
  uppercase: true,
} as const;

/** Badge "source: <channel>" — chip gelap pojok kanan bawah */
export const SOURCE = {
  enabled: true,
  label: 'source',
  text: '',
  fontFamily: 'Poppins',
  labelWeight: '600',
  labelSize: 26,
  labelColor: 'rgba(244, 242, 250, 0.55)',
  channelWeight: '700',
  channelSize: 28,
  channelColor: '#F4F2FA',
  letterSpacing: '0.02em',
  bg: 'rgba(13, 13, 22, 0.80)',
  border: '1px solid rgba(139, 92, 246, 0.38)',
  shadow: '0 8px 26px rgba(0, 0, 0, 0.45)',
  radius: 999,
  paddingH: 26,
  height: 58,
  gap: 13,
  iconSize: 30,
  iconBg: '#A6FF2F',
  iconRadius: 9,
  right: 40,
  bottom: 62,
  fadeDelayFrames: 8,
  fadeInFrames: 14,
  risePx: 14,
} as const;

/** Watermark @ofkiehme — chip gelap pojok kiri bawah (ofc: atas tengah) */
export const WATERMARK = {
  text: '@ofkiehme',
  fontFamily: 'Poppins',
  fontWeight: '600',
  fontSize: 28,
  letterSpacing: '0.16em',
  color: 'rgba(244, 242, 250, 0.85)',
  chipBg: 'rgba(13, 13, 22, 0.80)',
  chipBorder: '1px solid rgba(139, 92, 246, 0.38)',
  chipShadow: '0 8px 26px rgba(0, 0, 0, 0.45)',
  chipPaddingH: 26,
  chipPaddingV: 11,
  dotSize: 8,
  dotColor: '#A6FF2F',
  dotGlow: '0 0 8px rgba(166, 255, 47, 0.60)',
  left: 40,
  bottom: 62,
} as const;

/** Progress bar neon gradient bawah */
export const PROGRESS_BAR = {
  position: 'bottom' as const,
  height: 8,
  marginH: 24,
  offset: 26,
  /** gradient lime → cyan */
  color: 'linear-gradient(90deg, #A6FF2F 0%, #22D3EE 100%)',
  track: 'rgba(244, 242, 250, 0.10)',
  radius: 999,
  glow: '0 0 16px rgba(166, 255, 47, 0.40)',
  head: {
    enabled: true,
    size: 15,
    color: '#22D3EE',
    ring: '2px solid rgba(10, 10, 18, 0.9)',
    glow: '0 0 14px rgba(34, 211, 238, 0.75)',
  },
} as const;
