import React, {useMemo} from 'react';
import {
  AbsoluteFill,
  OffthreadVideo,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {CANVAS, INTRO, PAPER, TIMING, VIDEO} from '../config';
import type {ClipData} from '../types';
import {chunkWords} from '../helpers/chunker';
import {GrainOverlay, PaperBackground} from '../components/PaperBackground';
import {Subtitles} from '../components/Subtitles';
import {ProgressBar} from '../components/ProgressBar';
import {Watermark} from '../components/Watermark';
import {SourceBadge} from '../components/SourceBadge';
import {TapeCorners} from '../components/TapeCorners';

/** Durasi komposisi (frame) dihitung otomatis dari rentang potongan + padding */
export const clipDurationInFrames = (data: ClipData): number => {
  const seconds = data.clipEnd - data.clipStart + TIMING.lead + TIMING.tail;
  return Math.max(CANVAS.fps, Math.ceil(seconds * CANVAS.fps));
};

/**
 * OFC CLIP KIT v1.2 — template klip vertikal @ofkiehme
 * Urutan layer (bawah -> atas):
 *   kertas (foto tekstur stock CC0) -> kartu video (+ washi tape)
 *   -> grain -> subtitle -> watermark (chip) -> badge source (pojok kanan
 *   bawah) -> progress bar (bawah)
 */
export const VerticalClip: React.FC<{data: ClipData}> = ({data}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();

  const chunks = useMemo(() => chunkWords(data.words), [data.words]);

  const videoH = Math.round((CANVAS.width * 9) / 16);
  const startFrom = Math.max(0, Math.round((data.clipStart - TIMING.lead) * fps));

  // intro halus: kartu sedikit mengecil + naik sesaat di awal klip
  const introP = INTRO.cardEnabled
    ? spring({
        fps,
        frame,
        config: INTRO.cardSpring,
        durationInFrames: INTRO.cardFrames,
      })
    : 1;
  const cardScale =
    INTRO.cardScaleFrom + (1 - INTRO.cardScaleFrom) * introP;
  const cardRise = (1 - introP) * INTRO.cardRisePx;
  const offsetY = (VIDEO.centerY - 0.5) * CANVAS.height + cardRise;

  return (
    <AbsoluteFill
      style={{backgroundColor: PAPER.color, overflow: 'hidden'}}
    >
      <PaperBackground />

      {/* Video utama 16:9 sebagai kartu; posisi vertikal diatur VIDEO.centerY.
          Wrapper (transform intro) membungkus kartu + washi tape — tape
          dirender di luar overflow-hidden kartu supaya boleh menjorok. */}
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
        <div
          style={{
            position: 'relative',
            width: CANVAS.width,
            height: videoH,
            transform: `translateY(${offsetY}px) scale(${cardScale})`,
          }}
        >
          <div
            style={{
              position: 'absolute',
              inset: 0,
              borderRadius: VIDEO.radius,
              overflow: 'hidden',
              boxShadow: VIDEO.boxShadow,
              border: VIDEO.border,
              backgroundColor: '#141210',
            }}
          >
            {data.video ? (
              <OffthreadVideo
                src={staticFile(data.video)}
                startFrom={startFrom}
                volume={VIDEO.volume}
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                }}
              />
            ) : (
              <AbsoluteFill
                style={{
                  justifyContent: 'center',
                  alignItems: 'center',
                  color: 'rgba(255,255,255,0.65)',
                  fontFamily: 'Poppins',
                  fontWeight: 600,
                  fontSize: 32,
                  textAlign: 'center',
                  padding: 48,
                  lineHeight: 1.5,
                }}
              >
                MODE DEMO — STYLE PREVIEW
                <br />
                (isi field "video" di file data untuk render asli)
              </AbsoluteFill>
            )}
          </div>
          <TapeCorners />
        </div>
      </AbsoluteFill>

      <GrainOverlay />
      <Subtitles chunks={chunks} />
      <Watermark />
      <SourceBadge channel={data.sourceChannel} />
      <ProgressBar
        progress={durationInFrames > 1 ? frame / (durationInFrames - 1) : 0}
      />
    </AbsoluteFill>
  );
};
