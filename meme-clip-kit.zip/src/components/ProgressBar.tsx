import React from 'react';
import {PROGRESS_BAR} from '../config';

/**
 * Progress klip — track gelap + fill GRADIENT lime→cyan dengan glow
 * neon dan titik cyan bercahaya di ujung fill. Ditempatkan di tepi
 * bawah frame, seirama UI TikTok/Reels (menggantikan progress hitam
 * polos + kepala kuning ala story ofc-kit).
 */
export const ProgressBar: React.FC<{progress: number}> = ({progress}) => {
  const p = Math.min(1, Math.max(0, progress));
  const posStyle: React.CSSProperties =
    PROGRESS_BAR.position === 'bottom'
      ? {bottom: PROGRESS_BAR.offset}
      : {top: PROGRESS_BAR.offset};

  const showHead =
    PROGRESS_BAR.head.enabled && p > 0.004 && p < 0.997;

  return (
    <div
      style={{
        position: 'absolute',
        left: PROGRESS_BAR.marginH,
        right: PROGRESS_BAR.marginH,
        ...posStyle,
        height: PROGRESS_BAR.height,
        borderRadius: PROGRESS_BAR.radius,
        background: PROGRESS_BAR.track,
        zIndex: 30,
      }}
    >
      <div
        style={{
          height: '100%',
          width: `${p * 100}%`,
          borderRadius: PROGRESS_BAR.radius,
          background: PROGRESS_BAR.color,
          boxShadow: PROGRESS_BAR.glow,
        }}
      />
      {showHead ? (
        <div
          style={{
            position: 'absolute',
            left: `calc(${p * 100}% - ${PROGRESS_BAR.head.size / 2}px)`,
            top: '50%',
            transform: 'translateY(-50%)',
            width: PROGRESS_BAR.head.size,
            height: PROGRESS_BAR.head.size,
            borderRadius: 999,
            background: PROGRESS_BAR.head.color,
            border: PROGRESS_BAR.head.ring,
            boxShadow: PROGRESS_BAR.head.glow,
          }}
        />
      ) : null}
    </div>
  );
};
