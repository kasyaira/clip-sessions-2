# CATATAN REVISI — ofc-clip-kit (fixed)

Revisi atas permintaan user (3 poin) + perbaikan kompatibilitas pipeline.
**Dokumen pendamping:** `CATATAN-TEKNIS.md` (runbook lengkap: environment, error yang pernah
terjadi + solusinya, parameter render terbukti). Baca itu dulu sebelum menjalankan pipeline.

## 1. Subtitle Bahasa Indonesia (sesuai isi video)
- `npm run transcribe` sekarang mendukung flag bahasa:
  ```bash
  npm run transcribe -- public/input/raw.mp4 --language id
  ```
- Transkrip aktif: `out/transcripts/raw-id.json` (whisper small, word-level, dipaksa bahasa Indonesia).
- `render-inputs/clips.json` punya field baru `"transcript": "raw-id.json"` untuk menunjuk transkrip tertentu.
- Fix bug merging sub-kata di `scripts/transcribe.mjs`: accumulator kata dipindah ke luar loop segmen
  (dengan `--max-len 1`, satu kata bisa membentang antar segmen — sebelumnya "tanya" terpecah jadi "t anya").

## 2. Video card digeser ke atas
- `src/config.ts` → properti baru `VIDEO.centerY` (fraksi tinggi kanvas; 0.5 = tengah).
  Nilai sekarang: **0.44** (kartu naik ±115px dari posisi lama).
- `src/vertical-clip/VerticalClip.tsx` membaca `VIDEO.centerY` (translateY) — tidak lagi hardcode center.
- Cukup ubah angka di config untuk mengatur lagi.

## 3. Satu klip utuh (tidak dipecah)
- `render-inputs/clips.json` sekarang berisi 1 klip: `{id: "video-utuh", start: 0, end: 158}`.
- `src/project.json`: `lead` 0.18 → **0** supaya subtitle sinkron persis saat klip mulai dari detik 0
  (lead tetap tersedia untuk klip yang dipotong dari tengah video).

## Perbaikan pipeline (kompatibilitas environment baru)
- `scripts/transcribe.mjs` diadaptasi ke `@remotion/install-whisper-cpp` v4.0.526:
  API baru (to:/downloadWhisperModel/whisperCppVersion/offsets ms), filter token `[_BEG_]/[_TT_xx]`,
  cache whisper per model+bahasa di `out/tmp/*.whisper-cache-*.json`.
- `scripts/render-all.mjs`: `enableMultiProcessOnLinux: true` + `concurrency: 2` + `x264Preset: veryfast`
  (di sandbox Linux, mode single-process bawaan bikin render 4-5x lebih lambat).
- Script baru `scripts/render-segments.mjs`: render klip panjang per segmen ±1584 frame (idempoten,
  aman diulang; video dirender muted lalu audio asli dari sumber di-mux saat penggabungan — bebas
  glitch AAC di batas segmen). Pemakaian:
  ```bash
  node scripts/render-segments.mjs                # pakai out/data/video-utuh.json
  # setelah semua segmen selesai, gabung:
  ls out/segments/seg-*.mp4 | sort | xargs -n1 basename | sed "s/^/file '/;s/$/'/" > out/segments/concat.txt
  ffmpeg -y -f concat -safe 0 -i out/segments/concat.txt -c:v copy out/tmp/nosound.mp4
  ffmpeg -y -i public/input/raw.mp4 -t <durasi> -vn -c:a copy out/tmp/audio.m4a
  ffmpeg -y -i out/tmp/nosound.mp4 -i out/tmp/audio.m4a -map 0:v -map 1:a -c copy -shortest out/clips/<id>.mp4
  ```

## Data hasil transkripsi (ikut dikirim)
- `out/transcripts/raw-id.json` — word-level Bahasa Indonesia (381 kata)
- `out/transcripts/raw.json` — word-level English (553 kata, versi lama)
- `out/data/video-utuh.json` — data klip siap render (timing kata relatif klip)

## Cara render ulang
```bash
npm install
npm run transcribe -- public/input/raw.mp4 --language id   # opsional, transkrip sudah ikut
npm run build-data
npm run render          # klip pendek; untuk klip panjang pakai render-segments.mjs
```

## v1.2.1 (sesi-21)
- scripts/part-split.mjs kembali masuk zip (hilang dari zip sesi-20)
- scripts BARU dari sesi-21 (agent tools, sekarang resmi ikut kit):
  - dl-retry.sh — wrapper loader-download dengan auto-restart saat koneksi
    mati diam-diam (§42); log work/dl-retry.log relatif root kit
  - fix-monotonic.py — perbaiki run timestamp kata non-monotonik buatan
    whisper di tengah bagian (§52); idempoten
  - boundary-helper.mjs — kandidat batas klip: kata berujung [.?!] ATAU
    jeda hening >= 0.45s (§49.5)
- render-inputs/clips.json berisi definisi sesi-21 (13 klip, contoh
  penamaan file spasi ada di metadata sesi-21)
- TANPA node_modules / whisper.cpp / out/ / raw.mp4 / cache-pack (sama
  seperti sebelumnya)

## revisi sesi-22 (v1.2 + rantai kit + aturan nama §55)

- scripts BARU resmi ikut kit (sebelumnya eksternal agent, dibuat ulang tiap sesi):
  - render-one.sh — render 1 klip + marker resume out/segments/.current-clip
  - finish-one.sh — finalize idempoten → QA 3 titik proporsional + auto cek
    tetangga LOW → upload DENGAN NAMA SPASI TANPA NOMOR URAT (aturan §55) →
    hapus klip lokal pasca-upload
  - chain.sh <A|-> <B> <sesi-dir> — finish A + render B dalam satu panggilan
- dl-retry.sh FIX §56: OUT di-absolut-kan (readlink -f) + LOG absolut —
  bug path relatif ENOENT setelah cd internal jangan sampai balik lagi
- CARA-KERJA.md di kit = versi addendum SESI-22 (§55 aturan nama permanen)
- render-inputs/clips.json = contoh sesi-22 (13 klip ID topik tanpa nomor)
- ATURAN NAMA §55: id lokal slug topik hyphen; nama remote slug dengan
  spasi TANPA "clip NN"; urutan hanya di metadata.json (field urutan)
- TANPA node_modules / whisper.cpp / out/ / raw.mp4 / cache-pack
