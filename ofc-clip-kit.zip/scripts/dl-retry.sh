#!/usr/bin/env bash
# dl-retry.sh — loader-download dengan auto-restart saat koneksi mati diam-diam (§42)
# Pola: server loader acak umur; kalau .part tidak bertumbuh 30 detik => kill & mulai
# sesi BARU (server tidak dukung Range). Selesai = file final ada + ffprobe valid.
set -uo pipefail
URL="${1:?url}"
OUT="${2:?out file}"
LOG=work/dl-retry.log
MAX_ATTEMPTS=12
echo "=== dl-retry start $(date +%H:%M:%S) ===" >> "$LOG"

for i in $(seq 1 $MAX_ATTEMPTS); do
  # file final sudah ada dari attempt sebelumnya?
  if [ -f "$OUT" ]; then
    DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$OUT" 2>/dev/null | grep -oE '[0-9.]+' | head -1)
    if [ -n "$DUR" ]; then
      echo "[dl-retry] SELESAI: $OUT durasi=${DUR}s attempt=$i" | tee -a "$LOG"
      exit 0
    fi
    rm -f "$OUT"  # ada tapi invalid, buang
  fi
  echo "[dl-retry] attempt $i $(date +%H:%M:%S)" >> "$LOG"
  cd /home/z/my-project/ofc-clip-kit
  node scripts/loader-download.mjs "$URL" "$OUT" 720 > /home/z/my-project/work/dl-attempt.log 2>&1 &
  PID=$!
  # pantau pertumbuhan .part / kemunculan file final
  STALL=0
  LAST_SIZE=-1
  while kill -0 $PID 2>/dev/null; do
    sleep 10
    if [ -f "$OUT" ]; then break; fi  # selesai & ter-rename
    SIZE=$(stat -c%s "$OUT.part" 2>/dev/null || echo 0)
    if [ "$SIZE" -le "$LAST_SIZE" ]; then
      STALL=$((STALL+1))
      if [ $STALL -ge 3 ]; then
        echo "[dl-retry] attempt $i STALL di ${SIZE} bytes — kill & restart" >> "$LOG"
        kill -9 $PID 2>/dev/null; sleep 1
        break
      fi
    else
      STALL=0
      LAST_SIZE=$SIZE
      echo "[dl-retry] attempt $i: $((SIZE/1048576)) MB" >> "$LOG"
    fi
  done
  wait $PID 2>/dev/null
done
echo "[dl-retry] GAGAL setelah $MAX_ATTEMPTS attempts" | tee -a "$LOG"
exit 1
