/**
 * ============================================================
 *  OFC CLIP KIT — STYLE CONFIG (SINGLE SOURCE OF TRUTH)
 * ============================================================
 *  SEMUA pengaturan tampilan ada di file ini.
 *  Jangan ubah komponen lain untuk mengubah gaya visual:
 *  ubah nilai di sini, dan SEMUA klip ikut berubah secara konsisten.
 * ============================================================
 */

import project from './project.json';

/** Dimensi kanvas & frame rate output */
export const CANVAS = {
  width: 1080,
  height: 1920,
  fps: 30,
} as const;

export const COMPOSITION_ID = project.compositionId;

/** Padding waktu (detik) di awal & akhir klip supaya napasnya natural */
export const TIMING = {
  lead: project.lead,
  tail: project.tail,
};

/** Video sumber diasumsikan landscape 16:9 (bahan podcast / talking head) */
export const VIDEO = {
  /** sudut membulat kartu video */
  radius: 30,
  /** bayangan berlapis 3 tingkat — kartu terasa "duduk" di atas kertas */
  boxShadow:
    '0 34px 90px rgba(35, 28, 15, 0.34), 0 10px 28px rgba(35, 28, 15, 0.18), 0 2px 8px rgba(35, 28, 15, 0.12)',
  border: '1px solid rgba(22, 21, 19, 0.14)',
  /** volume audio video sumber, 0..1 */
  volume: 1,
  /** posisi vertikal TENGAH kartu video (fraksi tinggi kanvas).
   *  0.5 = persis tengah. 0.455 = kartu agak ke atas (v1.2 diturunkan sedikit
   *  dari 0.465) supaya zona kertas bawah makin lega untuk subtitle + badge
   *  source + progress bar. */
  centerY: 0.455,
} as const;

/** Animasi masuk klip (beberapa frame pertama) — kesan "produced", bukan potongan mentah */
export const INTRO = {
  /** kartu video: scale + rise halus saat klip mulai */
  cardEnabled: true,
  cardScaleFrom: 0.962,
  cardRisePx: 18,
  cardFrames: 18,
  cardSpring: {damping: 15, stiffness: 120, mass: 0.75},
} as const;

/** Background blocking — foto tekstur kertas ASLI dari stock gratis (v1.2)
 *  Sumber: rawpixel "Paper texture, beige background" — CC0, diambil lewat
 *  api.openverse.org; di-grade & mirror-tile jadi 1080x1920 (skrip
 *  scripts/paper-source.txt di public/textures/ mencatat asal + lisensi). */
export const PAPER = {
  /** warna fallback di belakang tekstur (mendekati rata-rata tekstur) */
  color: '#C9C2B7',
  /** file tekstur di folder public/ (full-frame 1080x1920) */
  texture: 'textures/paper.png',
  /** kekuatan vignette gelap di pinggir kertas, 0..1 — tekstur asli sudah
   *  punya kedalaman alami, vignette cukup kalem */
  vignette: 0.42,
} as const;

/** Lapisan grain halus di atas seluruh frame (biar video & kertas menyatu) */
export const GRAIN = {
  enabled: true,
  texture: 'textures/grain.png',
  opacity: 0.16,
  blend: 'overlay' as const,
  /** grain bergeser tiap frame -> film look hidup */
  animated: true,
};

/** Strip "washi tape" menempel di tepi atas kartu video — memperkuat
 *  identitas "kertas / tempelan" preset. Setengah strip di kertas,
 *  setengahnya di atas video, persis selotip foto sungguhan. */
export const TAPE = {
  enabled: true,
  width: 152,
  height: 32,
  bg: 'rgba(240, 233, 216, 0.58)',
  border: '1px solid rgba(255, 255, 255, 0.28)',
  shadow: '0 3px 10px rgba(35, 28, 15, 0.20)',
  /** rotasi strip kiri/kanan (derajat, positif = searah jarum jam) */
  rotate: 38,
  /** jarak strip dari sudut kiri/kanan kartu (px) */
  inset: 64,
} as const;

/** Subtitle chunk 2-4 kata, clean minimal: putih + outline hitam */
export const SUBTITLE = {
  fontFamily: 'Poppins',
  fontWeight: '800',
  fontSize: 96,
  minFontSize: 64,
  color: '#FFFFFF',
  strokeColor: '#151310',
  strokeWidth: 13,
  lineHeight: 1.14,
  letterSpacing: '0.01em',
  shadow: 'drop-shadow(0 6px 18px rgba(0, 0, 0, 0.38))',
  /** lebar maksimum blok teks (fraksi dari lebar kanvas) */
  maxWidthRatio: 0.9,
  /** posisi vertikal tengah blok subtitle (fraksi tinggi kanvas). Kartu video
   *  dgn centerY 0.455 berakhir di y~1184; 0.70 = sepenuhnya di area kertas
   *  BAWAH kartu — blok subtitle y~1240-1460, di atas badge source. */
  centerY: 0.70,
  /** animasi pop masuk */
  staggerFrames: 1.6,
  entryFrames: 13,
  spring: {damping: 13, stiffness: 230, mass: 0.55},
  /** animasi keluar cepat */
  exitFrames: 4,
  /** subtitle tetap tampil beberapa detik setelah chunk selesai (menghindari kelap-kelip saat jeda napas) */
  holdAfterEnd: 0.9,
  /** kata yang sedang diucap: berubah KUNING mengikuti irama bicara per kata,
   *  sedikit membesar, penuh opasitas; kata lain tetap putih & terbaca jelas */
  activeWord: {
    enabled: true,
    scale: 1.08,
    /** opasitas kata non-aktif — tetap tinggi agar warna tetap keliatan */
    dimOpacity: 0.85,
    /** warna highlight kata yang sedang diucap (kuning terang) */
    color: '#FFD60A',
    /** durasi ramp kuning saat kata mulai diucap (frame) */
    onFrames: 2,
    /** durasi fade balik ke putih setelah kata selesai (frame) */
    fadeFrames: 3,
    /** tahan kuning sesaat setelah kata selesai supaya tidak kedip (detik) */
    holdBuffer: 0.3,
  },
  /** aturan pemecah chunk: ideal & maksimal jumlah kata per popup */
  chunk: {preferWords: 3, maxWords: 4},
} as const;

/** Badge "source: <nama channel>" — atribusi channel sumber di pojok kiri bawah.
 *  Nama channel otomatis mengalir dari render-inputs/clips.json (field
 *  "sourceChannel") lewat build-data; field SOURCE.text di bawah cuma fallback. */
export const SOURCE = {
  enabled: true,
  /** label sebelum nama channel (tanpa titik dua — ditambahkan otomatis) */
  label: 'source',
  /** fallback kalau data klip tidak membawa sourceChannel */
  text: '',
  fontFamily: 'Poppins',
  labelWeight: '600',
  labelSize: 27,
  labelColor: 'rgba(24, 21, 16, 0.55)',
  channelWeight: '800',
  channelSize: 29,
  channelColor: '#181510',
  letterSpacing: '0.02em',
  /** bentuk chip pill "frosted paper" */
  bg: 'rgba(255, 253, 246, 0.74)',
  border: '1px solid rgba(24, 21, 16, 0.10)',
  shadow: '0 6px 18px rgba(35, 28, 15, 0.16)',
  radius: 999,
  paddingH: 26,
  height: 58,
  gap: 13,
  /** ikon play kecil di kiri teks (segitiga murni CSS — selalu render) */
  iconSize: 30,
  iconBg: '#1A1712',
  iconRadius: 9,
  /** posisi pojok KANAN-bawah (v1.2: dipindah dari kiri — pojok kiri-bawah
   *  TikTok/Reels dipakai UI username & caption, jadi attribution lebih
   *  aman & bebas tumpukan di kanan) */
  right: 44,
  bottom: 60,
  /** animasi masuk: fade + naik halus sesaat setelah klip mulai */
  fadeDelayFrames: 8,
  fadeInFrames: 14,
  risePx: 14,
} as const;

export const WATERMARK = {
  text: '@ofkiehme',
  fontFamily: 'Poppins',
  fontWeight: '600',
  fontSize: 28,
  letterSpacing: '0.16em',
  color: 'rgba(24, 21, 16, 0.62)',
  /** chip pill halus di belakang teks (serasi dengan badge source) */
  chipBg: 'rgba(255, 253, 246, 0.55)',
  chipBorder: '1px solid rgba(24, 21, 16, 0.08)',
  chipShadow: '0 4px 14px rgba(35, 28, 15, 0.10)',
  chipPaddingH: 26,
  chipPaddingV: 11,
  /** titik aksen kuning kecil sebelum teks — mengikat ke highlight subtitle */
  dotSize: 8,
  dotColor: '#FFD60A',
  dotGlow: '0 0 8px rgba(255, 214, 10, 0.60)',
  /** jarak dari tepi atas frame (px) — di tengah zona kertas atas kartu
   *  (v1.2: 156 — sedikit naik biar seimbang dgn kartu yang juga naik) */
  top: 156,
} as const;

export const PROGRESS_BAR = {
  /** penempatan: 'bottom' (default, seirama UI TikTok/Reels) atau 'top' */
  position: 'bottom' as const,
  height: 6,
  /** margin kiri/kanan track dari tepi frame (px) */
  marginH: 24,
  /** jarak track dari tepi bawah (atau atas, kalau position='top') (px) */
  offset: 24,
  color: '#181510',
  track: 'rgba(24, 21, 16, 0.10)',
  radius: 999,
  /** titik kuning yang "menjalan" di ujung fill — seperti story IG */
  head: {
    enabled: true,
    size: 14,
    color: '#FFD60A',
    ring: '2px solid #F1EBDD',
    glow: '0 0 12px rgba(255, 214, 10, 0.55)',
  },
} as const;
