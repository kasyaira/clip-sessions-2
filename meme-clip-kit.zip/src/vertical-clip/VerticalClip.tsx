import React, {useMemo} from 'react';
import {
  AbsoluteFill,
  OffthreadVideo,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {CANVAS, INTRO, TIMING, VIDEO} from '../config';
import type {ClipData} from '../types';
import {chunkWords} from '../helpers/chunker';
import {GrainOverlay, MemeBackground} from '../components/MemeBackground';
import {Subtitles} from '../components/Subtitles';
import {ProgressBar} from '../components/ProgressBar';
import {Watermark} from '../components/Watermark';
import {SourceBadge} from '../components/SourceBadge';
import {HookBanner, hookFromId} from '../components/HookBanner';
import {ChatBubbles} from '../components/ChatBubbles';

/** Durasi komposisi (frame) dihitung otomatis dari rentang potongan + padding */
export const clipDurationInFrames = (data: ClipData): number => {
  const seconds = data.clipEnd - data.clipStart + TIMING.lead + TIMING.tail;
  return Math.max(CANVAS.fps, Math.ceil(seconds * CANVAS.fps));
};

/**
 * MEME CLIP KIT v1.0 — template klip vertikal khusus MEME / HIBURAN.
 * Kebalikan total dari ofc-clip-kit (kertas elegan):
 *   background hitam neon + strip diagonal bergerak -> video 16:9
 *   FULL-WIDTH di atas (tanpa crop samping — facecam streamer aman)
 *   -> chat bubble reaksi melayang (kolom kanan video) -> hook banner
 *   lime miring menimpa jahitan bawah video -> subtitle KAPITAL font
 *   komik dgn kata aktif LIME -> watermark & badge source (chip gelap)
 *   -> progress bar neon gradient.
 */
export const VerticalClip: React.FC<{data: ClipData}> = ({data}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();

  const chunks = useMemo(() => chunkWords(data.words), [data.words]);
  const hook = useMemo(
    () => (data.hook && data.hook.trim()) || hookFromId(data.id),
    [data.hook, data.id]
  );

  const videoH = Math.round((CANVAS.width * 9) / 16); // 608
  const startFrom = Math.max(0, Math.round((data.clipStart - TIMING.lead) * fps));

  // intro PUNCHY: kartu "boing" dari 1.10 -> 1.0 (vs ofc: halus 0.962 -> 1)
  const introP = INTRO.enabled
    ? spring({
        fps,
        frame,
        config: INTRO.spring,
        durationInFrames: INTRO.frames,
      })
    : 1;
  const cardScale = INTRO.scaleFrom + (1 - INTRO.scaleFrom) * introP;

  return (
    <AbsoluteFill style={{backgroundColor: '#0A0A12', overflow: 'hidden'}}>
      <MemeBackground />

      {/* Video utama 16:9 full-width di zona atas — TANPA crop samping
          (facecam streamer di tepi kiri/kanan harus tetap terlihat). */}
      <div
        style={{
          position: 'absolute',
          top: VIDEO.top,
          left: 0,
          width: CANVAS.width,
          height: videoH,
          transform: `scale(${cardScale})`,
          transformOrigin: '50% 50%',
        }}
      >
        <div
          style={{
            position: 'absolute',
            inset: 0,
            borderRadius: VIDEO.radius,
            overflow: 'hidden',
            boxShadow: VIDEO.boxShadow,
            border: VIDEO.border,
            backgroundColor: '#05050A',
          }}
        >
          {data.video ? (
            <OffthreadVideo
              src={staticFile(data.video)}
              startFrom={startFrom}
              volume={VIDEO.volume}
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
              }}
            />
          ) : (
            <AbsoluteFill
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                color: 'rgba(244, 242, 250, 0.65)',
                fontFamily: 'Luckiest Guy',
                fontWeight: 400,
                fontSize: 26,
                textAlign: 'center',
                width: '84%',
                margin: '0 auto',
                lineHeight: 1.7,
                letterSpacing: '0.05em',
              }}
            >
              MODE DEMO
              <br />
              MEME STYLE PREVIEW
              <br />
              <br />
              ISI FIELD "VIDEO"
              <br />
              DI FILE DATA UNTUK
              <br />
              RENDER ASLI
            </AbsoluteFill>
          )}
        </div>
      </div>

      {/* reaksi "chat" melayang — kolom kanan DI ATAS video */}
      <ChatBubbles clipId={data.id} />

      {/* hook banner — strip lime miring menimpa jahitan bawah video */}
      <HookBanner hook={hook} />

      <GrainOverlay />
      <Subtitles chunks={chunks} />
      <Watermark />
      <SourceBadge channel={data.sourceChannel} />
      <ProgressBar
        progress={durationInFrames > 1 ? frame / (durationInFrames - 1) : 0}
      />
    </AbsoluteFill>
  );
};
